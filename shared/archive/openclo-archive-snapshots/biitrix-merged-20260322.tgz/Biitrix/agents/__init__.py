"""Пакет агентной иерархии Cloudbot."""

__all__ = [
    "larisa_ivanovna",
    "news_agent",
    "sales_agent",
]
