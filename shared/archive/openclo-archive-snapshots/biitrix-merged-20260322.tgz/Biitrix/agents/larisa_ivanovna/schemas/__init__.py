"""Схемы и DTO агента Ларисы Ивановны."""

from .brief import DayBrief, DayBriefRequest, FreeWindow, WeatherSnapshot
from .calendar import CalendarDaySnapshot, CalendarEvent, CreateCalendarEventInput
from .news import NewsDigest, NewsItem
from .task import TaskDaySnapshot, TaskItem

__all__ = [
    "CalendarDaySnapshot",
    "CalendarEvent",
    "CreateCalendarEventInput",
    "DayBrief",
    "DayBriefRequest",
    "FreeWindow",
    "NewsDigest",
    "NewsItem",
    "TaskDaySnapshot",
    "TaskItem",
    "WeatherSnapshot",
]
