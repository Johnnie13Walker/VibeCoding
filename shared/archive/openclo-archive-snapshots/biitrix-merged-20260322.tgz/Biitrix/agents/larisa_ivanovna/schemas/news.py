"""Контракты news-слоя."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class NewsItem:
    id: str
    topic: str
    title: str
    summary: str
    url: str = ""
    published_at_msk: str = ""
    source: str = "news"


@dataclass(frozen=True)
class NewsDigest:
    date_msk: str
    topics: tuple[str, ...] = field(default_factory=tuple)
    items: tuple[NewsItem, ...] = field(default_factory=tuple)
    source_available: bool = False
    limitation: str | None = None
