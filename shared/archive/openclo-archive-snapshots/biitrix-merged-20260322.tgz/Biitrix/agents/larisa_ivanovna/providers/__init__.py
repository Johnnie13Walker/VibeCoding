"""Provider contracts и адаптеры Ларисы Ивановны."""

from .calendar_provider import CalendarProvider, CalendarSkillProvider, NullCalendarProvider
from .news_provider import NewsProvider, NullNewsProvider
from .search_provider import NullSearchProvider, SearchProvider, SearchResponse, WebSearchSkillProvider
from .tasks_provider import NullTasksProvider, TasksProvider, TodoTasksSkillProvider
from .telegram_provider import NullTelegramProvider, SharedTelegramRouteProvider, TelegramProvider
from .weather_provider import NullWeatherProvider, WeatherProvider

__all__ = [
    "CalendarProvider",
    "CalendarSkillProvider",
    "NewsProvider",
    "NullCalendarProvider",
    "NullNewsProvider",
    "NullSearchProvider",
    "NullTasksProvider",
    "NullTelegramProvider",
    "NullWeatherProvider",
    "SearchProvider",
    "SearchResponse",
    "SharedTelegramRouteProvider",
    "TasksProvider",
    "TelegramProvider",
    "TodoTasksSkillProvider",
    "WeatherProvider",
    "WebSearchSkillProvider",
]
