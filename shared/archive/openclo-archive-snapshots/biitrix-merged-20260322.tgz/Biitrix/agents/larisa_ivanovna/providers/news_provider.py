"""News-адаптеры Ларисы Ивановны."""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..schemas.news import NewsDigest


class NewsProvider(ABC):
    @abstractmethod
    def get_digest(self, date_msk: str, topics: tuple[str, ...]) -> NewsDigest:
        raise NotImplementedError


class NullNewsProvider(NewsProvider):
    def get_digest(self, date_msk: str, topics: tuple[str, ...]) -> NewsDigest:
        return NewsDigest(
            date_msk=date_msk,
            topics=topics,
            source_available=False,
            limitation="News provider еще не нормализован для контура Ларисы Ивановны.",
        )
