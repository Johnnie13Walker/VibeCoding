"""Календарные адаптеры Ларисы Ивановны."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict
from typing import Any

from cloudbot.skills.create_bitrix_event import run as run_create_bitrix_event
from cloudbot.skills.get_bitrix_calendar import run as run_get_bitrix_calendar

from ..schemas.calendar import CalendarDaySnapshot, CreateCalendarEventInput


class CalendarProvider(ABC):
    @abstractmethod
    def get_day_snapshot(self, date_msk: str) -> CalendarDaySnapshot:
        raise NotImplementedError

    @abstractmethod
    def create_event(self, payload: CreateCalendarEventInput) -> dict[str, Any]:
        raise NotImplementedError


class NullCalendarProvider(CalendarProvider):
    def get_day_snapshot(self, date_msk: str) -> CalendarDaySnapshot:
        return CalendarDaySnapshot(
            date_msk=date_msk,
            source_available=False,
            limitation="Календарный provider еще не подключен к контуру Ларисы Ивановны.",
        )

    def create_event(self, payload: CreateCalendarEventInput) -> dict[str, Any]:
        return {
            "created": False,
            "event": None,
            "limitation": "Создание встреч недоступно, пока календарный provider не подключен.",
        }


class CalendarSkillProvider(CalendarProvider):
    def get_day_snapshot(self, date_msk: str) -> CalendarDaySnapshot:
        try:
            run_get_bitrix_calendar({"date_msk": date_msk, "timezone": "Europe/Moscow"}, {})
        except Exception as error:  # noqa: BLE001
            return CalendarDaySnapshot(
                date_msk=date_msk,
                source_available=False,
                limitation=f"Ошибка calendar skill: {error}",
            )

        return CalendarDaySnapshot(
            date_msk=date_msk,
            source_available=False,
            limitation=(
                "Calendar skill найден, но нормализация встреч для Ларисы Ивановны "
                "пока не реализована."
            ),
        )

    def create_event(self, payload: CreateCalendarEventInput) -> dict[str, Any]:
        try:
            legacy_result = run_create_bitrix_event(asdict(payload), {})
        except Exception as error:  # noqa: BLE001
            return {
                "created": False,
                "event": None,
                "limitation": f"Ошибка create_bitrix_event: {error}",
            }

        return {
            "created": False,
            "event": None,
            "legacy": legacy_result,
            "limitation": (
                "Создание встречи routed в legacy skill, но его ответ еще не нормализован "
                "под контур Ларисы Ивановны."
            ),
        }
