"""Search-адаптеры Ларисы Ивановны."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from cloudbot.skills.web_search import run as run_web_search


@dataclass(frozen=True)
class SearchResult:
    title: str
    snippet: str
    url: str = ""
    source: str = "search"


@dataclass(frozen=True)
class SearchResponse:
    query: str
    results: tuple[SearchResult, ...] = field(default_factory=tuple)
    source_available: bool = False
    limitation: str | None = None
    legacy: dict[str, Any] | None = None


class SearchProvider(ABC):
    @abstractmethod
    def search(self, query: str) -> SearchResponse:
        raise NotImplementedError


class NullSearchProvider(SearchProvider):
    def search(self, query: str) -> SearchResponse:
        return SearchResponse(
            query=query,
            source_available=False,
            limitation="Search provider еще не подключен к контуру Ларисы Ивановны.",
        )


class WebSearchSkillProvider(SearchProvider):
    def search(self, query: str) -> SearchResponse:
        try:
            legacy_result = run_web_search({"query": query, "timezone": "Europe/Moscow"}, {})
        except Exception as error:  # noqa: BLE001
            return SearchResponse(
                query=query,
                source_available=False,
                limitation=f"Ошибка web_search skill: {error}",
            )

        return SearchResponse(
            query=query,
            source_available=False,
            legacy=legacy_result,
            limitation=(
                "Search skill найден, но его результат пока не нормализован под контур "
                "Ларисы Ивановны."
            ),
        )
