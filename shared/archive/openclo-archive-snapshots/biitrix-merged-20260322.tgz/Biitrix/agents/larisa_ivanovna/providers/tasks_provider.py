"""Task-адаптеры Ларисы Ивановны."""

from __future__ import annotations

from abc import ABC, abstractmethod

from cloudbot.skills.get_todo_tasks import run as run_get_todo_tasks

from ..schemas.task import TaskDaySnapshot


class TasksProvider(ABC):
    @abstractmethod
    def get_day_snapshot(self, date_msk: str) -> TaskDaySnapshot:
        raise NotImplementedError


class NullTasksProvider(TasksProvider):
    def get_day_snapshot(self, date_msk: str) -> TaskDaySnapshot:
        return TaskDaySnapshot(
            date_msk=date_msk,
            source_available=False,
            limitation="Task provider еще не подключен к контуру Ларисы Ивановны.",
        )


class TodoTasksSkillProvider(TasksProvider):
    def get_day_snapshot(self, date_msk: str) -> TaskDaySnapshot:
        try:
            run_get_todo_tasks({"date_msk": date_msk, "timezone": "Europe/Moscow"}, {})
        except Exception as error:  # noqa: BLE001
            return TaskDaySnapshot(
                date_msk=date_msk,
                source_available=False,
                limitation=f"Ошибка todo skill: {error}",
            )

        return TaskDaySnapshot(
            date_msk=date_msk,
            source_available=False,
            limitation=(
                "Todo skill найден, но нормализация списка задач для контура Ларисы Ивановны "
                "пока не реализована."
            ),
        )
