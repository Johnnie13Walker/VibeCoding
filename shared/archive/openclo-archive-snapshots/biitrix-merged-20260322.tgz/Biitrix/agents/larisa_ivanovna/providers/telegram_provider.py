"""Telegram route-адаптеры Ларисы Ивановны."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from ..config import DEFAULT_CONFIG, TelegramRouteConfig


@dataclass(frozen=True)
class TelegramRouteDescription:
    route_key: str
    bot_token_env: str | None
    chat_id_env: str | None
    parse_mode: str


class TelegramProvider(ABC):
    @abstractmethod
    def describe_route(self) -> TelegramRouteDescription:
        raise NotImplementedError

    @abstractmethod
    def send(
        self,
        text: str,
        *,
        chat_id: str = "",
        send_reply: Callable[..., Any] | None = None,
        parse_mode: str | None = None,
    ) -> dict[str, Any]:
        raise NotImplementedError


class NullTelegramProvider(TelegramProvider):
    def describe_route(self) -> TelegramRouteDescription:
        telegram_config = DEFAULT_CONFIG.telegram
        return TelegramRouteDescription(
            route_key=telegram_config.route_key,
            bot_token_env=telegram_config.bot_token_env_candidates[0],
            chat_id_env=telegram_config.chat_id_env_candidates[0],
            parse_mode=telegram_config.parse_mode,
        )

    def send(
        self,
        text: str,
        *,
        chat_id: str = "",
        send_reply: Callable[..., Any] | None = None,
        parse_mode: str | None = None,
    ) -> dict[str, Any]:
        route = self.describe_route()
        return {
            "delivered": False,
            "route_key": route.route_key,
            "chat_id": chat_id,
            "limitation": "Telegram route Ларисы Ивановны не был передан в runtime.",
        }


class SharedTelegramRouteProvider(TelegramProvider):
    def __init__(
        self,
        *,
        env_data: Mapping[str, str] | None = None,
        config: TelegramRouteConfig = DEFAULT_CONFIG.telegram,
    ) -> None:
        self.env_data = {str(key): str(value) for key, value in (env_data or {}).items()}
        self.config = config

    def _resolve_first_env(self, names: tuple[str, ...]) -> tuple[str | None, str]:
        for name in names:
            value = str(self.env_data.get(name) or "").strip()
            if value:
                return name, value
        return None, ""

    def describe_route(self) -> TelegramRouteDescription:
        bot_env, _ = self._resolve_first_env(self.config.bot_token_env_candidates)
        chat_env, _ = self._resolve_first_env(self.config.chat_id_env_candidates)
        return TelegramRouteDescription(
            route_key=self.config.route_key,
            bot_token_env=bot_env,
            chat_id_env=chat_env,
            parse_mode=self.config.parse_mode,
        )

    def send(
        self,
        text: str,
        *,
        chat_id: str = "",
        send_reply: Callable[..., Any] | None = None,
        parse_mode: str | None = None,
    ) -> dict[str, Any]:
        _, env_chat_id = self._resolve_first_env(self.config.chat_id_env_candidates)
        target_chat_id = str(chat_id or env_chat_id).strip()
        route = self.describe_route()

        if send_reply is None or not target_chat_id:
            return {
                "delivered": False,
                "route_key": route.route_key,
                "chat_id": target_chat_id,
                "limitation": (
                    "Для прямой отправки нужен send_reply callback или chat_id существующего "
                    "Telegram-контура."
                ),
            }

        effective_parse_mode = parse_mode or route.parse_mode
        try:
            send_reply(target_chat_id, text, parse_mode=effective_parse_mode)
        except TypeError:
            send_reply(target_chat_id, text)

        return {
            "delivered": True,
            "route_key": route.route_key,
            "chat_id": target_chat_id,
            "parse_mode": effective_parse_mode,
        }
