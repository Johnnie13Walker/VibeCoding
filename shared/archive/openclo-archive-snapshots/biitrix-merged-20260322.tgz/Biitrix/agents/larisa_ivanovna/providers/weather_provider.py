"""Погодные адаптеры Ларисы Ивановны."""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..schemas.brief import WeatherSnapshot


class WeatherProvider(ABC):
    @abstractmethod
    def get_weather(self, date_msk: str, city: str) -> WeatherSnapshot:
        raise NotImplementedError


class NullWeatherProvider(WeatherProvider):
    def get_weather(self, date_msk: str, city: str) -> WeatherSnapshot:
        return WeatherSnapshot(
            city=city,
            summary="Источник погоды не подключен.",
            source_available=False,
            limitation="Weather provider не подтвержден в этом контуре.",
        )
