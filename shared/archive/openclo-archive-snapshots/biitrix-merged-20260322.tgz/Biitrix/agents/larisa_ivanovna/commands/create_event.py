"""Команда создания встречи."""

from __future__ import annotations

from ..config import COMMAND_ALIASES
from ..schemas.calendar import CreateCalendarEventInput
from ..workflows.create_event import CreateEventWorkflowDeps, run_create_event_workflow


def build_command(deps: CreateEventWorkflowDeps) -> dict[str, object]:
    def handler(payload: CreateCalendarEventInput, context: dict[str, object] | None = None) -> dict[str, object]:
        result = run_create_event_workflow(payload, deps)
        return {
            "text": str(result.get("text") or ""),
            "payload": result,
        }

    return {
        "name": "create_event",
        "aliases": COMMAND_ALIASES["create_event"],
        "handler": handler,
    }
