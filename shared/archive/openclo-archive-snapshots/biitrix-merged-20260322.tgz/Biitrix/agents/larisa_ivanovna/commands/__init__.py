"""Registry команд Ларисы Ивановны."""

from .create_event import build_command as build_create_event_command
from .get_day_brief import build_command as build_get_day_brief_command
from .get_news import build_command as build_get_news_command
from .get_weather import build_command as build_get_weather_command
from .plan_day import build_command as build_plan_day_command
from .search import build_command as build_search_command

__all__ = [
    "build_create_event_command",
    "build_get_day_brief_command",
    "build_get_news_command",
    "build_get_weather_command",
    "build_plan_day_command",
    "build_search_command",
]
