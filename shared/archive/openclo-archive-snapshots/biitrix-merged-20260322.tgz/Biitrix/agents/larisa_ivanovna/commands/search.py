"""Команда пользовательского поиска."""

from __future__ import annotations

from ..config import COMMAND_ALIASES
from ..workflows.search import SearchWorkflowDeps, run_search_workflow


def build_command(deps: SearchWorkflowDeps) -> dict[str, object]:
    def handler(payload: dict[str, str], context: dict[str, object] | None = None) -> dict[str, object]:
        result = run_search_workflow(str(payload.get("query") or "").strip(), deps)
        return {
            "text": str(result.get("text") or ""),
            "payload": result,
        }

    return {
        "name": "search",
        "aliases": COMMAND_ALIASES["search"],
        "handler": handler,
    }
