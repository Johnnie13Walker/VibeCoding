"""Команда новостного блока."""

from __future__ import annotations

from ..config import COMMAND_ALIASES, DEFAULT_CONFIG
from ..workflows.news import NewsWorkflowDeps, run_news_workflow


def build_command(deps: NewsWorkflowDeps) -> dict[str, object]:
    def handler(payload: dict[str, object], context: dict[str, object] | None = None) -> dict[str, object]:
        topics_raw = payload.get("topics") or DEFAULT_CONFIG.default_news_topics
        topics = tuple(str(item) for item in topics_raw)
        result = run_news_workflow(
            date_msk=str(payload.get("date_msk") or ""),
            topics=topics,
            deps=deps,
        )
        return {
            "text": str(result.get("text") or ""),
            "payload": result,
        }

    return {
        "name": "get_news",
        "aliases": COMMAND_ALIASES["get_news"],
        "handler": handler,
    }
