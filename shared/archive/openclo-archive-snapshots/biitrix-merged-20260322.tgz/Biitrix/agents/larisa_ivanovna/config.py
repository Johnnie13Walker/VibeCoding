"""Конфигурация и идентичность агента Ларисы Ивановны."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

MSK_TIMEZONE: Final[str] = "Europe/Moscow"

ALLOWED_SCOPES: Final[tuple[str, ...]] = (
    "calendar",
    "tasks",
    "weather",
    "news",
    "search",
    "telegram",
    "day_planning",
)

BLOCKED_SCOPES: Final[tuple[str, ...]] = (
    "crm",
    "deals",
    "sales",
    "sales_analytics",
    "finance",
    "commercial_reporting",
    "devops",
)

COMMAND_ALIASES: Final[dict[str, tuple[str, ...]]] = {
    "get_day_brief": ("/today", "/brief", "/day"),
    "create_event": ("/add-meeting", "/create-event"),
    "get_weather": ("/weather",),
    "get_news": ("/larisa-news",),
    "search": ("/search",),
    "plan_day": ("/plan-day", "/plan"),
}

WEEKDAY_LABELS: Final[dict[int, str]] = {
    0: "понедельник",
    1: "вторник",
    2: "среда",
    3: "четверг",
    4: "пятница",
    5: "суббота",
    6: "воскресенье",
}


@dataclass(frozen=True)
class TelegramRouteConfig:
    route_key: str = "larisa_ivanovna"
    bot_token_env_candidates: tuple[str, ...] = (
        "LARISA_TELEGRAM_BOT_TOKEN",
        "TELEGRAM_BOT_TOKEN",
    )
    chat_id_env_candidates: tuple[str, ...] = (
        "LARISA_TELEGRAM_CHAT_ID",
        "TELEGRAM_CHAT_ID",
    )
    parse_mode: str = "HTML"


@dataclass(frozen=True)
class LarisaIvanovnaConfig:
    agent_id: str = "larisa_ivanovna"
    display_name: str = "Лариса Ивановна"
    timezone: str = MSK_TIMEZONE
    legacy_workflows: tuple[str, ...] = (
        "day_briefing",
        "meetings_summary",
        "tasks_summary",
    )
    default_city: str = "Москва"
    default_news_topics: tuple[str, ...] = ()
    allowed_scopes: tuple[str, ...] = ALLOWED_SCOPES
    blocked_scopes: tuple[str, ...] = BLOCKED_SCOPES
    telegram: TelegramRouteConfig = TelegramRouteConfig()


DEFAULT_CONFIG = LarisaIvanovnaConfig()
