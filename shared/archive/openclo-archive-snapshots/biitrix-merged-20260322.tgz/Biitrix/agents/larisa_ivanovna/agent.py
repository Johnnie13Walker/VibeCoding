"""Точка входа агента Ларисы Ивановны."""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Callable

from .commands import (
    build_create_event_command,
    build_get_day_brief_command,
    build_get_news_command,
    build_get_weather_command,
    build_plan_day_command,
    build_search_command,
)
from .config import DEFAULT_CONFIG, LarisaIvanovnaConfig
from .policy import LarisaIvanovnaPolicy
from .providers import (
    CalendarSkillProvider,
    NullNewsProvider,
    NullWeatherProvider,
    SharedTelegramRouteProvider,
    TodoTasksSkillProvider,
    WebSearchSkillProvider,
)
from .workflows.create_event import CreateEventWorkflowDeps
from .workflows.daily_brief import DailyBriefWorkflowDeps
from .workflows.news import NewsWorkflowDeps
from .workflows.search import SearchWorkflowDeps
from .workflows.weather import WeatherWorkflowDeps


class LarisaIvanovnaAgentError(RuntimeError):
    """Ошибка контура Ларисы Ивановны."""


@dataclass(frozen=True)
class LarisaDependencies:
    calendar_provider: Any
    tasks_provider: Any
    weather_provider: Any
    news_provider: Any
    search_provider: Any
    telegram_provider: Any


class LarisaIvanovnaAgent:
    def __init__(
        self,
        *,
        config: LarisaIvanovnaConfig = DEFAULT_CONFIG,
        dependencies: LarisaDependencies,
    ) -> None:
        self.config = config
        self.policy = LarisaIvanovnaPolicy(config)
        self.dependencies = dependencies
        self.registry = self._build_registry()

    def _build_registry(self) -> dict[str, dict[str, object]]:
        daily_brief_deps = DailyBriefWorkflowDeps(
            calendar_provider=self.dependencies.calendar_provider,
            tasks_provider=self.dependencies.tasks_provider,
            weather_provider=self.dependencies.weather_provider,
            news_provider=self.dependencies.news_provider,
        )
        commands = [
            build_get_day_brief_command(daily_brief_deps),
            build_create_event_command(
                CreateEventWorkflowDeps(
                    calendar_provider=self.dependencies.calendar_provider,
                )
            ),
            build_get_weather_command(
                WeatherWorkflowDeps(
                    weather_provider=self.dependencies.weather_provider,
                )
            ),
            build_get_news_command(
                NewsWorkflowDeps(
                    news_provider=self.dependencies.news_provider,
                )
            ),
            build_search_command(
                SearchWorkflowDeps(
                    search_provider=self.dependencies.search_provider,
                )
            ),
            build_plan_day_command(daily_brief_deps),
        ]

        registry: dict[str, dict[str, object]] = {}
        for command in commands:
            registry[str(command["name"])] = command
            for alias in command["aliases"]:
                registry[str(alias)] = command
        return registry

    def execute(
        self,
        command_name: str,
        payload: Any,
        *,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        command = self.registry.get(str(command_name))
        if command is None:
            raise LarisaIvanovnaAgentError(f"Команда {command_name} не зарегистрирована.")
        handler = command["handler"]
        return handler(payload, context)

    def dispatch_to_telegram(
        self,
        command_name: str,
        payload: Any,
        *,
        context: dict[str, Any] | None = None,
        chat_id: str = "",
        send_reply: Callable[..., Any] | None = None,
    ) -> dict[str, Any]:
        result = self.execute(command_name, payload, context=context)
        delivery = self.dependencies.telegram_provider.send(
            str(result.get("text") or ""),
            chat_id=chat_id,
            send_reply=send_reply,
        )
        return {
            **result,
            "delivery": delivery,
        }


def build_larisa_agent_from_env(env_data: dict[str, str] | None = None) -> LarisaIvanovnaAgent:
    env_payload = dict(env_data or os.environ)
    dependencies = LarisaDependencies(
        calendar_provider=CalendarSkillProvider(),
        tasks_provider=TodoTasksSkillProvider(),
        weather_provider=NullWeatherProvider(),
        news_provider=NullNewsProvider(),
        search_provider=WebSearchSkillProvider(),
        telegram_provider=SharedTelegramRouteProvider(env_data=env_payload),
    )
    return LarisaIvanovnaAgent(
        config=DEFAULT_CONFIG,
        dependencies=dependencies,
    )
