"""Telegram-friendly форматирование brief дня."""

from __future__ import annotations

from ..schemas.brief import DayBrief, FreeWindow
from ..schemas.calendar import CalendarEvent
from ..schemas.task import TaskItem
from .telegram_news import format_telegram_news
from .telegram_weather import format_telegram_weather


def _extract_clock(value: str) -> str:
    if "T" in value:
        return value[11:16]
    return value[:5]


def _format_time_range(start_at_msk: str, end_at_msk: str) -> str:
    return f"{_extract_clock(start_at_msk)}-{_extract_clock(end_at_msk)}"


def _render_meetings(meetings: tuple[CalendarEvent, ...]) -> str:
    if not meetings:
        return "Нет подтвержденных встреч."
    return "\n".join(
        f"- {_format_time_range(item.start_at_msk, item.end_at_msk)} {item.title}"
        for item in meetings
    )


def _render_tasks(tasks_for_today: tuple[TaskItem, ...], overdue_tasks: tuple[TaskItem, ...]) -> str:
    lines: list[str] = []
    if not tasks_for_today:
        lines.append("Сегодня: нет подтвержденных задач.")
    else:
        lines.extend(f"- Сегодня: {item.title}" for item in tasks_for_today)

    if not overdue_tasks:
        lines.append("- Просрочено: нет.")
    else:
        lines.extend(f"- Просрочено: {item.title}" for item in overdue_tasks)
    return "\n".join(lines)


def _render_free_windows(free_windows: tuple[FreeWindow, ...]) -> str:
    if not free_windows:
        return "Свободные окна не рассчитаны."
    return "\n".join(f"- {item.start_at_msk}-{item.end_at_msk}" for item in free_windows)


def format_telegram_brief(brief: DayBrief) -> str:
    lines = [
        f"{brief.date_msk}, {brief.weekday_msk}",
        "",
        f"Фокус дня: {brief.focus}",
        "",
        "Встречи:",
        _render_meetings(brief.meetings),
        "",
        "Задачи:",
        _render_tasks(brief.tasks_for_today, brief.overdue_tasks),
        "",
        "Свободные окна:",
        _render_free_windows(brief.free_windows),
        "",
        "Погода по Москве:",
        format_telegram_weather(brief.weather),
        "",
        "Новости по темам:",
        format_telegram_news(brief.news),
        "",
        "3 действия на день:",
    ]

    if brief.action_items:
        lines.extend(f"- {item}" for item in brief.action_items)
    else:
        lines.append("- Нет подтвержденных действий.")

    if brief.limitations:
        lines.extend(["", "Ограничения:"])
        lines.extend(f"- {item}" for item in brief.limitations)

    return "\n".join(lines)
