"""Telegram-friendly форматирование новостей."""

from __future__ import annotations

from ..schemas.news import NewsDigest


def format_telegram_news(digest: NewsDigest) -> str:
    if not digest.source_available:
        return digest.limitation or "Новостной источник недоступен."

    if not digest.items:
        return "По подтвержденным темам новостей пока нет."

    lines: list[str] = []
    for item in digest.items:
        link_part = f" — {item.url}" if item.url else ""
        lines.append(f"- {item.topic}: {item.title}{link_part}")
    return "\n".join(lines)
