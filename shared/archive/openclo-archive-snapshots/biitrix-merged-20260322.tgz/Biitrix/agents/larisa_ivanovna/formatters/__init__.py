"""Formatter-слой Ларисы Ивановны."""

from .telegram_brief import format_telegram_brief
from .telegram_news import format_telegram_news
from .telegram_weather import format_telegram_weather

__all__ = [
    "format_telegram_brief",
    "format_telegram_news",
    "format_telegram_weather",
]
