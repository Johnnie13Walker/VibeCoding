"""Сборка daily brief Ларисы Ивановны."""

from __future__ import annotations

from dataclasses import dataclass

from ..config import DEFAULT_CONFIG
from ..providers.calendar_provider import CalendarProvider
from ..providers.news_provider import NewsProvider
from ..providers.tasks_provider import TasksProvider
from ..providers.weather_provider import WeatherProvider
from ..schemas.brief import DayBrief, DayBriefRequest, FreeWindow
from ..schemas.calendar import CalendarEvent
from ..schemas.news import NewsDigest


@dataclass(frozen=True)
class DailyBriefWorkflowDeps:
    calendar_provider: CalendarProvider
    tasks_provider: TasksProvider
    weather_provider: WeatherProvider
    news_provider: NewsProvider


def build_day_brief(
    request: DayBriefRequest,
    deps: DailyBriefWorkflowDeps,
) -> DayBrief:
    calendar_snapshot = deps.calendar_provider.get_day_snapshot(request.date_msk)
    task_snapshot = deps.tasks_provider.get_day_snapshot(request.date_msk)
    weather_snapshot = deps.weather_provider.get_weather(request.date_msk, DEFAULT_CONFIG.default_city)
    news_digest = deps.news_provider.get_digest(request.date_msk, request.news_topics)

    free_windows = (
        _calculate_free_windows(calendar_snapshot.meetings)
        if calendar_snapshot.source_available
        else tuple()
    )
    limitations = tuple(
        item
        for item in (
            calendar_snapshot.limitation,
            task_snapshot.limitation,
            weather_snapshot.limitation,
            news_digest.limitation,
        )
        if item
    )

    return DayBrief(
        date_msk=request.date_msk,
        weekday_msk=request.weekday_msk,
        timezone=DEFAULT_CONFIG.timezone,
        meetings=calendar_snapshot.meetings,
        tasks_for_today=task_snapshot.tasks_for_today,
        overdue_tasks=task_snapshot.overdue_tasks,
        free_windows=free_windows,
        weather=weather_snapshot,
        news=news_digest if isinstance(news_digest, NewsDigest) else NewsDigest(date_msk=request.date_msk),
        focus=_build_focus(
            meetings=calendar_snapshot.meetings,
            tasks_for_today=task_snapshot.tasks_for_today,
            overdue_tasks=task_snapshot.overdue_tasks,
            free_windows=free_windows,
        ),
        action_items=_build_action_items(
            meetings=calendar_snapshot.meetings,
            tasks_for_today=task_snapshot.tasks_for_today,
            overdue_tasks=task_snapshot.overdue_tasks,
            free_windows=free_windows,
        ),
        limitations=limitations,
    )


def _calculate_free_windows(
    meetings: tuple[CalendarEvent, ...],
    *,
    day_start: str = "08:00",
    day_end: str = "19:00",
) -> tuple[FreeWindow, ...]:
    if not meetings:
        return (
            FreeWindow(
                start_at_msk=day_start,
                end_at_msk=day_end,
            ),
        )

    sorted_meetings = tuple(
        sorted(meetings, key=lambda item: _to_minutes(_extract_clock(item.start_at_msk)))
    )
    windows: list[FreeWindow] = []
    cursor = _to_minutes(day_start)
    day_end_minutes = _to_minutes(day_end)

    for meeting in sorted_meetings:
        meeting_start = _to_minutes(_extract_clock(meeting.start_at_msk))
        meeting_end = _to_minutes(_extract_clock(meeting.end_at_msk))
        if meeting_start > cursor:
            windows.append(FreeWindow(start_at_msk=_from_minutes(cursor), end_at_msk=_from_minutes(meeting_start)))
        if meeting_end > cursor:
            cursor = meeting_end

    if cursor < day_end_minutes:
        windows.append(FreeWindow(start_at_msk=_from_minutes(cursor), end_at_msk=_from_minutes(day_end_minutes)))

    return tuple(windows)


def _build_focus(
    *,
    meetings: tuple[CalendarEvent, ...],
    tasks_for_today: tuple[object, ...],
    overdue_tasks: tuple[object, ...],
    free_windows: tuple[FreeWindow, ...],
) -> str:
    if not meetings and not tasks_for_today and not overdue_tasks:
        return "Подтвержденных событий мало. День нужно собрать вокруг личных приоритетов."
    if overdue_tasks:
        return f"Сначала закрыть просроченное: {getattr(overdue_tasks[0], 'title', 'без названия')}."
    if meetings:
        return f"День привязан к встрече {_extract_clock(meetings[0].start_at_msk)}: {meetings[0].title}."
    if free_windows:
        return f"Есть окно {free_windows[0].start_at_msk}-{free_windows[0].end_at_msk} для фокусной работы."
    return f"Главный приоритет дня: {getattr(tasks_for_today[0], 'title', 'без названия')}."


def _build_action_items(
    *,
    meetings: tuple[CalendarEvent, ...],
    tasks_for_today: tuple[object, ...],
    overdue_tasks: tuple[object, ...],
    free_windows: tuple[FreeWindow, ...],
) -> tuple[str, ...]:
    items: list[str] = []
    if overdue_tasks:
        items.append(f"Закрыть просроченную задачу: {getattr(overdue_tasks[0], 'title', 'без названия')}.")
    if tasks_for_today:
        items.append(f"Зафиксировать время на задачу: {getattr(tasks_for_today[0], 'title', 'без названия')}.")
    if meetings:
        items.append(f"Подготовиться к встрече {_extract_clock(meetings[0].start_at_msk)}: {meetings[0].title}.")
    elif free_windows:
        items.append(
            f"Использовать окно {free_windows[0].start_at_msk}-{free_windows[0].end_at_msk} для фокусной работы."
        )
    if not items:
        items.append("Уточнить календарь и задачи перед началом дня.")
    return tuple(items[:3])


def _extract_clock(value: str) -> str:
    if "T" in value:
        return value[11:16]
    return value[:5]


def _to_minutes(value: str) -> int:
    hours, minutes = value.split(":", maxsplit=1)
    return int(hours) * 60 + int(minutes)


def _from_minutes(value: int) -> str:
    hours = str(value // 60).zfill(2)
    minutes = str(value % 60).zfill(2)
    return f"{hours}:{minutes}"
