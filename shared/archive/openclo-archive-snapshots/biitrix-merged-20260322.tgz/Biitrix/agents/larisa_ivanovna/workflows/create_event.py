"""Workflow создания встречи."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..providers.calendar_provider import CalendarProvider
from ..schemas.calendar import CreateCalendarEventInput


@dataclass(frozen=True)
class CreateEventWorkflowDeps:
    calendar_provider: CalendarProvider


def run_create_event_workflow(
    payload: CreateCalendarEventInput,
    deps: CreateEventWorkflowDeps,
) -> dict[str, Any]:
    if not payload.title.strip():
        return {
            "text": "Нельзя создать встречу без названия.",
            "created": False,
            "limitation": "Отсутствует обязательное поле title.",
        }
    if not payload.start_at_msk.strip():
        return {
            "text": "Нельзя создать встречу без времени начала.",
            "created": False,
            "limitation": "Отсутствует обязательное поле start_at_msk.",
        }

    result = deps.calendar_provider.create_event(payload)
    if not result.get("created"):
        return {
            "text": str(result.get("limitation") or "Не удалось создать встречу."),
            "created": False,
            "limitation": result.get("limitation"),
            "legacy": result.get("legacy"),
        }

    event = result.get("event")
    return {
        "text": f"Встреча создана: {_extract_clock(event.start_at_msk)} {event.title}.",
        "created": True,
        "event": event,
    }


def _extract_clock(value: str) -> str:
    if "T" in value:
        return value[11:16]
    return value[:5]
