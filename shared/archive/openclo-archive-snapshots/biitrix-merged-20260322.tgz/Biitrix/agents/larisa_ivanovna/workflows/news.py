"""Workflow новостного блока."""

from __future__ import annotations

from dataclasses import dataclass

from ..formatters.telegram_news import format_telegram_news
from ..providers.news_provider import NewsProvider


@dataclass(frozen=True)
class NewsWorkflowDeps:
    news_provider: NewsProvider


def run_news_workflow(
    *,
    date_msk: str,
    topics: tuple[str, ...],
    deps: NewsWorkflowDeps,
) -> dict[str, object]:
    digest = deps.news_provider.get_digest(date_msk, topics)
    return {
        "text": format_telegram_news(digest),
        "digest": digest,
    }
