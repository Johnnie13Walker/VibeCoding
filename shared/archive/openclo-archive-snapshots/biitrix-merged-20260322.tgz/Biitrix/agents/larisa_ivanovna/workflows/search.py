"""Workflow пользовательского поиска."""

from __future__ import annotations

from dataclasses import dataclass

from ..providers.search_provider import SearchProvider


@dataclass(frozen=True)
class SearchWorkflowDeps:
    search_provider: SearchProvider


def run_search_workflow(query: str, deps: SearchWorkflowDeps) -> dict[str, object]:
    response = deps.search_provider.search(query)
    if not response.source_available:
        return {
            "text": response.limitation or "Поиск сейчас недоступен.",
            "response": response,
        }
    if not response.results:
        return {
            "text": "По запросу не найдено подтвержденных результатов.",
            "response": response,
        }

    lines = [f"Результаты поиска по запросу: {response.query}"]
    lines.extend(
        f"- {item.title}{f' — {item.url}' if item.url else ''}"
        for item in response.results[:5]
    )
    return {
        "text": "\n".join(lines),
        "response": response,
    }
