"""Парсер RSS/Atom в единый формат новостных элементов."""

from __future__ import annotations

from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html import unescape
import re
from typing import Any
from xml.etree import ElementTree

HTML_TAG_RE = re.compile(r"<[^>]+>")


def _local_name(tag: str) -> str:
    if "}" in tag:
        return tag.rsplit("}", 1)[1]
    return tag


def _normalize_text(value: str | None) -> str:
    return " ".join(unescape(str(value or "").replace("\xa0", " ")).split())


def _strip_html(value: str | None) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    return _normalize_text(HTML_TAG_RE.sub(" ", raw))


def _first_child_text(node: ElementTree.Element, *names: str) -> str:
    expected = {name.lower() for name in names}
    for child in list(node):
        if _local_name(child.tag).lower() in expected:
            value = "".join(child.itertext()).strip()
            if value:
                return value
    return ""


def _extract_link(node: ElementTree.Element) -> str:
    for child in list(node):
        if _local_name(child.tag).lower() != "link":
            continue
        text_value = (child.text or "").strip()
        if text_value:
            return text_value
        href_value = str(child.attrib.get("href") or "").strip()
        if href_value:
            return href_value
    return ""


def parse_datetime(value: str | None) -> datetime | None:
    raw = str(value or "").strip()
    if not raw:
        return None

    try:
        dt = parsedate_to_datetime(raw)
    except (TypeError, ValueError):
        dt = None

    if dt is None:
        normalized = raw.replace("Z", "+00:00")
        try:
            dt = datetime.fromisoformat(normalized)
        except ValueError:
            return None

    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _to_item(
    *,
    title: str,
    link: str,
    published_raw: str,
    summary: str,
    source_url: str,
    source_name: str,
    category: str,
) -> dict[str, Any] | None:
    clean_title = str(title).strip()
    clean_link = str(link).strip()
    if not clean_title and not clean_link:
        return None

    published_at = parse_datetime(published_raw)
    published_ts = int(published_at.timestamp()) if published_at else 0

    return {
        "title": clean_title or clean_link,
        "link": clean_link,
        "published_raw": str(published_raw or "").strip(),
        "published_at": published_at.isoformat() if published_at else "",
        "published_ts": published_ts,
        "summary": _strip_html(summary),
        "source_url": source_url,
        "source_name": _normalize_text(source_name),
        "category": category,
    }


def _parse_rss_channel(
    channel: ElementTree.Element,
    *,
    source_url: str,
    category: str,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    source_name = _first_child_text(channel, "title")
    for item in list(channel):
        if _local_name(item.tag).lower() != "item":
            continue

        parsed = _to_item(
            title=_first_child_text(item, "title"),
            link=_extract_link(item),
            published_raw=_first_child_text(item, "pubDate", "published", "updated", "date"),
            summary=_first_child_text(item, "description", "summary", "encoded"),
            source_url=source_url,
            source_name=source_name,
            category=category,
        )
        if parsed:
            items.append(parsed)
    return items


def _parse_atom_feed(
    feed: ElementTree.Element,
    *,
    source_url: str,
    category: str,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    source_name = _first_child_text(feed, "title")
    for entry in list(feed):
        if _local_name(entry.tag).lower() != "entry":
            continue

        parsed = _to_item(
            title=_first_child_text(entry, "title"),
            link=_extract_link(entry),
            published_raw=_first_child_text(entry, "published", "updated"),
            summary=_first_child_text(entry, "summary", "content"),
            source_url=source_url,
            source_name=source_name,
            category=category,
        )
        if parsed:
            items.append(parsed)
    return items


def parse_feed(xml_payload: str | bytes, *, source_url: str, category: str) -> list[dict[str, Any]]:
    if isinstance(xml_payload, bytes):
        payload = xml_payload.decode("utf-8", errors="replace")
    else:
        payload = xml_payload

    root = ElementTree.fromstring(payload)
    root_name = _local_name(root.tag).lower()

    if root_name == "feed":
        return _parse_atom_feed(root, source_url=source_url, category=category)

    channel = None
    for child in list(root):
        if _local_name(child.tag).lower() == "channel":
            channel = child
            break

    if channel is None:
        channel = root

    return _parse_rss_channel(channel, source_url=source_url, category=category)
