"""News Agent: сбор, фильтрация и форматирование новостного дайджеста."""

from __future__ import annotations

__all__ = ["NewsAgent", "NewsAgentError"]


def __getattr__(name: str):
    if name in {"NewsAgent", "NewsAgentError"}:
        from .news_agent import NewsAgent, NewsAgentError

        return {"NewsAgent": NewsAgent, "NewsAgentError": NewsAgentError}[name]
    raise AttributeError(name)
