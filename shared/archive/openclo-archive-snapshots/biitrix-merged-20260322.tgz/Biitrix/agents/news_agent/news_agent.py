"""Главный агент новостей: RSS -> фильтрация -> перевод -> Telegram."""

from __future__ import annotations

import argparse
import json
import os
import sys
from time import time
from typing import Any, Mapping
from urllib.request import Request, urlopen

from .news_fetcher import DEFAULT_RSS_SOURCES, RSSNewsFetcher
from .news_filter import (
    DEFAULT_MAX_AGE_HOURS,
    DEFAULT_NEWS_PER_CATEGORY,
    deduplicate_news,
    filter_non_promotional_news,
    filter_recent_news,
    pick_fresh_news_by_category,
)
from .news_formatter import (
    MockRuTranslator,
    OpenAIHeadlineTranslator,
    TranslationError,
    apply_translation,
    format_digest_message,
    format_digest_messages,
)
from .runtime_support import append_news_log

DEFAULT_CATEGORY_ORDER = [
    "AI",
    "Cloud / DevOps",
    "Marketing / SEO",
]


class NewsAgentError(RuntimeError):
    """Ошибка подготовки или отправки новостей."""


def _to_env_dict(env: Mapping[str, str] | None = None) -> dict[str, str]:
    if env is None:
        return dict(os.environ)
    return {str(key): str(value) for key, value in env.items()}


class NewsAgent:
    def __init__(
        self,
        *,
        sources: Mapping[str, list[str]] | None = None,
        fetcher: RSSNewsFetcher | None = None,
        translator: Any | None = None,
        fetch_article_text: bool = True,
        per_category_limit: int = DEFAULT_NEWS_PER_CATEGORY,
        max_title_len: int = 90,
        max_age_hours: int = DEFAULT_MAX_AGE_HOURS,
        now_ts: int | None = None,
        category_order: list[str] | None = None,
    ) -> None:
        self.sources = dict(sources or DEFAULT_RSS_SOURCES)
        self.fetcher = fetcher or RSSNewsFetcher()
        self.translator = translator
        self.fetch_article_text = bool(fetch_article_text)
        self.per_category_limit = int(per_category_limit)
        self.max_title_len = int(max_title_len)
        self.max_age_hours = int(max_age_hours)
        self.now_ts = int(now_ts or time())
        self.category_order = list(category_order or DEFAULT_CATEGORY_ORDER)

    @classmethod
    def from_env(
        cls,
        env: Mapping[str, str] | None = None,
        *,
        per_category_limit: int | None = None,
        translation_mode: str | None = None,
    ) -> "NewsAgent":
        env_data = _to_env_dict(env)
        fetcher = RSSNewsFetcher.from_env(env_data)

        selected_mode = str(
            translation_mode or env_data.get("NEWS_TRANSLATION_MODE") or "openai"
        ).strip().lower()

        if selected_mode == "mock":
            translator = MockRuTranslator()
        elif selected_mode == "openai":
            translator = OpenAIHeadlineTranslator(
                api_key=env_data.get("OPENAI_API_KEY", ""),
                model=env_data.get("NEWS_TRANSLATION_MODEL", "gpt-4o-mini"),
                timeout_sec=int(env_data.get("NEWS_TRANSLATION_TIMEOUT_SEC", "45")),
                batch_size=int(env_data.get("NEWS_TRANSLATION_BATCH_SIZE", "3")),
            )
        else:
            raise NewsAgentError(
                "Неизвестный NEWS_TRANSLATION_MODE. Поддерживаются: openai, mock."
            )

        effective_limit = int(
            env_data.get(
                "NEWS_PER_CATEGORY_LIMIT",
                env_data.get("NEWS_LIMIT", per_category_limit or DEFAULT_NEWS_PER_CATEGORY),
            )
        )
        max_title_len = int(env_data.get("NEWS_TITLE_MAX_LEN", "90"))
        max_age_hours = int(env_data.get("NEWS_MAX_AGE_HOURS", str(DEFAULT_MAX_AGE_HOURS)))
        now_ts = int(env_data.get("NEWS_NOW_TS", str(int(time()))))
        fetch_article_text = str(
            env_data.get("NEWS_FETCH_ARTICLE_TEXT", env_data.get("NEWS_ARTICLE_FETCH_ENABLED", "1"))
        ).strip() != "0"

        return cls(
            fetcher=fetcher,
            translator=translator,
            fetch_article_text=fetch_article_text,
            per_category_limit=effective_limit,
            max_title_len=max_title_len,
            max_age_hours=max_age_hours,
            now_ts=now_ts,
        )

    def build_digest(self) -> dict[str, Any]:
        started_at = time()
        append_news_log(
            "digest_start",
            categories=self.category_order,
            per_category_limit=self.per_category_limit,
        )
        active_sources = {
            category: list(self.sources.get(category) or [])
            for category in self.category_order
            if self.sources.get(category)
        }
        fetched = self.fetcher.fetch(active_sources)
        cache_hit = bool(fetched.get("cached"))
        raw_items = fetched["items"]
        deduplicated = deduplicate_news(raw_items)
        recent = filter_recent_news(
            deduplicated,
            now_ts=self.now_ts,
            max_age_hours=self.max_age_hours,
        )
        filtered = filter_non_promotional_news(recent)
        grouped_selected = pick_fresh_news_by_category(
            filtered,
            category_order=self.category_order,
            per_category_limit=self.per_category_limit,
        )
        selected = [
            item
            for category in self.category_order
            for item in grouped_selected.get(category, [])
        ]
        selected, article_errors = self.fetcher.enrich_articles(
            selected,
            enabled=self.fetch_article_text,
        )
        if fetched["errors"]:
            append_news_log("digest_rss_warnings", warnings=fetched["errors"])
        if article_errors:
            append_news_log("digest_article_warnings", warnings=article_errors)

        if not selected:
            if fetched["errors"]:
                append_news_log(
                    "digest_error",
                    error="Не удалось получить новости: все источники вернули ошибки.",
                    cache_hit=cache_hit,
                )
                raise NewsAgentError(
                    "Не удалось получить новости: все источники вернули ошибки."
                )
            append_news_log(
                "digest_error",
                error="Не найдено свежих новостей за последние 24 часа.",
                cache_hit=cache_hit,
            )
            raise NewsAgentError("Не найдено свежих новостей за последние 24 часа.")

        if self.translator is None:
            raise NewsAgentError("Не настроен переводчик заголовков")

        try:
            translated = apply_translation(
                selected,
                translator=self.translator,
                max_title_len=self.max_title_len,
            )
        except TranslationError as error:
            append_news_log("digest_error", error=str(error), cache_hit=cache_hit)
            raise NewsAgentError(f"Не удалось перевести новости на русский язык: {error}") from error

        translated_by_key = {
            (str(item.get("category")), str(item.get("link")), int(item.get("published_ts") or 0)): item
            for item in translated
        }
        grouped: dict[str, list[dict[str, Any]]] = {}
        for category in self.category_order:
            grouped[category] = []
            for item in grouped_selected.get(category, []):
                key = (str(item.get("category")), str(item.get("link")), int(item.get("published_ts") or 0))
                translated_item = translated_by_key.get(key, dict(item))
                grouped[category].append(translated_item)

        digest_text = format_digest_message(grouped, category_order=self.category_order)
        digest_chunks = format_digest_messages(grouped, category_order=self.category_order)
        generation_ms = int((time() - started_at) * 1000)
        append_news_log(
            "digest_generated",
            generation_ms=generation_ms,
            total_selected=len(translated),
            total_raw=len(raw_items),
            cache_hit=cache_hit,
        )

        return {
            "message": digest_text,
            "message_chunks": digest_chunks,
            "items": translated,
            "grouped_items": grouped,
            "sources": self.sources,
            "fetch_errors": fetched["errors"],
            "article_errors": article_errors,
            "cache_hit": cache_hit,
            "generation_ms": generation_ms,
            "total_raw": len(raw_items),
            "total_unique": len(deduplicated),
            "total_recent": len(recent),
            "total_non_promotional": len(filtered),
            "total_selected": len(translated),
            "total_article_enriched": sum(1 for item in translated if str(item.get("article_text") or "").strip()),
            "per_category_limit": self.per_category_limit,
        }

    def send_to_telegram(
        self,
        *,
        text: str,
        texts: list[str] | None = None,
        chat_id: str | None = None,
        env: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        env_data = _to_env_dict(env)
        dry_run = env_data.get("NEWS_TELEGRAM_DRY_RUN") == "1" or env_data.get("TELEGRAM_DRY_RUN") == "1"
        payload_texts = [chunk for chunk in (texts or [text]) if str(chunk or "").strip()]

        target_chat_id = str(chat_id or env_data.get("TELEGRAM_CHAT_ID") or "").strip()
        if not target_chat_id:
            raise NewsAgentError("Не задан TELEGRAM_CHAT_ID для отправки новостей")

        if dry_run:
            append_news_log("telegram_send_dry_run", chat_id=target_chat_id, messages_total=len(payload_texts))
            return {
                "status": "dry_run",
                "chat_id": target_chat_id,
                "messages_total": len(payload_texts),
            }

        bot_token = str(env_data.get("TELEGRAM_BOT_TOKEN") or "").strip()
        if not bot_token:
            raise NewsAgentError("Не задан TELEGRAM_BOT_TOKEN для отправки новостей")

        api_base = str(env_data.get("TELEGRAM_API_BASE_URL") or "https://api.telegram.org").strip()
        endpoint = f"{api_base.rstrip('/')}/bot{bot_token}/sendMessage"
        payloads: list[dict[str, Any]] = []

        for chunk in payload_texts:
            body = json.dumps(
                {
                    "chat_id": target_chat_id,
                    "text": chunk,
                    "disable_web_page_preview": True,
                    "parse_mode": "HTML",
                },
                ensure_ascii=False,
            ).encode("utf-8")

            request = Request(
                endpoint,
                method="POST",
                data=body,
                headers={"Content-Type": "application/json"},
            )

            try:
                with urlopen(request, timeout=15) as response:  # noqa: S310
                    raw = response.read().decode("utf-8", errors="replace")
            except Exception as error:  # noqa: BLE001
                raise NewsAgentError(f"Ошибка отправки в Telegram: {error}") from error

            try:
                payload = json.loads(raw)
            except json.JSONDecodeError:
                payload = {}

            if payload.get("ok") is not True:
                description = payload.get("description") or "unknown error"
                append_news_log("telegram_send_error", error=description, chat_id=target_chat_id)
                raise NewsAgentError(f"Telegram sendMessage failed: {description}")
            payloads.append(payload)

        append_news_log("telegram_send_ok", chat_id=target_chat_id, messages_total=len(payload_texts))
        return {
            "status": "sent",
            "chat_id": target_chat_id,
            "messages_total": len(payload_texts),
            "payloads": payloads,
        }

    def run(self, *, send: bool = False, chat_id: str | None = None) -> dict[str, Any]:
        result = self.build_digest()
        if not send:
            return result

        telegram_result = self.send_to_telegram(
            text=result["message"],
            texts=result.get("message_chunks"),
            chat_id=chat_id,
        )
        result["telegram"] = telegram_result
        return result


def build_news_digest_from_env(
    env: Mapping[str, str] | None = None,
    *,
    per_category_limit: int | None = None,
) -> dict[str, Any]:
    agent = NewsAgent.from_env(env=env, per_category_limit=per_category_limit)
    return agent.build_digest()


def _build_cli_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="News Agent Cloudbot")
    parser.add_argument("--send", action="store_true", help="Отправить дайджест в Telegram")
    parser.add_argument("--chat-id", default="", help="Явный chat_id для Telegram")
    parser.add_argument(
        "--per-category-limit",
        type=int,
        default=DEFAULT_NEWS_PER_CATEGORY,
        help="Лимит новостей на категорию (3-5)",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Совместимость со старым интерфейсом. Используется как лимит на категорию.",
    )
    parser.add_argument(
        "--translation-mode",
        default="",
        choices=["", "openai", "mock"],
        help="Режим перевода (openai|mock). По умолчанию берется NEWS_TRANSLATION_MODE или openai.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_cli_parser()
    args = parser.parse_args(argv)

    try:
        effective_limit = args.limit if args.limit is not None else args.per_category_limit
        agent = NewsAgent.from_env(
            os.environ,
            per_category_limit=effective_limit,
            translation_mode=args.translation_mode or None,
        )
        result = agent.run(send=args.send, chat_id=args.chat_id or None)
    except Exception as error:  # noqa: BLE001
        print(f"NEWS AGENT ERROR: {error}", file=sys.stderr)
        return 1

    print(result["message"])
    print("\nИсточники:")
    for category in DEFAULT_CATEGORY_ORDER:
        print(category)
        for source in result["sources"].get(category, []):
            print(f"- {source}")

    if result.get("fetch_errors"):
        print("\nПредупреждения по RSS:")
        for row in result["fetch_errors"]:
            print(f"- {row['category']}: {row['source_url']} -> {row['error']}")

    if result.get("article_errors"):
        print("\nПредупреждения по статьям:")
        for row in result["article_errors"]:
            print(f"- {row['link']} -> {row['error']}")

    if args.send:
        telegram_status = (result.get("telegram") or {}).get("status") or "unknown"
        print(f"\nTelegram: {telegram_status}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
