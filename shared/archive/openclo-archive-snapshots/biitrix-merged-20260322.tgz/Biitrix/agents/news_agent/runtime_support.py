"""Вспомогательные функции news_agent: логирование и файловые runtime-пути."""

from __future__ import annotations

from datetime import datetime
import json
from pathlib import Path
from typing import Any, Mapping
from zoneinfo import ZoneInfo

REPO_ROOT = Path(__file__).resolve().parents[2]
MOSCOW_TZ = ZoneInfo("Europe/Moscow")
DEFAULT_NEWS_CACHE_FILE = REPO_ROOT / "cache" / "news_cache.json"
DEFAULT_NEWS_LOG_FILE = REPO_ROOT / "logs" / "news_agent.log"


def read_json_dict(path: Path) -> dict[str, Any]:
    file_path = Path(path)
    if not file_path.exists():
        return {}

    try:
        raw = json.loads(file_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}

    if not isinstance(raw, dict):
        return {}
    return raw


def write_json_dict(path: Path, payload: Mapping[str, Any]) -> None:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(
        json.dumps(dict(payload), ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )


def append_news_log(event: str, **payload: Any) -> None:
    record = {
        "ts_msk": datetime.now(MOSCOW_TZ).isoformat(timespec="seconds"),
        "event": str(event),
        **payload,
    }
    DEFAULT_NEWS_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with DEFAULT_NEWS_LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, default=str))
        handle.write("\n")
