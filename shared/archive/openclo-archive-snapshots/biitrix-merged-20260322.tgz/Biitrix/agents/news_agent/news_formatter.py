"""Перевод, сводка и форматирование новостного дайджеста."""

from __future__ import annotations

from html import escape
import json
import re
from typing import Any, Iterable, Protocol
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

from .news_filter import shorten_headline

OPENAI_CHAT_COMPLETIONS_URL = "https://api.openai.com/v1/chat/completions"
TELEGRAM_TEXT_LIMIT = 3800
DEFAULT_SUMMARY_SENTENCES = 4
SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
CYRILLIC_RE = re.compile(r"[А-Яа-яЁё]")


class TranslationError(RuntimeError):
    """Ошибка локализации новостей."""


class HeadlineTranslator(Protocol):
    def localize_many(self, items: list[dict[str, Any]]) -> list[dict[str, str]]:
        """Локализует новости и формирует краткие сводки."""


def _normalize_text(value: str | None) -> str:
    return " ".join(str(value or "").replace("\xa0", " ").split())


def _split_sentences(text: str | None) -> list[str]:
    prepared = _normalize_text(text)
    if not prepared:
        return []
    return [part.strip() for part in SENTENCE_SPLIT_RE.split(prepared) if part.strip()]


def _ensure_sentence(text: str | None) -> str:
    prepared = _normalize_text(text)
    if not prepared:
        return ""
    if prepared[-1] not in ".!?":
        return f"{prepared}."
    return prepared


def _domain_label(url: str | None) -> str:
    host = urlsplit(str(url or "").strip()).netloc.lower()
    if host.startswith("www."):
        host = host[4:]
    return host or "первоисточник"


def _source_label(item: dict[str, Any]) -> str:
    link_domain = _domain_label(item.get("link"))
    if link_domain != "первоисточник":
        return link_domain
    source_name = _normalize_text(item.get("source_name"))
    if source_name:
        return source_name
    return _domain_label(item.get("source_url"))


def _fallback_summary(item: dict[str, Any], *, title_ru: str | None = None) -> str:
    title = _normalize_text(title_ru or item.get("title_ru") or item.get("title"))
    source_name = _source_label(item)
    category = _normalize_text(item.get("category")) or "общая"
    raw_summary = _normalize_text(item.get("summary"))
    article_text = _normalize_text(item.get("article_text"))

    sentences: list[str] = []
    if title:
        sentences.append(_ensure_sentence(f"Материал {source_name} посвящен теме «{title}»"))

    detail_source = article_text if CYRILLIC_RE.search(article_text) else raw_summary
    if CYRILLIC_RE.search(detail_source):
        for candidate in _split_sentences(detail_source):
            normalized = _ensure_sentence(candidate)
            if normalized and normalized not in sentences:
                sentences.append(normalized)
            if len(sentences) >= DEFAULT_SUMMARY_SENTENCES:
                break

    fallback_tail = [
        _ensure_sentence(
            f"Публикация попала в свежую выборку по категории {category} за последние 24 часа"
        ),
        _ensure_sentence("В дайджесте оставлен только первоисточник без рекламных и повторяющихся публикаций"),
        _ensure_sentence("В дайджест включен первоисточник, чтобы можно было быстро перейти к полному тексту"),
        _ensure_sentence("Если в RSS мало деталей, дополнительный контекст лучше смотреть уже в самой статье"),
    ]
    for candidate in fallback_tail:
        if candidate not in sentences:
            sentences.append(candidate)
        if len(sentences) >= DEFAULT_SUMMARY_SENTENCES:
            break

    return " ".join(sentences[:DEFAULT_SUMMARY_SENTENCES])


def _extract_json_array(raw_text: str) -> list[dict[str, str]]:
    text = str(raw_text or "").strip()
    if text.startswith("```"):
        text = text.strip("`").strip()
        if text.startswith("json"):
            text = text[4:].strip()

    candidates = [text]
    start_idx = text.find("[")
    end_idx = text.rfind("]")
    if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
        candidates.append(text[start_idx : end_idx + 1])

    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if not isinstance(parsed, list):
            continue

        normalized: list[dict[str, str]] = []
        for item in parsed:
            if not isinstance(item, dict):
                break
            title_ru = _normalize_text(item.get("title_ru"))
            summary_ru = _normalize_text(item.get("summary_ru"))
            normalized.append({"title_ru": title_ru, "summary_ru": summary_ru})
        else:
            return normalized

    raise TranslationError("OpenAI вернул невалидный формат локализации")


class OpenAIHeadlineTranslator:
    def __init__(
        self,
        *,
        api_key: str,
        model: str = "gpt-4o-mini",
        timeout_sec: int = 25,
        batch_size: int = 3,
        api_url: str = OPENAI_CHAT_COMPLETIONS_URL,
    ) -> None:
        self.api_key = str(api_key or "").strip()
        self.model = str(model or "gpt-4o-mini").strip()
        self.timeout_sec = int(timeout_sec)
        self.batch_size = max(int(batch_size), 1)
        self.api_url = str(api_url).strip()

        if not self.api_key:
            raise TranslationError("Не задан OPENAI_API_KEY для перевода новостей")

    def _localize_batch(self, items: list[dict[str, Any]]) -> list[dict[str, str]]:
        prompt_items = []
        for item in items:
            prompt_items.append(
                {
                    "title": _normalize_text(item.get("title")),
                    "summary": _normalize_text(item.get("summary"))[:900],
                    "article_text": _normalize_text(item.get("article_text"))[:1800],
                    "source_name": _source_label(item),
                    "category": _normalize_text(item.get("category")),
                }
            )

        system_prompt = (
            "Ты редактор русскоязычного новостного дайджеста. "
            "Для каждой новости переведи заголовок на русский язык и напиши краткую сводку в 4-5 коротких предложениях. "
            "Главный источник фактов — article_text, затем summary. "
            "Опирайся только на переданные title/summary/article_text/source_name/category. "
            "Не выдумывай факты, которых нет во входных данных. "
            "Если article_text и summary бедные, честно укажи, что в источнике мало деталей."
        )
        user_prompt = (
            "Верни строго JSON-массив объектов той же длины. "
            "У каждого объекта должны быть ключи title_ru и summary_ru.\n"
            f"{json.dumps(prompt_items, ensure_ascii=False)}"
        )

        body = {
            "model": self.model,
            "temperature": 0.2,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": (
                        "Оберни итог в JSON-объект с ключом items, "
                        "где items — это массив локализованных новостей.\n"
                        f"{user_prompt}"
                    ),
                },
            ],
        }
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")

        request = Request(
            self.api_url,
            method="POST",
            data=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
        )

        try:
            with urlopen(request, timeout=self.timeout_sec) as response:  # noqa: S310
                raw = response.read().decode("utf-8", errors="replace")
        except Exception as error:  # noqa: BLE001
            raise TranslationError(f"Ошибка запроса к OpenAI: {error}") from error

        try:
            decoded = json.loads(raw)
            message = decoded["choices"][0]["message"]["content"]
            payload_obj = json.loads(message)
            localized_raw = payload_obj["items"]
        except (json.JSONDecodeError, KeyError, IndexError, TypeError) as error:
            raise TranslationError("OpenAI вернул неожиданный ответ на локализацию") from error

        localized = _extract_json_array(json.dumps(localized_raw, ensure_ascii=False))
        if len(localized) != len(items):
            raise TranslationError("Количество локализованных новостей не совпадает с исходным списком")
        return localized

    def localize_many(self, items: list[dict[str, Any]]) -> list[dict[str, str]]:
        if not items:
            return []

        localized: list[dict[str, str]] = []
        for start_idx in range(0, len(items), self.batch_size):
            localized.extend(self._localize_batch(items[start_idx : start_idx + self.batch_size]))
        return localized


class MockRuTranslator:
    """Тестовый локализатор без сетевых запросов."""

    def localize_many(self, items: list[dict[str, Any]]) -> list[dict[str, str]]:
        localized: list[dict[str, str]] = []
        for item in items:
            title_ru = f"Перевод: {_normalize_text(item.get('title'))}"
            localized.append(
                {
                    "title_ru": title_ru,
                    "summary_ru": _fallback_summary(item, title_ru=title_ru),
                }
            )
        return localized


def apply_translation(
    items: Iterable[dict[str, Any]],
    *,
    translator: HeadlineTranslator,
    max_title_len: int = 90,
) -> list[dict[str, Any]]:
    prepared = [dict(item) for item in items]
    localized = translator.localize_many(prepared)

    if len(localized) != len(prepared):
        raise TranslationError("Невозможно сопоставить локализацию с исходными новостями")

    for idx, item in enumerate(prepared):
        title_ru = _normalize_text(localized[idx].get("title_ru")) or _normalize_text(item.get("title"))
        summary_ru = _normalize_text(localized[idx].get("summary_ru")) or _fallback_summary(
            item,
            title_ru=title_ru,
        )
        item["title_ru"] = title_ru
        item["display_title"] = shorten_headline(title_ru, max_len=max_title_len)
        item["summary_ru"] = summary_ru
        item["source_label"] = _source_label(item)

    return prepared


def _render_item_block(item: dict[str, Any]) -> str:
    title = item.get("display_title") or item.get("title_ru") or item.get("title") or "Без заголовка"
    summary = _normalize_text(item.get("summary_ru")) or _fallback_summary(item)
    source_label = item.get("source_label") or _source_label(item)
    link = _normalize_text(item.get("link"))

    lines = [
        f"— <b>{escape(str(title))}</b>",
        f"Кратко: {escape(str(summary))}",
        f"Источник: {escape(str(source_label))}",
    ]
    if link:
        lines.append(f"Ссылка: {escape(str(link))}")
    return "\n".join(lines)


def format_digest_messages(
    grouped_news: dict[str, list[dict[str, Any]]],
    *,
    category_order: list[str],
    telegram_limit: int = TELEGRAM_TEXT_LIMIT,
) -> list[str]:
    header = "<b>📰 Новости сегодня</b>"
    continuation_header = "<b>📰 Новости сегодня (продолжение)</b>"
    messages: list[str] = []
    current = header

    def append_block(block: str, *, retry_block: str | None = None) -> bool:
        nonlocal current
        candidate = f"{current}\n\n{block}".strip()
        if len(candidate) <= telegram_limit:
            current = candidate
            return False

        if current.strip() in {header, continuation_header}:
            current = candidate
            return False

        messages.append(current.strip())
        current = f"{continuation_header}\n\n{retry_block or block}".strip()
        return True

    for category in category_order:
        rows = grouped_news.get(category) or []
        if not rows:
            append_block(f"<b>{escape(str(category))}</b>\n— нет свежих новостей")
            continue

        first_item_in_category = True
        for item in rows:
            item_block = _render_item_block(item)
            block_with_header = f"<b>{escape(str(category))}</b>\n{item_block}"
            block = block_with_header if first_item_in_category else item_block
            append_block(block, retry_block=block_with_header)
            first_item_in_category = False

    if current.strip():
        messages.append(current.strip())

    return messages


def format_digest_message(
    grouped_news: dict[str, list[dict[str, Any]]],
    *,
    category_order: list[str],
) -> str:
    return "\n\n".join(format_digest_messages(grouped_news, category_order=category_order))
