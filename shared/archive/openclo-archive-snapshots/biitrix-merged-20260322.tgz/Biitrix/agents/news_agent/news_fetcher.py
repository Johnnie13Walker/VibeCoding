"""Загрузка RSS-источников для News Agent."""

from __future__ import annotations

import json
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from time import time
from typing import Any, Mapping
from urllib.request import Request, urlopen

from .news_filter import normalize_url
from .runtime_support import DEFAULT_NEWS_CACHE_FILE, append_news_log, read_json_dict, write_json_dict
from .rss_parser import parse_feed

AI_PRIMARY_RSS_SOURCES = [
    "https://venturebeat.com/category/ai/feed/",
]
AI_BACKUP_RSS_SOURCES = [
    "https://openai.com/blog/rss.xml",
    "https://the-decoder.com/feed/",
    "https://www.theverge.com/rss/ai/index.xml",
]
DEFAULT_RSS_SOURCES: dict[str, list[str]] = {
    "AI": AI_PRIMARY_RSS_SOURCES + AI_BACKUP_RSS_SOURCES,
    "Web Development": [
        "https://css-tricks.com/feed/",
        "https://web.dev/feed.xml",
        "https://dev.to/feed",
        "https://stackoverflow.blog/feed/",
    ],
    "Cloud / DevOps": [
        "https://thenewstack.io/feed/",
        "https://devops.com/feed/",
        "https://www.docker.com/blog/feed/",
        "https://kubernetes.io/feed.xml",
    ],
    "Marketing / SEO": [
        "https://searchengineland.com/feed",
        "https://moz.com/blog/feed",
    ],
}

DEFAULT_TIMEOUT_SEC = 12
DEFAULT_ARTICLE_TIMEOUT_SEC = 12
DEFAULT_USER_AGENT = "CloudbotNewsAgent/1.0 (+https://cloudbot.local)"
DEFAULT_ARTICLE_TEXT_LIMIT = 6000
DEFAULT_CACHE_TTL_SEC = 60 * 60
CACHE_FORMAT_VERSION = 1

TEXT_TAGS = {"p", "li", "blockquote", "h2", "h3", "h4"}
SKIP_TAGS = {"script", "style", "noscript", "svg", "iframe", "canvas"}
NOISY_CONTAINER_TAGS = {"nav", "footer", "header", "aside", "form"}
FALLBACK_RSS_SOURCES_BY_CATEGORY: dict[str, set[str]] = {
    "AI": set(AI_BACKUP_RSS_SOURCES),
}
MIN_SOURCE_ITEMS_BEFORE_FALLBACK: dict[str, int] = {
    "AI": 6,
}


def _read_fixture_sections(path: Path) -> tuple[dict[str, str], dict[str, str]]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(raw, dict) and isinstance(raw.get("feeds"), dict):
        feed_payload = raw["feeds"]
        article_payload = raw.get("articles") or {}
    else:
        feed_payload = raw
        article_payload = {}

    if not isinstance(feed_payload, dict):
        raise ValueError("Файл фикстур NEWS_RSS_FIXTURES_FILE должен содержать объект URL -> XML")

    feed_fixtures: dict[str, str] = {}
    for key, value in feed_payload.items():
        url = str(key).strip()
        xml = str(value or "").strip()
        if not url or not xml:
            continue
        feed_fixtures[url] = xml

    article_fixtures: dict[str, str] = {}
    if isinstance(article_payload, dict):
        for key, value in article_payload.items():
            url = normalize_url(str(key).strip())
            html = str(value or "").strip()
            if not url or not html:
                continue
            article_fixtures[url] = html

    return feed_fixtures, article_fixtures


def _normalize_text(value: str | None) -> str:
    return " ".join(unescape(str(value or "").replace("\xa0", " ")).split())


class ArticleTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.skip_depth = 0
        self.noisy_depth = 0
        self.in_body = False
        self.current_tag: str | None = None
        self.current_parts: list[str] = []
        self.blocks: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        lower = tag.lower()
        if lower == "body":
            self.in_body = True
        if lower in SKIP_TAGS:
            self.skip_depth += 1
            return
        if lower in NOISY_CONTAINER_TAGS:
            self.noisy_depth += 1
            return
        if self.skip_depth or self.noisy_depth or not self.in_body:
            return
        if lower in TEXT_TAGS:
            self.current_tag = lower
            self.current_parts = []

    def handle_endtag(self, tag: str) -> None:
        lower = tag.lower()
        if lower == "body":
            self.in_body = False
        if lower in SKIP_TAGS and self.skip_depth:
            self.skip_depth -= 1
            return
        if lower in NOISY_CONTAINER_TAGS and self.noisy_depth:
            self.noisy_depth -= 1
            return
        if lower == self.current_tag:
            text = _normalize_text(" ".join(self.current_parts))
            if text and text not in self.blocks:
                self.blocks.append(text)
            self.current_tag = None
            self.current_parts = []

    def handle_data(self, data: str) -> None:
        if self.skip_depth or self.noisy_depth or not self.in_body or self.current_tag is None:
            return
        text = _normalize_text(data)
        if text:
            self.current_parts.append(text)

    def extract(self, limit: int) -> str:
        selected: list[str] = []
        total_len = 0
        for block in self.blocks:
            if len(block) < 40:
                continue
            candidate_len = total_len + len(block) + (2 if selected else 0)
            if candidate_len > limit and selected:
                break
            selected.append(block)
            total_len = candidate_len
        return "\n\n".join(selected)


def extract_article_text(html_payload: str | bytes, *, limit: int = DEFAULT_ARTICLE_TEXT_LIMIT) -> str:
    if isinstance(html_payload, bytes):
        payload = html_payload.decode("utf-8", errors="replace")
    else:
        payload = html_payload

    parser = ArticleTextExtractor()
    parser.feed(payload)
    parser.close()
    return parser.extract(limit)


class RSSNewsFetcher:
    def __init__(
        self,
        *,
        timeout_sec: int = DEFAULT_TIMEOUT_SEC,
        article_timeout_sec: int = DEFAULT_ARTICLE_TIMEOUT_SEC,
        article_text_limit: int = DEFAULT_ARTICLE_TEXT_LIMIT,
        user_agent: str = DEFAULT_USER_AGENT,
        fixtures_by_url: Mapping[str, str] | None = None,
        article_fixtures_by_url: Mapping[str, str] | None = None,
        cache_enabled: bool = True,
        cache_ttl_sec: int = DEFAULT_CACHE_TTL_SEC,
        cache_file: Path | None = None,
        cache_namespace: str = "",
    ) -> None:
        self.timeout_sec = int(timeout_sec)
        self.article_timeout_sec = int(article_timeout_sec)
        self.article_text_limit = int(article_text_limit)
        self.user_agent = str(user_agent).strip() or DEFAULT_USER_AGENT
        self.fixtures_by_url = dict(fixtures_by_url or {})
        self.article_fixtures_by_url = dict(article_fixtures_by_url or {})
        self.cache_enabled = bool(cache_enabled)
        self.cache_ttl_sec = max(int(cache_ttl_sec), 0)
        self.cache_file = Path(cache_file or DEFAULT_NEWS_CACHE_FILE)
        self.cache_namespace = str(cache_namespace or "").strip()

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "RSSNewsFetcher":
        data = env or {}
        fixtures_path = str(data.get("NEWS_RSS_FIXTURES_FILE") or "").strip()
        timeout_sec = int(str(data.get("NEWS_RSS_TIMEOUT_SEC") or DEFAULT_TIMEOUT_SEC))
        article_timeout_sec = int(
            str(data.get("NEWS_ARTICLE_TIMEOUT_SEC") or DEFAULT_ARTICLE_TIMEOUT_SEC)
        )
        article_text_limit = int(
            str(data.get("NEWS_ARTICLE_TEXT_LIMIT") or DEFAULT_ARTICLE_TEXT_LIMIT)
        )
        cache_enabled = str(data.get("NEWS_CACHE_ENABLED", "1")).strip() != "0"
        cache_ttl_sec = int(str(data.get("NEWS_CACHE_TTL_SEC") or DEFAULT_CACHE_TTL_SEC))
        cache_file = Path(str(data.get("NEWS_CACHE_FILE") or DEFAULT_NEWS_CACHE_FILE))

        fixtures: dict[str, str] = {}
        article_fixtures: dict[str, str] = {}
        if fixtures_path:
            fixtures, article_fixtures = _read_fixture_sections(Path(fixtures_path))

        return cls(
            timeout_sec=timeout_sec,
            article_timeout_sec=article_timeout_sec,
            article_text_limit=article_text_limit,
            fixtures_by_url=fixtures,
            article_fixtures_by_url=article_fixtures,
            cache_enabled=cache_enabled,
            cache_ttl_sec=cache_ttl_sec,
            cache_file=cache_file,
            cache_namespace=fixtures_path,
        )

    def fetch_source(self, source_url: str) -> str:
        url = str(source_url or "").strip()
        if not url:
            raise ValueError("Пустой URL RSS-источника")

        if url in self.fixtures_by_url:
            append_news_log("rss_fetch_fixture", source_url=url)
            return self.fixtures_by_url[url]

        request = Request(
            url,
            headers={
                "User-Agent": self.user_agent,
                "Accept": "application/rss+xml, application/xml;q=0.9, */*;q=0.8",
            },
        )
        with urlopen(request, timeout=self.timeout_sec) as response:  # noqa: S310
            charset = response.headers.get_content_charset() or "utf-8"
            payload = response.read().decode(charset, errors="replace")
        append_news_log("rss_fetch_ok", source_url=url, payload_size=len(payload))
        return payload

    def _cache_key(self, source_map: Mapping[str, list[str]]) -> str:
        payload = {
            "version": CACHE_FORMAT_VERSION,
            "sources": source_map,
            "namespace": self.cache_namespace,
        }
        return json.dumps(payload, ensure_ascii=False, sort_keys=True)

    def _load_cached_fetch(self, source_map: Mapping[str, list[str]]) -> dict[str, Any] | None:
        if not self.cache_enabled or self.cache_ttl_sec <= 0:
            return None

        raw_cache = read_json_dict(self.cache_file)
        entries = raw_cache.get("entries")
        if not isinstance(entries, dict):
            return None

        entry = entries.get(self._cache_key(source_map))
        if not isinstance(entry, dict):
            return None

        fetched_at = int(entry.get("fetched_at") or 0)
        age_sec = int(time()) - fetched_at
        if fetched_at <= 0 or age_sec > self.cache_ttl_sec:
            return None

        result = entry.get("result")
        if not isinstance(result, dict):
            return None

        append_news_log(
            "rss_cache_hit",
            cache_file=str(self.cache_file),
            cache_age_sec=age_sec,
            categories=list(source_map.keys()),
        )
        return {
            "items": list(result.get("items") or []),
            "errors": list(result.get("errors") or []),
            "sources": dict(result.get("sources") or source_map),
            "cached": True,
        }

    def _store_cached_fetch(self, source_map: Mapping[str, list[str]], result: Mapping[str, Any]) -> None:
        if not self.cache_enabled or self.cache_ttl_sec <= 0:
            return

        raw_cache = read_json_dict(self.cache_file)
        entries = raw_cache.get("entries")
        if not isinstance(entries, dict):
            entries = {}

        entries[self._cache_key(source_map)] = {
            "fetched_at": int(time()),
            "result": {
                "items": list(result.get("items") or []),
                "errors": list(result.get("errors") or []),
                "sources": dict(result.get("sources") or source_map),
            },
        }
        write_json_dict(
            self.cache_file,
            {
                "version": CACHE_FORMAT_VERSION,
                "entries": entries,
            },
        )
        append_news_log(
            "rss_cache_store",
            cache_file=str(self.cache_file),
            categories=list(source_map.keys()),
            cached_items=len(result.get("items") or []),
        )

    def _split_source_urls(
        self,
        *,
        category: str,
        urls: list[str],
    ) -> tuple[list[str], list[str]]:
        fallback_urls = FALLBACK_RSS_SOURCES_BY_CATEGORY.get(category) or set()
        primary: list[str] = []
        backup: list[str] = []
        seen: set[str] = set()

        for raw_url in urls:
            source_url = str(raw_url or "").strip()
            if not source_url or source_url in seen:
                continue
            seen.add(source_url)
            if source_url in fallback_urls:
                backup.append(source_url)
            else:
                primary.append(source_url)

        return primary, backup

    def _fetch_category_urls(
        self,
        *,
        category: str,
        urls: list[str],
        errors: list[dict[str, str]],
    ) -> list[dict[str, Any]]:
        category_items: list[dict[str, Any]] = []

        for source_url in urls:
            try:
                payload = self.fetch_source(source_url)
                parsed = parse_feed(payload, source_url=source_url, category=category)
                category_items.extend(parsed)
            except Exception as error:  # noqa: BLE001
                append_news_log(
                    "rss_fetch_error",
                    category=category,
                    source_url=source_url,
                    error=str(error),
                )
                errors.append(
                    {
                        "category": category,
                        "source_url": source_url,
                        "error": str(error),
                    }
                )

        return category_items

    def fetch_article(self, article_url: str) -> str:
        url = str(article_url or "").strip()
        normalized = normalize_url(url)
        if not normalized:
            raise ValueError("Пустой URL статьи")

        if normalized in self.article_fixtures_by_url:
            return self.article_fixtures_by_url[normalized]
        if url in self.article_fixtures_by_url:
            return self.article_fixtures_by_url[url]

        request = Request(
            normalized,
            headers={
                "User-Agent": self.user_agent,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
        )
        with urlopen(request, timeout=self.article_timeout_sec) as response:  # noqa: S310
            charset = response.headers.get_content_charset() or "utf-8"
            return response.read().decode(charset, errors="replace")

    def enrich_articles(
        self,
        items: list[dict[str, Any]],
        *,
        enabled: bool = True,
    ) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
        prepared = [dict(item) for item in items]
        if not enabled:
            return prepared, []

        errors: list[dict[str, str]] = []
        article_cache: dict[str, str] = {}
        for item in prepared:
            normalized = normalize_url(item.get("link"))
            if not normalized:
                continue
            if normalized in article_cache:
                item["article_text"] = article_cache[normalized]
                continue
            try:
                html = self.fetch_article(normalized)
                article_text = extract_article_text(html, limit=self.article_text_limit)
                article_cache[normalized] = article_text
                item["article_text"] = article_text
            except Exception as error:  # noqa: BLE001
                item["article_text"] = ""
                errors.append(
                    {
                        "link": normalized,
                        "error": str(error),
                    }
                )
        return prepared, errors

    def fetch(self, sources: Mapping[str, list[str]] | None = None) -> dict[str, Any]:
        source_map = dict(sources or DEFAULT_RSS_SOURCES)
        cached_result = self._load_cached_fetch(source_map)
        if cached_result is not None:
            return cached_result

        items: list[dict[str, Any]] = []
        errors: list[dict[str, str]] = []

        for category, urls in source_map.items():
            primary_urls, backup_urls = self._split_source_urls(category=category, urls=list(urls))
            category_items: list[dict[str, Any]] = []
            category_errors: list[dict[str, str]] = []
            backup_recovered = False
            target_items = int(MIN_SOURCE_ITEMS_BEFORE_FALLBACK.get(category) or 0)

            if primary_urls:
                category_items.extend(
                    self._fetch_category_urls(
                        category=category,
                        urls=primary_urls,
                        errors=category_errors,
                    )
                )

            should_try_backup = bool(backup_urls) and (
                not category_items or bool(category_errors)
                or (target_items > 0 and len(category_items) < target_items)
            )
            if should_try_backup:
                backup_items = self._fetch_category_urls(
                    category=category,
                    urls=backup_urls,
                    errors=category_errors,
                )
                if backup_items and category_errors:
                    backup_recovered = True
                category_items.extend(
                    backup_items
                )

            if category_errors and not backup_recovered:
                errors.extend(category_errors)
            items.extend(category_items)

        result = {
            "items": items,
            "errors": errors,
            "sources": source_map,
            "cached": False,
        }
        self._store_cached_fetch(source_map, result)
        return result
