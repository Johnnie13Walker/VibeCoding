"""Фильтрация и нормализация новостей."""

from __future__ import annotations

from time import time
from typing import Any, Iterable
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

MIN_NEWS_PER_CATEGORY = 3
MAX_NEWS_PER_CATEGORY = 5
DEFAULT_NEWS_PER_CATEGORY = 3
DEFAULT_MAX_AGE_HOURS = 24
MAX_NEWS_TITLE_LENGTH = 120

TRACKING_QUERY_PREFIXES = ("utm_",)
TRACKING_QUERY_KEYS = {"fbclid", "gclid", "mc_cid", "mc_eid", "ref"}
PROMOTIONAL_TITLE_MARKERS = (
    "sponsored",
    "sponsor",
    "webinar",
    "whitepaper",
    "ebook",
    "buyers guide",
    "download",
    "register now",
    "book a demo",
    "demo",
    "subscribe",
    "discount",
    "sale",
    "advertisement",
    "advertorial",
)
PROMOTIONAL_LINK_MARKERS = (
    "/sponsored/",
    "/advertise/",
    "/events/",
    "/webinar/",
)
GENERIC_TITLE_MARKERS = (
    "top 10",
    "top ten",
    "tips",
    "things to know",
    "ultimate guide",
    "beginner guide",
    "best tools",
    "best practices",
)
TECHNICAL_KEYWORDS = (
    "ai",
    "llm",
    "devops",
    "cloud",
    "kubernetes",
    "docker",
    "python",
    "node",
    "api",
    "automation",
)


def clamp_news_per_category(limit: int | None) -> int:
    if limit is None:
        return DEFAULT_NEWS_PER_CATEGORY
    value = int(limit)
    if value < MIN_NEWS_PER_CATEGORY:
        return MIN_NEWS_PER_CATEGORY
    if value > MAX_NEWS_PER_CATEGORY:
        return MAX_NEWS_PER_CATEGORY
    return value


def normalize_url(raw_url: str | None) -> str:
    url = str(raw_url or "").strip()
    if not url:
        return ""

    split = urlsplit(url)
    query_pairs = []
    for key, value in parse_qsl(split.query, keep_blank_values=True):
        lower_key = key.lower()
        if lower_key in TRACKING_QUERY_KEYS:
            continue
        if any(lower_key.startswith(prefix) for prefix in TRACKING_QUERY_PREFIXES):
            continue
        query_pairs.append((key, value))

    normalized_query = urlencode(query_pairs, doseq=True)
    cleaned = split._replace(query=normalized_query, fragment="")
    return urlunsplit(cleaned).rstrip("/")


def normalize_title(raw_title: str | None) -> str:
    title = " ".join(str(raw_title or "").strip().split())
    return title.lower()


def is_promotional_news(item: dict[str, Any]) -> bool:
    title = normalize_title(item.get("title"))
    link = normalize_url(item.get("link")).lower()

    if any(marker in title for marker in PROMOTIONAL_TITLE_MARKERS):
        return True
    if any(marker in link for marker in PROMOTIONAL_LINK_MARKERS):
        return True
    return False


def has_technical_keywords(item: dict[str, Any]) -> bool:
    title = normalize_title(item.get("title"))
    summary = normalize_title(item.get("summary"))
    haystack = f"{title} {summary}".strip()
    return any(keyword in haystack for keyword in TECHNICAL_KEYWORDS)


def is_low_signal_news(item: dict[str, Any]) -> bool:
    title = str(item.get("title") or "").strip()
    normalized_title = normalize_title(title)
    if not normalized_title:
        return True
    if len(title) > MAX_NEWS_TITLE_LENGTH:
        return True
    if any(marker in normalized_title for marker in GENERIC_TITLE_MARKERS):
        return True
    return False


def article_priority_score(item: dict[str, Any]) -> int:
    score = 0
    title = normalize_title(item.get("title"))
    summary = normalize_title(item.get("summary"))

    title_keyword_hits = sum(1 for keyword in TECHNICAL_KEYWORDS if keyword in title)
    summary_keyword_hits = sum(1 for keyword in TECHNICAL_KEYWORDS if keyword in summary)
    score += min(title_keyword_hits * 3, 9)
    score += min(summary_keyword_hits, 4)

    if not has_technical_keywords(item):
        score -= 3
    if is_low_signal_news(item):
        score -= 8

    return score


def deduplicate_news(items: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    dedup_map: dict[str, dict[str, Any]] = {}
    for item in items:
        key_url = normalize_url(item.get("link"))
        key_title = normalize_title(item.get("title"))
        key = key_url or key_title
        if not key:
            continue

        current = dedup_map.get(key)
        if current is None:
            dedup_map[key] = dict(item)
            continue

        current_ts = int(current.get("published_ts") or 0)
        next_ts = int(item.get("published_ts") or 0)
        if next_ts >= current_ts:
            dedup_map[key] = dict(item)

    return list(dedup_map.values())


def filter_recent_news(
    items: Iterable[dict[str, Any]],
    *,
    now_ts: int | None = None,
    max_age_hours: int = DEFAULT_MAX_AGE_HOURS,
) -> list[dict[str, Any]]:
    current_ts = int(now_ts or time())
    min_ts = current_ts - int(max_age_hours * 60 * 60)

    recent: list[dict[str, Any]] = []
    for item in items:
        published_ts = int(item.get("published_ts") or 0)
        if published_ts <= 0:
            continue
        if published_ts < min_ts or published_ts > current_ts:
            continue
        recent.append(dict(item))
    return recent


def filter_non_promotional_news(items: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    curated: list[dict[str, Any]] = []
    for item in items:
        prepared = dict(item)
        if is_promotional_news(prepared):
            continue
        if is_low_signal_news(prepared):
            continue
        prepared["priority_score"] = article_priority_score(prepared)
        prepared["has_technical_keywords"] = has_technical_keywords(prepared)
        curated.append(prepared)
    return curated


def shorten_headline(headline: str | None, *, max_len: int = 90) -> str:
    text = " ".join(str(headline or "").strip().split())
    if len(text) <= max_len:
        return text

    slice_len = max(max_len - 1, 1)
    clipped = text[:slice_len]
    split_idx = clipped.rfind(" ")
    if split_idx > 30:
        clipped = clipped[:split_idx]
    return f"{clipped.rstrip(' ,.;:-')}…"


def group_by_category(
    items: Iterable[dict[str, Any]],
    *,
    category_order: list[str],
) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = {category: [] for category in category_order}
    for item in items:
        category = str(item.get("category") or "").strip()
        if category not in grouped:
            continue
        grouped[category].append(dict(item))
    return grouped


def pick_fresh_news_by_category(
    items: Iterable[dict[str, Any]],
    *,
    category_order: list[str],
    per_category_limit: int | None = None,
) -> dict[str, list[dict[str, Any]]]:
    safe_limit = clamp_news_per_category(per_category_limit)
    grouped = group_by_category(items, category_order=category_order)
    selected: dict[str, list[dict[str, Any]]] = {}

    for category in category_order:
        ranked = sorted(
            grouped.get(category, []),
            key=lambda item: (
                int(item.get("priority_score") or article_priority_score(item)),
                int(item.get("published_ts") or 0),
                str(item.get("title") or ""),
            ),
            reverse=True,
        )
        selected[category] = ranked[:safe_limit]

    return selected
