"""Сборка публичных ссылок на карточки Bitrix24 без секрета webhook."""

from __future__ import annotations

from urllib.parse import urlparse, urlunparse


def normalize_portal_base_url(url: str | None) -> str:
    raw = str(url or "").strip()
    if not raw:
        return ""

    parsed = urlparse(raw)
    if not parsed.scheme or not parsed.netloc:
        return ""
    return urlunparse((parsed.scheme, parsed.netloc, "", "", "", "")).rstrip("/")


def build_deal_url(portal_base_url: str | None, deal_id: str | int | None) -> str:
    base_url = normalize_portal_base_url(portal_base_url)
    entity_id = str(deal_id or "").strip()
    if not base_url or not entity_id:
        return ""
    return f"{base_url}/crm/deal/details/{entity_id}/"


def build_lead_url(portal_base_url: str | None, lead_id: str | int | None) -> str:
    base_url = normalize_portal_base_url(portal_base_url)
    entity_id = str(lead_id or "").strip()
    if not base_url or not entity_id:
        return ""
    return f"{base_url}/crm/lead/details/{entity_id}/"


def build_dynamic_item_url(
    portal_base_url: str | None,
    entity_type_id: str | int | None,
    entity_id: str | int | None,
    *,
    category_id: str | int | None = None,
) -> str:
    base_url = normalize_portal_base_url(portal_base_url)
    type_id = str(entity_type_id or "").strip()
    item_id = str(entity_id or "").strip()
    if not base_url or not type_id or not item_id:
        return ""
    suffix = f"?categoryId={str(category_id).strip()}" if str(category_id or "").strip() else ""
    return f"{base_url}/crm/type/{type_id}/details/{item_id}/{suffix}"


def build_entity_url(portal_base_url: str | None, entity_type: str, entity_id: str | int | None) -> str:
    normalized_type = str(entity_type or "").strip().lower()
    if normalized_type == "deal":
        return build_deal_url(portal_base_url, entity_id)
    if normalized_type == "lead":
        return build_lead_url(portal_base_url, entity_id)
    return ""
