"""Sales Copilot agent: Bitrix CRM -> анализ -> Telegram-отчет."""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping
from urllib.request import Request, urlopen

from cloudbot.business_day import current_business_week, current_business_week_window, previous_business_week_window
from cloudbot.providers.bitrix_provider import BitrixProvider
from cloudbot.skills.bitrix_sales_data import get_sales_snapshot

from .communications_metrics import (
    get_communications_summary_for_window,
    get_yesterday_communications_summary,
    resolve_sales_team_filter,
)
from .pipeline_analyzer import MOSCOW_TZ, analyze_pipeline
from .risk_detector import detect_risks
from .sales_formatter import (
    format_followup_report,
    format_focus_sales_report,
    format_pipeline_report,
    format_risks_report,
    format_sales_brief,
    format_weekly_review,
)

REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SALES_LOG_FILE = REPO_ROOT / "logs" / "sales_agent.log"
REPORT_TYPES = {"sales", "pipeline", "risks", "focus", "followup", "weekly"}
TELEGRAM_PARSE_MODE = "HTML"


class SalesAgentError(RuntimeError):
    """Ошибка подготовки sales-отчета."""


def _mask_value(value: str | None) -> str:
    raw = str(value or "").strip()
    if not raw:
        return "-"
    if len(raw) <= 4:
        return "***"
    return f"{raw[:2]}***{raw[-2:]}"


def _env_dict(env: Mapping[str, str] | None = None) -> dict[str, str]:
    if env is None:
        return {str(key): str(value) for key, value in os.environ.items()}
    return {str(key): str(value) for key, value in env.items()}


def _append_sales_log(event: str, **payload: Any) -> None:
    record = {
        "ts_msk": datetime.now(MOSCOW_TZ).isoformat(timespec="seconds"),
        "event": event,
        **payload,
    }
    DEFAULT_SALES_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with DEFAULT_SALES_LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, default=str))
        handle.write("\n")


def _resolve_now(env_data: Mapping[str, str]) -> datetime:
    raw_ts = str(env_data.get("SALES_AGENT_NOW_TS") or "").strip()
    if raw_ts:
        return datetime.fromtimestamp(int(raw_ts), tz=timezone.utc).astimezone(MOSCOW_TZ)
    return datetime.now(MOSCOW_TZ)


def _optional_float(value: str | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(" ", "").replace(",", "."))
    except ValueError:
        return None


def _parse_report_date(raw_value: str | None, *, option_name: str) -> date | None:
    raw = str(raw_value or "").strip()
    if not raw:
        return None
    try:
        return date.fromisoformat(raw)
    except ValueError as error:
        raise SalesAgentError(f"Неверная дата {option_name}: {raw}. Ожидается формат YYYY-MM-DD.") from error


def _resolve_period_override(env_data: Mapping[str, str]) -> dict[str, Any] | None:
    start_date = _parse_report_date(env_data.get("SALES_REPORT_DATE_FROM"), option_name="--date-from")
    end_date = _parse_report_date(env_data.get("SALES_REPORT_DATE_TO"), option_name="--date-to")
    if start_date is None and end_date is None:
        return None
    if start_date is None or end_date is None:
        raise SalesAgentError("Для произвольного периода нужны оба параметра: --date-from и --date-to.")
    if end_date < start_date:
        raise SalesAgentError("Дата окончания периода не может быть раньше даты начала.")

    start = datetime.combine(start_date, time.min, tzinfo=MOSCOW_TZ)
    end = datetime.combine(end_date + timedelta(days=1), time.min, tzinfo=MOSCOW_TZ)
    return {
        "start": start,
        "end": end,
        "start_date": start_date,
        "end_date": end_date,
    }


def _resolve_sales_chat_id(
    env_data: Mapping[str, str],
    *,
    explicit_chat_id: str | None = None,
    report_type: str | None = None,
) -> str:
    explicit_value = str(explicit_chat_id or "").strip()
    if explicit_value:
        return explicit_value

    report = str(report_type or "").strip().lower()
    candidates: list[str | None]
    if report == "weekly":
        candidates = [
            env_data.get("SALES_WEEKLY_TELEGRAM_CHAT_ID"),
            env_data.get("SALES_TELEGRAM_CHAT_ID"),
            env_data.get("TELEGRAM_CHAT_ID"),
        ]
    else:
        candidates = [
            env_data.get("SALES_TELEGRAM_CHAT_ID"),
            env_data.get("SALES_DAILY_TELEGRAM_CHAT_ID"),
            env_data.get("SALES_WEEKLY_TELEGRAM_CHAT_ID"),
            env_data.get("TELEGRAM_CHAT_ID"),
        ]

    for candidate in candidates:
        value = str(candidate or "").strip()
        if value:
            return value
    return ""


def _telegram_ready(env_data: Mapping[str, str]) -> bool:
    return bool(_resolve_sales_chat_id(env_data)) and (
        bool(env_data.get("TELEGRAM_BOT_TOKEN"))
        or str(env_data.get("TELEGRAM_DRY_RUN") or env_data.get("SALES_TELEGRAM_DRY_RUN") or "") == "1"
    )


class SalesAgent:
    def __init__(
        self,
        *,
        provider: BitrixProvider,
        now: datetime,
        inactivity_days: int = 5,
        late_stage_days: int = 5,
        stale_communication_days: int = 14,
        large_deal_amount: float = 150000.0,
        monthly_target: float | None = None,
        env_data: Mapping[str, str] | None = None,
    ) -> None:
        self.provider = provider
        self.now = now.astimezone(MOSCOW_TZ)
        self.inactivity_days = int(inactivity_days)
        self.late_stage_days = int(late_stage_days)
        self.stale_communication_days = int(stale_communication_days)
        self.large_deal_amount = float(large_deal_amount)
        self.monthly_target = monthly_target
        self.env_data = dict(env_data or {})

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "SalesAgent":
        env_data = _env_dict(env)
        provider = BitrixProvider.from_env(env=env_data)
        return cls(
            provider=provider,
            now=_resolve_now(env_data),
            inactivity_days=int(env_data.get("SALES_INACTIVITY_DAYS") or "5"),
            late_stage_days=int(env_data.get("SALES_LATE_STAGE_INACTIVITY_DAYS") or "5"),
            stale_communication_days=int(env_data.get("SALES_STALE_COMMUNICATION_DAYS") or "14"),
            large_deal_amount=float(env_data.get("SALES_LARGE_DEAL_AMOUNT") or "150000"),
            monthly_target=_optional_float(env_data.get("SALES_MONTHLY_TARGET")),
            env_data=env_data,
        )

    def build_report_payload(self, *, report_type: str = "sales") -> dict[str, Any]:
        period_override = _resolve_period_override(self.env_data)
        weekly_window: dict[str, Any] | None = None
        if report_type == "weekly":
            if period_override:
                current_week_start = period_override["start"]
                current_week_end = period_override["end"]
                week_start_date = period_override["start_date"]
                week_end_date = period_override["end_date"]
                previous_week_end = current_week_start
                previous_week_start = previous_week_end - (current_week_end - current_week_start)
                weekly_window = {
                    "start": current_week_start,
                    "end": current_week_end,
                    "previous_start": previous_week_start,
                    "previous_end": previous_week_end,
                    "start_date": week_start_date,
                    "end_date": week_end_date,
                    "custom_period": True,
                    "title": "📊 Отчёт Льва Петровича по периоду",
                    "summary_heading": "1. Что произошло за период",
                    "people_heading": "3. Люди за период",
                    "problem_deals_heading": "5. Проблемные сделки периода",
                }
            else:
                current_week_start, current_week_end = current_business_week_window(self.now)
                previous_week_start, previous_week_end = previous_business_week_window(self.now)
                week_start_date, week_end_date = current_business_week(self.now)
                weekly_window = {
                    "start": current_week_start,
                    "end": current_week_end,
                    "previous_start": previous_week_start,
                    "previous_end": previous_week_end,
                    "start_date": week_start_date,
                    "end_date": week_end_date,
                    "custom_period": False,
                }

        snapshot = get_sales_snapshot(
            self.env_data,
            period_start=weekly_window.get("start") if weekly_window else None,
            period_end=weekly_window.get("end") if weekly_window else None,
        )
        analysis = analyze_pipeline(
            snapshot,
            now=self.now,
            large_deal_amount=self.large_deal_amount,
            inactivity_days=self.inactivity_days,
            stale_communication_days=self.stale_communication_days,
        )
        risk_report = detect_risks(
            analysis,
            inactivity_days=self.inactivity_days,
            late_stage_days=self.late_stage_days,
            stale_communication_days=self.stale_communication_days,
        )
        department_filter = resolve_sales_team_filter(
            self.env_data,
            snapshot=snapshot,
        )
        weekly_summary: dict[str, Any] | None = None
        previous_weekly_summary: dict[str, Any] | None = None
        if weekly_window:
            weekly_summary = get_communications_summary_for_window(
                self.env_data,
                snapshot=snapshot,
                analysis=analysis,
                period_start=weekly_window["start"],
                period_end=weekly_window["end"],
                department_filter=department_filter,
            )
            previous_weekly_summary = get_communications_summary_for_window(
                self.env_data,
                snapshot=snapshot,
                analysis=None,
                period_start=weekly_window["previous_start"],
                period_end=weekly_window["previous_end"],
                department_filter=department_filter,
            )
            communications_summary = weekly_summary
        else:
            communications_summary = get_yesterday_communications_summary(
                self.env_data,
                snapshot=snapshot,
                analysis=analysis,
                now=self.now,
                department_filter=department_filter,
            )
        department_filter = communications_summary.get("department_filter") or department_filter
        _append_sales_log(
            "sales_department_filter",
            mode=department_filter.get("mode"),
            found_departments=department_filter.get("found_departments") or [],
            missing_departments=department_filter.get("missing_departments") or [],
            allowlist_count=int(department_filter.get("allowlist_count") or 0),
            allowlist_users=department_filter.get("allowlist_users") or [],
            warnings=department_filter.get("warnings") or [],
        )
        _append_sales_log(
            "sales_snapshot",
            source=snapshot.get("source"),
            deals=len(snapshot.get("active_deals") or snapshot.get("recent_deals") or []),
            leads=len(snapshot.get("active_leads") or snapshot.get("recent_leads") or []),
            meetings=len(snapshot.get("conducted_meetings") or []),
            briefs=len(snapshot.get("accepted_briefs") or []),
            tasks=len(snapshot.get("tasks") or []),
            communication_managers=len(communications_summary.get("managers") or []),
        )
        payload = {
            "snapshot": snapshot,
            "analysis": analysis,
            "risk_report": risk_report,
            "communications_summary": communications_summary,
        }
        if weekly_window:
            if weekly_window.get("custom_period") and weekly_window.get("end_date") < self.now.date():
                limitations = list(analysis.get("limitations") or [])
                note = (
                    "Для прошедших периодов риск, люди и текущая воронка считаются по текущему состоянию "
                    "открытых сделок; исторический снимок Bitrix на конец периода в этом отчёте не хранится."
                )
                if note not in limitations:
                    limitations.append(note)
                analysis["limitations"] = limitations
            payload["weekly_context"] = {
                **weekly_window,
                "communications_summary": weekly_summary or {},
                "previous_communications_summary": previous_weekly_summary or {},
            }
        return payload

    def render(self, report_type: str, payload: dict[str, Any]) -> str:
        if report_type not in REPORT_TYPES:
            raise SalesAgentError(f"Неизвестный тип отчета: {report_type}")

        analysis = payload["analysis"]
        risk_report = payload["risk_report"]
        communications_summary = payload.get("communications_summary") or {}

        if report_type == "sales":
            return format_sales_brief(
                analysis,
                risk_report,
                communications_summary=communications_summary,
                monthly_target=self.monthly_target,
            )
        if report_type == "pipeline":
            return format_sales_brief(
                analysis,
                risk_report,
                communications_summary=communications_summary,
                monthly_target=self.monthly_target,
            )
        if report_type == "risks":
            return format_risks_report(
                analysis,
                risk_report,
                communications_summary=communications_summary,
            )
        if report_type == "focus":
            return format_focus_sales_report(
                analysis,
                risk_report,
                communications_summary=communications_summary,
            )
        if report_type == "followup":
            return format_followup_report(analysis, risk_report)
        return format_weekly_review(
            analysis,
            risk_report,
            weekly_context=payload.get("weekly_context") or {},
            monthly_target=self.monthly_target,
        )

    def send_to_telegram(
        self,
        text: str,
        *,
        chat_id: str | None = None,
        parse_mode: str | None = TELEGRAM_PARSE_MODE,
        report_type: str | None = None,
    ) -> dict[str, Any]:
        env_data = dict(self.env_data)
        target_chat_id = _resolve_sales_chat_id(
            env_data,
            explicit_chat_id=chat_id,
            report_type=report_type,
        )
        if not target_chat_id:
            raise SalesAgentError("Не задан chat_id для sales-отчета")
        masked_chat_id = _mask_value(target_chat_id)

        dry_run = str(env_data.get("SALES_TELEGRAM_DRY_RUN") or env_data.get("TELEGRAM_DRY_RUN") or "") == "1"
        if dry_run:
            _append_sales_log("telegram_send_dry_run", chat_id=masked_chat_id)
            return {"status": "dry_run", "chat_id_masked": masked_chat_id}

        bot_token = str(env_data.get("TELEGRAM_BOT_TOKEN") or "").strip()
        if not bot_token:
            raise SalesAgentError("Не задан TELEGRAM_BOT_TOKEN для sales-отчета")

        api_base = str(env_data.get("TELEGRAM_API_BASE_URL") or "https://api.telegram.org").strip()
        request = Request(
            f"{api_base.rstrip('/')}/bot{bot_token}/sendMessage",
            method="POST",
            data=json.dumps(
                {
                    "chat_id": target_chat_id,
                    "text": text,
                    "disable_web_page_preview": True,
                    "parse_mode": parse_mode or TELEGRAM_PARSE_MODE,
                },
                ensure_ascii=False,
            ).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )

        try:
            with urlopen(request, timeout=15) as response:  # noqa: S310
                raw = response.read().decode("utf-8", errors="replace")
        except Exception as error:  # noqa: BLE001
            raise SalesAgentError(f"Ошибка отправки sales-отчета в Telegram: {error}") from error

        payload = json.loads(raw or "{}")
        if payload.get("ok") is not True:
            description = payload.get("description") or "unknown error"
            raise SalesAgentError(f"Telegram sendMessage failed: {description}")

        _append_sales_log("telegram_send_ok", chat_id=masked_chat_id)
        return {"status": "sent", "chat_id_masked": masked_chat_id, "payload": payload}

    def run(
        self,
        *,
        report_type: str = "sales",
        send: bool = False,
        chat_id: str | None = None,
    ) -> dict[str, Any]:
        payload = self.build_report_payload(report_type=report_type)
        text = self.render(report_type, payload)
        result = {
            "ok": True,
            "report_type": report_type,
            "text": text,
            "parse_mode": TELEGRAM_PARSE_MODE,
            "analysis": payload["analysis"],
            "risk_report": payload["risk_report"],
            "communications_summary": payload.get("communications_summary") or {},
        }
        if send:
            result["telegram"] = self.send_to_telegram(
                text,
                chat_id=chat_id,
                parse_mode=result["parse_mode"],
                report_type=report_type,
            )
        return result


def build_sales_report_from_env(
    env: Mapping[str, str] | None = None,
    *,
    report_type: str = "sales",
    date_from: str | None = None,
    date_to: str | None = None,
) -> dict[str, Any]:
    env_data = _env_dict(env)
    if date_from:
        env_data["SALES_REPORT_DATE_FROM"] = str(date_from)
    if date_to:
        env_data["SALES_REPORT_DATE_TO"] = str(date_to)
    return SalesAgent.from_env(env_data).run(report_type=report_type)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Sales Copilot для Cloudbot")
    parser.add_argument("--report", choices=sorted(REPORT_TYPES), default="sales")
    parser.add_argument("--send", action="store_true")
    parser.add_argument("--chat-id", default="")
    parser.add_argument("--date-from", default="")
    parser.add_argument("--date-to", default="")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    env_data = _env_dict()
    if args.date_from:
        env_data["SALES_REPORT_DATE_FROM"] = str(args.date_from)
    if args.date_to:
        env_data["SALES_REPORT_DATE_TO"] = str(args.date_to)
    agent = SalesAgent.from_env(env_data)

    try:
        result = agent.run(
            report_type=args.report,
            send=bool(args.send),
            chat_id=args.chat_id or None,
        )
    except SalesAgentError as error:
        print(f"Sales Copilot error: {error}", file=sys.stderr)
        _append_sales_log("sales_error", error=str(error), report_type=args.report)
        return 1
    except Exception as error:  # noqa: BLE001
        print(f"Critical sales error: {error}", file=sys.stderr)
        _append_sales_log("sales_error", error=str(error), report_type=args.report)
        return 1

    print(result["text"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
