"""Нормализация live-данных Bitrix для управленческого Sales Copilot."""

from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from typing import Any

from cloudbot.business_day import MOSCOW_TZ, report_day_flags

from .bitrix_links import build_deal_url, build_dynamic_item_url, build_lead_url
QUALIFIED_MARKERS = ("qual", "квали", "appointment", "meeting", "demo", "proposal", "in work")
WON_MARKERS = ("won", "успеш", "оплач", "converted", "sale")
LOST_MARKERS = ("lost", "lose", "junk", "некаче", "отказ", "fail")
LATE_STAGE_MARKERS = (
    "proposal",
    "invoice",
    "contract",
    "negoti",
    "final",
    "offer",
    "коммер",
    "договор",
    "счет",
    "оплат",
    "соглас",
    "кп",
)
LEADER_FIELD_MARKERS = ("HEAD", "ESCAL", "DIRECTOR", "RUK", "CONTROL", "BOSS")
STAGE_NAME_MAP = {
    "NEW": "Новая",
    "PREPARATION": "Подготовка",
    "EXECUTING": "В работе",
    "FINAL_INVOICE": "Финальный счет",
    "PREPAYMENT_INVOICE": "Предоплата",
    "WON": "Успешно",
    "LOSE": "Потеряна",
}
GENERIC_LOST_REASON_VALUES = {
    "",
    "0",
    "1",
    "отвал",
    "lose",
    "c10:lose",
    "новая",
    "квалификация",
    "подготовка кп",
    "подготовка договора",
    "подготовка брифа",
    "догрев и переговоры",
}
HOT_STAGE_STAGE_ID = "C10:UC_KC7195"
HOT_STAGE_STAGE_NAME = "Подготовка договора"
BRIEF_PREP_STAGE_ID = "C10:PREPAYMENT_INVOIC"
BRIEF_PREP_STAGE_NAME = "Подготовка БРИФа"
TASK_DEADLINE_CHANGE_KEYS = {
    "changeddeadlinecount",
    "deadlinechangecount",
    "deadlinechangescount",
    "deadlinemovecount",
    "deadlinemovescount",
    "deadlinepostponecount",
    "deadlinereschedulecount",
    "deadlineshiftcount",
    "deadlineshiftscount",
    "postponecount",
    "postponescount",
    "reschedulecount",
    "reschedulescount",
}
TASK_DEADLINE_CHANGED_AT_KEYS = {
    "activitydate",
    "changedat",
    "changeddate",
    "deadlinechangedat",
    "deadlinemovedat",
    "deadlinepostponedat",
    "deadlinerescheduledat",
    "deadlineshiftat",
    "lastdeadlinechangedat",
    "lastdeadlinemovedat",
    "lastdeadlinepostponedat",
    "lastdeadlinerescheduledat",
    "lastdeadlineshiftat",
    "postponedat",
    "rescheduledat",
    "statuschangeddate",
    "updatedat",
}


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "y", "yes", "true", "t", "да"}


def _to_float(value: Any) -> float:
    if value in (None, ""):
        return 0.0
    try:
        return float(str(value).replace(" ", "").replace(",", "."))
    except ValueError:
        return 0.0


def _parse_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None

    if isinstance(value, datetime):
        if value.tzinfo is None:
            return value.replace(tzinfo=MOSCOW_TZ)
        return value.astimezone(MOSCOW_TZ)

    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(float(value), tz=timezone.utc).astimezone(MOSCOW_TZ)

    raw = str(value).strip()
    if not raw:
        return None
    if raw.endswith("Z"):
        raw = f"{raw[:-1]}+00:00"

    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError:
        parsed = None

    if parsed is None:
        for fmt in (
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d",
            "%d.%m.%Y %H:%M:%S",
            "%d.%m.%Y %H:%M",
            "%d.%m.%Y",
        ):
            try:
                parsed = datetime.strptime(raw, fmt)
                break
            except ValueError:
                continue

    if parsed is None:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=MOSCOW_TZ)
    return parsed.astimezone(MOSCOW_TZ)


def _normalized_lookup_key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").strip().lower())


def _task_nested_value(
    payload: Any,
    *,
    candidate_keys: set[str],
    parser: callable,
    max_depth: int = 3,
) -> Any:
    stack: list[tuple[Any, int]] = [(payload, 0)]
    while stack:
        current, depth = stack.pop(0)
        if depth > max_depth:
            continue
        if isinstance(current, dict):
            for key, value in current.items():
                if _normalized_lookup_key(key) in candidate_keys:
                    parsed = parser(value)
                    if parsed is not None:
                        return parsed
                if isinstance(value, (dict, list, tuple)):
                    stack.append((value, depth + 1))
        elif isinstance(current, (list, tuple)):
            for value in current:
                if isinstance(value, (dict, list, tuple)):
                    stack.append((value, depth + 1))
    return None


def _parse_int_like(value: Any) -> int | None:
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    raw = str(value).strip()
    if not raw:
        return None
    raw = raw.replace(" ", "")
    if raw.isdigit():
        return int(raw)
    match = re.search(r"-?\d+", raw)
    if match:
        return int(match.group(0))
    return None


def _extract_task_deadline_change_count(task: dict[str, Any]) -> int:
    count = _task_nested_value(task, candidate_keys=TASK_DEADLINE_CHANGE_KEYS, parser=_parse_int_like)
    return max(int(count or 0), 0)


def _extract_task_deadline_changed_at(task: dict[str, Any]) -> datetime | None:
    return _task_nested_value(task, candidate_keys=TASK_DEADLINE_CHANGED_AT_KEYS, parser=_parse_datetime)


def _today_flags(dt: datetime | None, now: datetime) -> tuple[bool, bool]:
    return report_day_flags(dt, now)


def _semantic_is_won(value: str) -> bool:
    return str(value or "").strip().upper() == "S"


def _semantic_is_lost(value: str) -> bool:
    return str(value or "").strip().upper() == "F"


def _status_haystack(*parts: Any) -> str:
    return " ".join(str(part or "").strip() for part in parts if str(part or "").strip()).lower()


def _is_qualified_status(status_id: str, status_name: str, semantic_id: str) -> bool:
    if _semantic_is_won(semantic_id):
        return True
    haystack = _status_haystack(status_id, status_name, semantic_id)
    return any(marker in haystack for marker in QUALIFIED_MARKERS)


def _is_won_status(status_id: str, status_name: str, semantic_id: str) -> bool:
    if _semantic_is_won(semantic_id):
        return True
    haystack = _status_haystack(status_id, status_name, semantic_id)
    return any(marker in haystack for marker in WON_MARKERS)


def _is_lost_status(status_id: str, status_name: str, semantic_id: str) -> bool:
    if _semantic_is_lost(semantic_id):
        return True
    haystack = _status_haystack(status_id, status_name, semantic_id)
    return any(marker in haystack for marker in LOST_MARKERS)


def _friendly_stage_name(stage_id: str, status_name: str | None = None) -> str:
    explicit_name = str(status_name or "").strip()
    if explicit_name and explicit_name != stage_id:
        return explicit_name

    raw = str(stage_id or "").strip()
    if not raw:
        return "Без стадии"
    token = raw.split(":", 1)[-1].strip().upper()
    if token in STAGE_NAME_MAP:
        return STAGE_NAME_MAP[token]
    humanized = token.replace("_", " ").strip().title()
    return humanized or raw


def _is_late_stage(stage_id: str, stage_name: str, probability: float) -> bool:
    haystack = _status_haystack(stage_id, stage_name)
    if any(marker in haystack for marker in LATE_STAGE_MARKERS):
        return True
    return probability >= 70.0


def _explicit_leader_flag(item: dict[str, Any]) -> bool:
    for key, value in item.items():
        key_upper = str(key).upper()
        if any(marker in key_upper for marker in LEADER_FIELD_MARKERS) and _truthy(value):
            return True
    for field in (
        "UF_CRM_NEEDS_HEAD",
        "UF_CRM_ESCALATE",
        "UF_CRM_DIRECTOR_CONTROL",
        "NEEDS_ATTENTION",
    ):
        if _truthy(item.get(field)):
            return True
    return False


def _effective_probability(probability: float, *, late_stage: bool, inactive_days: int | None) -> float:
    if probability > 0.0:
        return probability
    if late_stage:
        return 75.0 if (inactive_days or 0) <= 5 else 55.0
    if inactive_days in (None, 0, 1):
        return 45.0
    return 25.0


def _user_name(user: dict[str, Any]) -> str:
    parts = [
        str(user.get("name") or "").strip(),
        str(user.get("last_name") or "").strip(),
    ]
    full_name = " ".join(part for part in parts if part).strip()
    if full_name:
        return full_name
    return str(user.get("full_name") or user.get("email") or "Не назначен").strip()


def _assigned_name(user_map: dict[str, str], assigned_id: str) -> str:
    value = user_map.get(str(assigned_id or "").strip(), "").strip()
    if value:
        return value
    assigned_id = str(assigned_id or "").strip()
    if assigned_id:
        return f"ID {assigned_id}"
    return "без ответственного"


def _dedupe_entities(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in items:
        entity_id = str(item.get("id") or "").strip()
        if not entity_id or entity_id in seen:
            continue
        seen.add(entity_id)
        result.append(item)
    return result


def _company_contact_suffix(
    company_map: dict[str, str],
    contact_map: dict[str, str],
    company_id: str | None,
    contact_id: str | None,
) -> str:
    company_title = company_map.get(str(company_id or "").strip(), "")
    contact_title = contact_map.get(str(contact_id or "").strip(), "")
    relation = company_title or contact_title
    return relation.strip()


def _significant_tokens(text: str) -> set[str]:
    return {
        token
        for token in re.split(r"[^a-zA-Zа-яА-Я0-9]+", str(text or "").lower())
        if len(token) >= 4
    }


def _meeting_matches(entity_title: str, relation_suffix: str, meeting_title: str) -> bool:
    meeting_lc = str(meeting_title or "").lower()
    if not meeting_lc:
        return False

    for probe in (entity_title, relation_suffix):
        probe_lc = str(probe or "").lower().strip()
        if probe_lc and (probe_lc in meeting_lc or meeting_lc in probe_lc):
            return True

    entity_tokens = _significant_tokens(entity_title) | _significant_tokens(relation_suffix)
    meeting_tokens = _significant_tokens(meeting_title)
    return bool(entity_tokens and meeting_tokens and entity_tokens.intersection(meeting_tokens))


def _status_name_map(items: list[dict[str, Any]]) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in items or []:
        status_id = str(item.get("STATUS_ID") or item.get("status_id") or "").strip()
        if not status_id:
            continue
        result[status_id] = str(item.get("NAME") or item.get("name") or status_id).strip()
    return result


def _source_name_map(items: list[dict[str, Any]]) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in items or []:
        source_id = str(item.get("STATUS_ID") or item.get("status_id") or "").strip()
        if not source_id:
            continue
        result[source_id] = str(item.get("NAME") or item.get("name") or source_id).strip()
    return result


def _looks_like_text_reason(value: str, *, title: str, relation_suffix: str) -> bool:
    cleaned = str(value or "").strip()
    if len(cleaned) < 12 or len(cleaned) > 280:
        return False
    lowered = cleaned.lower()
    if lowered in GENERIC_LOST_REASON_VALUES:
        return False
    if "@" in cleaned or "http://" in lowered or "https://" in lowered or ".ru" in lowered:
        return False
    if re.match(r"^\d{4}[./-]\d{2}[./-]\d{2}", cleaned) or re.match(r"^\d{2}[./-]\d{2}[./-]\d{4}", cleaned):
        return False
    if re.fullmatch(r"[0-9 .:+-]+", cleaned):
        return False
    if lowered == str(title or "").strip().lower():
        return False
    if relation_suffix and lowered == str(relation_suffix).strip().lower():
        return False
    word_count = len([part for part in re.split(r"\s+", cleaned) if part])
    return bool(
        re.search(r"[a-zа-я]", cleaned, flags=re.IGNORECASE)
        and " " in cleaned
        and (word_count >= 3 or bool(re.search(r"[,.!?;:]", cleaned)))
    )


def _extract_explicit_lost_reason(raw: dict[str, Any], *, title: str, relation_suffix: str) -> str | None:
    standard_keys = ("COMMENTS", "COMMENT", "DESCRIPTION")
    for key in standard_keys:
        value = str(raw.get(key) or "").strip()
        if _looks_like_text_reason(value, title=title, relation_suffix=relation_suffix):
            return value

    for key, value in raw.items():
        if not str(key).startswith("UF_CRM_"):
            continue
        candidate = str(value or "").strip()
        if _looks_like_text_reason(candidate, title=title, relation_suffix=relation_suffix):
            return candidate
    return None


def _normalize_dynamic_item(
    raw_item: dict[str, Any],
    *,
    now: datetime,
    user_map: dict[str, str],
    stage_name_map: dict[str, str],
    portal_base_url: str,
    entity_type_id: int,
) -> dict[str, Any]:
    item_id = str(raw_item.get("id") or raw_item.get("ID") or "").strip()
    stage_id = str(raw_item.get("stage_id") or raw_item.get("stageId") or raw_item.get("STAGE_ID") or "").strip()
    moved_at = _parse_datetime(raw_item.get("moved_at") or raw_item.get("movedTime"))
    updated_at = _parse_datetime(raw_item.get("updated_at") or raw_item.get("updatedTime"))
    created_at = _parse_datetime(raw_item.get("created_at") or raw_item.get("createdTime"))
    effective_at = moved_at or updated_at or created_at
    today_moved, yesterday_moved = _today_flags(effective_at, now)
    assigned_id = str(raw_item.get("assigned_id") or raw_item.get("assignedById") or "").strip()
    category_id = str(raw_item.get("category_id") or raw_item.get("categoryId") or "").strip()
    return {
        "id": item_id,
        "title": str(raw_item.get("title") or raw_item.get("TITLE") or item_id).strip(),
        "card_url": build_dynamic_item_url(
            portal_base_url,
            entity_type_id,
            item_id,
            category_id=category_id,
        ),
        "assigned_id": assigned_id,
        "assigned_name": _assigned_name(user_map, assigned_id),
        "stage_id": stage_id,
        "stage_name": stage_name_map.get(stage_id) or stage_id or "Без стадии",
        "category_id": category_id,
        "created_at": created_at,
        "updated_at": updated_at,
        "moved_at": effective_at,
        "today_moved": today_moved,
        "yesterday_moved": yesterday_moved,
        "raw": raw_item.get("raw") if isinstance(raw_item.get("raw"), dict) else raw_item,
    }


def _build_stage_stats(active_deals: list[dict[str, Any]]) -> list[dict[str, Any]]:
    stats: dict[str, dict[str, Any]] = {}
    for deal in active_deals:
        key = str(deal.get("stage_name") or "Без стадии").strip()
        item = stats.setdefault(key, {"stage_name": key, "count": 0, "amount": 0.0})
        item["count"] += 1
        item["amount"] += float(deal.get("amount") or 0.0)
    return sorted(
        stats.values(),
        key=lambda item: (float(item["amount"]), int(item["count"])),
        reverse=True,
    )[:3]


def _build_owner_stats(active_deals: list[dict[str, Any]]) -> list[dict[str, Any]]:
    stats: dict[str, dict[str, Any]] = {}
    for deal in active_deals:
        key = str(deal.get("assigned_name") or "Не назначен").strip()
        item = stats.setdefault(
            key,
            {"assigned_name": key, "count": 0, "amount": 0.0, "stuck_count": 0},
        )
        item["count"] += 1
        item["amount"] += float(deal.get("amount") or 0.0)
        if int(deal.get("inactive_days") or 0) >= 5:
            item["stuck_count"] += 1
    return sorted(
        stats.values(),
        key=lambda item: (float(item["amount"]), int(item["count"]), -int(item["stuck_count"])),
        reverse=True,
    )[:3]


def _is_hot_stage_deal(deal: dict[str, Any]) -> bool:
    stage_id = str(deal.get("stage_id") or "").strip()
    if stage_id == HOT_STAGE_STAGE_ID:
        return True
    stage_name = str(deal.get("stage_name") or "").strip().lower()
    return stage_name == HOT_STAGE_STAGE_NAME.lower()


def _is_brief_prep_deal(deal: dict[str, Any]) -> bool:
    stage_id = str(deal.get("stage_id") or "").strip()
    if stage_id == BRIEF_PREP_STAGE_ID:
        return True
    stage_name = str(deal.get("stage_name") or "").strip().lower()
    return stage_name == BRIEF_PREP_STAGE_NAME.lower()


def _aggregate_sources(deals: list[dict[str, Any]]) -> list[dict[str, Any]]:
    stats: dict[str, dict[str, Any]] = {}
    for deal in deals:
        source_name = str(deal.get("source_name") or "Источник не указан").strip()
        item = stats.setdefault(source_name, {"source_name": source_name, "count": 0, "amount": 0.0})
        item["count"] += 1
        item["amount"] += float(deal.get("amount") or 0.0)
    return sorted(stats.values(), key=lambda item: (int(item["count"]), float(item["amount"])), reverse=True)


def _closed_task_statuses(task_status_map: dict[str, str]) -> set[str]:
    closed = {
        str(status_id).strip()
        for status_id, status_name in (task_status_map or {}).items()
        if "заверш" in str(status_name or "").strip().lower()
    }
    return closed or {"5"}


def _extract_task_deal_ids(task: dict[str, Any]) -> list[str]:
    result: list[str] = []
    for binding in task.get("crm_bindings") or []:
        raw = str(binding or "").strip()
        if raw.startswith("D_"):
            deal_id = raw.split("_", 1)[-1].strip()
            if deal_id:
                result.append(deal_id)
    return result


def _build_overdue_task_stats(
    tasks: list[dict[str, Any]],
    *,
    active_deals_by_id: dict[str, dict[str, Any]],
    now: datetime,
    task_status_map: dict[str, str],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    closed_statuses = _closed_task_statuses(task_status_map)
    overdue_tasks: list[dict[str, Any]] = []
    by_manager: dict[str, dict[str, Any]] = {}

    for task in tasks:
        deadline = _parse_datetime(task.get("deadline"))
        if deadline is None or deadline >= now:
            continue
        status = str(task.get("status") or "").strip()
        if status in closed_statuses:
            continue

        linked_deals = [
            active_deals_by_id[deal_id]
            for deal_id in _extract_task_deal_ids(task)
            if deal_id in active_deals_by_id
        ]
        if not linked_deals:
            continue

        deal = sorted(linked_deals, key=lambda item: float(item.get("amount") or 0.0), reverse=True)[0]
        days_overdue = max(int((now - deadline).total_seconds() // 86400), 0)
        item = {
            "task_id": str(task.get("id") or "").strip(),
            "task_title": str(task.get("title") or "").strip() or "Без названия",
            "task_status": status,
            "deadline": deadline,
            "days_overdue": days_overdue,
            "deal_id": deal.get("id"),
            "deal_title": deal.get("title"),
            "deal_card_url": deal.get("card_url"),
            "deal_amount": float(deal.get("amount") or 0.0),
            "deal_stage_name": deal.get("stage_name"),
            "manager_id": deal.get("assigned_id"),
            "manager_name": deal.get("assigned_name"),
        }
        overdue_tasks.append(item)

        manager_id = str(deal.get("assigned_id") or "").strip()
        manager_key = manager_id or str(deal.get("assigned_name") or "").strip()
        manager_row = by_manager.setdefault(
            manager_key,
            {
                "manager_id": manager_id or None,
                "manager_name": deal.get("assigned_name") or "без ответственного",
                "count": 0,
                "deals": [],
                "max_days_overdue": 0,
            },
        )
        manager_row["count"] += 1
        manager_row["max_days_overdue"] = max(manager_row["max_days_overdue"], days_overdue)
        manager_row["deals"].append(
            {
                "deal_id": deal.get("id"),
                "deal_title": deal.get("title"),
                "deal_card_url": deal.get("card_url"),
                "task_title": item["task_title"],
                "deadline": deadline,
                "days_overdue": days_overdue,
            }
        )

    overdue_tasks.sort(key=lambda item: (int(item["days_overdue"]), float(item["deal_amount"])), reverse=True)
    manager_rows = sorted(
        by_manager.values(),
        key=lambda item: (int(item["count"]), int(item["max_days_overdue"])),
        reverse=True,
    )
    return overdue_tasks, manager_rows


def _build_deadline_reschedule_focus_tasks(
    tasks: list[dict[str, Any]],
    *,
    active_deals_by_id: dict[str, dict[str, Any]],
    now: datetime,
    task_status_map: dict[str, str],
) -> list[dict[str, Any]]:
    closed_statuses = _closed_task_statuses(task_status_map)
    items: list[dict[str, Any]] = []

    for task in tasks:
        if str(task.get("status") or "").strip() in closed_statuses:
            continue

        deadline_change_count = _extract_task_deadline_change_count(task)
        if deadline_change_count <= 2:
            continue

        linked_deals = [
            active_deals_by_id[deal_id]
            for deal_id in _extract_task_deal_ids(task)
            if deal_id in active_deals_by_id
        ]
        if not linked_deals:
            continue

        deal = sorted(linked_deals, key=lambda item: float(item.get("amount") or 0.0), reverse=True)[0]
        manager_id = str(deal.get("assigned_id") or "").strip()
        manager_name = str(deal.get("assigned_name") or "").strip()
        if not manager_id or not manager_name:
            continue

        deadline = _parse_datetime(task.get("deadline"))
        days_overdue = max(int((now - deadline).total_seconds() // 86400), 0) if deadline and deadline < now else 0
        deadline_changed_at = _extract_task_deadline_changed_at(task)
        last_shift_age_days = (
            max(int((now - deadline_changed_at).total_seconds() // 86400), 0)
            if deadline_changed_at is not None and deadline_changed_at <= now
            else 0
        )

        items.append(
            {
                "task_id": str(task.get("id") or "").strip(),
                "task_title": str(task.get("title") or "").strip() or "Без названия",
                "deadline": deadline,
                "days_overdue": days_overdue,
                "deadline_change_count": deadline_change_count,
                "deadline_changed_at": deadline_changed_at,
                "last_shift_age_days": last_shift_age_days,
                "deal_id": deal.get("id"),
                "deal_title": deal.get("title"),
                "deal_card_url": deal.get("card_url"),
                "deal_amount": float(deal.get("amount") or 0.0),
                "manager_id": manager_id,
                "manager_name": manager_name,
            }
        )

    items.sort(
        key=lambda item: (
            int(item.get("deadline_change_count") or 0),
            int(int(item.get("days_overdue") or 0) > 0),
            int(item.get("days_overdue") or 0) or int(item.get("last_shift_age_days") or 0),
            float(item.get("deal_amount") or 0.0),
        ),
        reverse=True,
    )
    return items


def _normalize_deal(
    raw_deal: dict[str, Any],
    *,
    now: datetime,
    user_map: dict[str, str],
    stage_name_map: dict[str, str],
    source_name_map: dict[str, str],
    company_map: dict[str, str],
    contact_map: dict[str, str],
    department_heads: set[str],
    large_deal_amount: float,
    portal_base_url: str,
) -> dict[str, Any]:
    stage_id = str(raw_deal.get("stage_id") or raw_deal.get("STAGE_ID") or "").strip()
    stage_name = stage_name_map.get(stage_id) or _friendly_stage_name(stage_id, raw_deal.get("stage_description"))
    semantic_id = str(raw_deal.get("semantic_id") or raw_deal.get("STAGE_SEMANTIC_ID") or "").strip()
    created_at = _parse_datetime(raw_deal.get("created_at") or raw_deal.get("DATE_CREATE"))
    modified_at = _parse_datetime(raw_deal.get("updated_at") or raw_deal.get("DATE_MODIFY"))
    moved_at = _parse_datetime(raw_deal.get("moved_at") or raw_deal.get("MOVED_TIME"))
    last_activity_at = _parse_datetime(raw_deal.get("last_activity_at") or raw_deal.get("LAST_ACTIVITY_TIME"))
    last_communication_at = _parse_datetime(
        raw_deal.get("last_communication_at") or raw_deal.get("LAST_COMMUNICATION_TIME")
    )
    last_signal_at = last_communication_at or last_activity_at or modified_at or created_at
    last_communication_signal_at = last_communication_at or created_at
    inactive_days = (
        max(int((now - last_signal_at).total_seconds() // 86400), 0)
        if last_signal_at is not None
        else None
    )
    communication_gap_days = (
        max(int((now - last_communication_signal_at).total_seconds() // 86400), 0)
        if last_communication_signal_at is not None
        else None
    )
    today_created, yesterday_created = _today_flags(created_at, now)
    today_moved, yesterday_moved = _today_flags(moved_at, now)
    moved_in_last_week = bool(moved_at and moved_at >= (now - timedelta(days=7)))
    amount = _to_float(raw_deal.get("amount") or raw_deal.get("OPPORTUNITY"))
    probability = _to_float(raw_deal.get("probability") or raw_deal.get("PROBABILITY"))
    late_stage = _is_late_stage(stage_id, stage_name, probability)
    effective_probability = _effective_probability(
        probability,
        late_stage=late_stage,
        inactive_days=inactive_days,
    )
    won = _is_won_status(stage_id, stage_name, semantic_id)
    lost = _is_lost_status(stage_id, stage_name, semantic_id)
    closed = bool(raw_deal.get("closed")) or won or lost
    assigned_id = str(raw_deal.get("assigned_id") or raw_deal.get("ASSIGNED_BY_ID") or "").strip()
    relation_suffix = _company_contact_suffix(
        company_map,
        contact_map,
        raw_deal.get("company_id"),
        raw_deal.get("contact_id"),
    )
    title = str(raw_deal.get("title") or raw_deal.get("TITLE") or "").strip()
    if not title:
        title = f"Сделка {raw_deal.get('id') or raw_deal.get('ID') or ''}".strip()
    source_id = str(raw_deal.get("source_id") or raw_deal.get("SOURCE_ID") or "").strip()
    source_description = str(raw_deal.get("source_description") or raw_deal.get("SOURCE_DESCRIPTION") or "").strip()
    large_deal = amount >= float(large_deal_amount)
    leader_flag = _explicit_leader_flag(raw_deal.get("raw") if isinstance(raw_deal.get("raw"), dict) else raw_deal)

    next_step_at = _parse_datetime(raw_deal.get("next_step_at"))
    next_step_subject = str(raw_deal.get("next_step_subject") or "").strip() or None
    missing_next_step = next_step_at is None
    raw_payload = raw_deal.get("raw") if isinstance(raw_deal.get("raw"), dict) else raw_deal
    lost_reason = _extract_explicit_lost_reason(raw_payload, title=title, relation_suffix=relation_suffix) if lost else None

    return {
        "kind": "deal",
        "id": str(raw_deal.get("id") or raw_deal.get("ID") or "").strip(),
        "title": title,
        "card_url": build_deal_url(portal_base_url, raw_deal.get("id") or raw_deal.get("ID")),
        "assigned_id": assigned_id,
        "assigned_name": _assigned_name(user_map, assigned_id),
        "assigned_is_department_head": assigned_id in department_heads,
        "stage_id": stage_id,
        "stage_name": stage_name,
        "semantic_id": semantic_id,
        "amount": amount,
        "probability": probability,
        "effective_probability": effective_probability,
        "created_at": created_at,
        "modified_at": modified_at,
        "moved_at": moved_at,
        "last_activity_at": last_activity_at,
        "last_communication_at": last_communication_at,
        "last_signal_at": last_signal_at,
        "inactive_days": inactive_days,
        "communication_gap_days": communication_gap_days,
        "next_step_at": next_step_at,
        "next_step_subject": next_step_subject,
        "next_step_source": str(raw_deal.get("next_step_source") or "").strip() or None,
        "next_step_activity_id": str(raw_deal.get("next_step_activity_id") or "").strip() or None,
        "next_step_provider_id": str(raw_deal.get("next_step_provider_id") or "").strip() or None,
        "next_step_provider_type_id": str(raw_deal.get("next_step_provider_type_id") or "").strip() or None,
        "next_step_supported": True,
        "missing_next_step": missing_next_step,
        "today_created": today_created,
        "yesterday_created": yesterday_created,
        "today_moved": today_moved,
        "yesterday_moved": yesterday_moved,
        "moved_in_last_week": moved_in_last_week,
        "meeting_today": False,
        "meeting_titles": [],
        "active": not closed,
        "won": won,
        "lost": lost,
        "late_stage": late_stage and not closed,
        "high_probability": (effective_probability >= 70.0) or (late_stage and effective_probability >= 55.0),
        "large_deal": large_deal,
        "leader_flag": leader_flag,
        "needs_leader": leader_flag or (large_deal and ((inactive_days or 0) >= 5 or late_stage)),
        "source_id": source_id or None,
        "source_name": source_name_map.get(source_id) or source_id or "Источник не указан",
        "source_description": source_description or None,
        "lost_reason": lost_reason,
        "company_id": str(raw_deal.get("company_id") or "").strip() or None,
        "contact_id": str(raw_deal.get("contact_id") or "").strip() or None,
        "relation_suffix": relation_suffix,
        "raw": raw_payload,
    }


def _normalize_lead(
    raw_lead: dict[str, Any],
    *,
    now: datetime,
    user_map: dict[str, str],
    company_map: dict[str, str],
    contact_map: dict[str, str],
    portal_base_url: str,
) -> dict[str, Any]:
    status_id = str(raw_lead.get("stage_id") or raw_lead.get("status_id") or raw_lead.get("STATUS_ID") or "").strip()
    status_name = _friendly_stage_name(status_id, raw_lead.get("stage_description") or raw_lead.get("STATUS_DESCRIPTION"))
    semantic_id = str(raw_lead.get("semantic_id") or raw_lead.get("STATUS_SEMANTIC_ID") or "").strip()
    created_at = _parse_datetime(raw_lead.get("created_at") or raw_lead.get("DATE_CREATE"))
    modified_at = _parse_datetime(raw_lead.get("updated_at") or raw_lead.get("DATE_MODIFY"))
    last_activity_at = _parse_datetime(raw_lead.get("last_activity_at") or raw_lead.get("LAST_ACTIVITY_TIME"))
    last_communication_at = _parse_datetime(
        raw_lead.get("last_communication_at") or raw_lead.get("LAST_COMMUNICATION_TIME")
    )
    last_signal_at = last_communication_at or last_activity_at or modified_at or created_at
    inactive_days = (
        max(int((now - last_signal_at).total_seconds() // 86400), 0)
        if last_signal_at is not None
        else None
    )
    today_created, yesterday_created = _today_flags(created_at, now)
    assigned_id = str(raw_lead.get("assigned_id") or raw_lead.get("ASSIGNED_BY_ID") or "").strip()
    qualified = _is_qualified_status(status_id, status_name, semantic_id)
    won = _is_won_status(status_id, status_name, semantic_id)
    lost = _is_lost_status(status_id, status_name, semantic_id)
    relation_suffix = _company_contact_suffix(
        company_map,
        contact_map,
        raw_lead.get("company_id"),
        raw_lead.get("contact_id"),
    )
    title = str(raw_lead.get("title") or raw_lead.get("TITLE") or raw_lead.get("NAME") or "").strip()
    if not title:
        title = f"Лид {raw_lead.get('id') or raw_lead.get('ID') or ''}".strip()

    next_step_at = last_communication_at or last_activity_at
    missing_next_step = next_step_at is None

    return {
        "kind": "lead",
        "id": str(raw_lead.get("id") or raw_lead.get("ID") or "").strip(),
        "title": title,
        "card_url": build_lead_url(portal_base_url, raw_lead.get("id") or raw_lead.get("ID")),
        "assigned_id": assigned_id,
        "assigned_name": _assigned_name(user_map, assigned_id),
        "status_id": status_id,
        "status_name": status_name,
        "semantic_id": semantic_id,
        "created_at": created_at,
        "modified_at": modified_at,
        "last_activity_at": last_activity_at,
        "last_communication_at": last_communication_at,
        "last_signal_at": last_signal_at,
        "inactive_days": inactive_days,
        "next_step_at": next_step_at,
        "next_step_supported": True,
        "missing_next_step": missing_next_step,
        "today_created": today_created,
        "yesterday_created": yesterday_created,
        "qualified": qualified,
        "won": won,
        "lost": lost,
        "active": not (won or lost),
        "company_id": str(raw_lead.get("company_id") or "").strip() or None,
        "contact_id": str(raw_lead.get("contact_id") or "").strip() or None,
        "relation_suffix": relation_suffix,
        "raw": raw_lead.get("raw") if isinstance(raw_lead.get("raw"), dict) else raw_lead,
    }


def analyze_pipeline(
    snapshot: dict[str, Any],
    *,
    now: datetime | None = None,
    large_deal_amount: float = 150000.0,
    inactivity_days: int = 5,
    stale_communication_days: int = 14,
) -> dict[str, Any]:
    now = (now or datetime.now(MOSCOW_TZ)).astimezone(MOSCOW_TZ)

    limitations = list(snapshot.get("limitations") or [])
    if snapshot.get("source") == "not_configured":
        limitations.append("Bitrix CRM не настроен: отсутствует BITRIX_WEBHOOK_URL.")
    if not snapshot.get("next_step_source"):
        limitations.append("Следующий шаг не найден: нет подтверждённого источника next step в Bitrix.")
    portal_base_url = str(snapshot.get("portal_base_url") or "").strip()

    user_map = {
        user_id: _user_name(user)
        for user_id, user in (snapshot.get("responsibles") or {}).items()
        if str(user_id).strip()
    }
    company_map = {
        str(item.get("id") or "").strip(): str(item.get("title") or "").strip()
        for item in snapshot.get("companies") or []
        if str(item.get("id") or "").strip()
    }
    contact_map = {
        str(item.get("id") or "").strip(): str(item.get("full_name") or "").strip()
        for item in snapshot.get("contacts") or []
        if str(item.get("id") or "").strip()
    }
    department_heads = {
        str(item.get("head_user_id") or "").strip()
        for item in snapshot.get("departments") or []
        if str(item.get("head_user_id") or "").strip()
    }
    deal_stage_name_map = _status_name_map(snapshot.get("deal_stage_map") or [])
    deal_source_name_map = _source_name_map(snapshot.get("deal_source_map") or [])
    meeting_stage_name_map = _status_name_map(snapshot.get("meeting_stage_map") or [])
    brief_stage_name_map = _status_name_map(snapshot.get("brief_stage_map") or [])

    recent_deals = _dedupe_entities(
        [
            _normalize_deal(
                raw_deal,
                now=now,
                user_map=user_map,
                stage_name_map=deal_stage_name_map,
                source_name_map=deal_source_name_map,
                company_map=company_map,
                contact_map=contact_map,
                department_heads=department_heads,
                large_deal_amount=large_deal_amount,
                portal_base_url=portal_base_url,
            )
            for raw_deal in snapshot.get("recent_deals") or []
        ]
    )
    active_deals = _dedupe_entities(
        [
            _normalize_deal(
                raw_deal,
                now=now,
                user_map=user_map,
                stage_name_map=deal_stage_name_map,
                source_name_map=deal_source_name_map,
                company_map=company_map,
                contact_map=contact_map,
                department_heads=department_heads,
                large_deal_amount=large_deal_amount,
                portal_base_url=portal_base_url,
            )
            for raw_deal in snapshot.get("active_deals") or []
        ]
    )
    active_deals = [deal for deal in active_deals if deal.get("active")]
    closed_deals = _dedupe_entities(
        [
            _normalize_deal(
                raw_deal,
                now=now,
                user_map=user_map,
                stage_name_map=deal_stage_name_map,
                source_name_map=deal_source_name_map,
                company_map=company_map,
                contact_map=contact_map,
                department_heads=department_heads,
                large_deal_amount=large_deal_amount,
                portal_base_url=portal_base_url,
            )
            for raw_deal in snapshot.get("closed_deals") or []
        ]
    )
    recent_leads: list[dict[str, Any]] = []
    active_leads: list[dict[str, Any]] = []
    conducted_meetings = [
        _normalize_dynamic_item(
            item,
            now=now,
            user_map=user_map,
            stage_name_map=meeting_stage_name_map,
            portal_base_url=portal_base_url,
            entity_type_id=1048,
        )
        for item in snapshot.get("conducted_meetings") or []
    ]
    accepted_briefs = [
        _normalize_dynamic_item(
            item,
            now=now,
            user_map=user_map,
            stage_name_map=brief_stage_name_map,
            portal_base_url=portal_base_url,
            entity_type_id=1056,
        )
        for item in snapshot.get("accepted_briefs") or []
    ]

    lost_deals_yesterday = [
        deal
        for deal in closed_deals
        if deal.get("lost") and deal.get("yesterday_moved")
    ]
    new_deals_yesterday = sorted(
        [
            deal
            for deal in active_deals
            if deal.get("yesterday_moved") and _is_brief_prep_deal(deal)
        ],
        key=lambda item: (
            _parse_datetime(item.get("moved_at")) or datetime.min.replace(tzinfo=MOSCOW_TZ),
            float(item.get("amount") or 0.0),
        ),
        reverse=True,
    )
    source_stats_yesterday = _aggregate_sources(new_deals_yesterday)
    deals_without_next_step = [deal for deal in active_deals if deal.get("missing_next_step")]
    hot_stage_deals = [
        deal
        for deal in active_deals
        if _is_hot_stage_deal(deal)
    ]
    stale_communication_deals = [
        deal
        for deal in active_deals
        if int(deal.get("communication_gap_days") or 0) >= int(stale_communication_days)
    ]
    moving_deals = [
        deal
        for deal in active_deals
        if int(deal.get("inactive_days") or 0) < int(inactivity_days)
    ]
    active_deals_by_id = {
        str(deal.get("id") or "").strip(): deal
        for deal in active_deals
        if str(deal.get("id") or "").strip()
    }
    overdue_tasks, overdue_tasks_by_manager = _build_overdue_task_stats(
        list(snapshot.get("tasks") or []),
        active_deals_by_id=active_deals_by_id,
        now=now,
        task_status_map=dict(snapshot.get("task_status_map") or {}),
    )
    overdue_task_deal_ids = {
        str(item.get("deal_id") or "").strip()
        for item in overdue_tasks
        if str(item.get("deal_id") or "").strip()
    }
    deadline_reschedule_focus_tasks = _build_deadline_reschedule_focus_tasks(
        list(snapshot.get("tasks") or []),
        active_deals_by_id=active_deals_by_id,
        now=now,
        task_status_map=dict(snapshot.get("task_status_map") or {}),
    )

    stage_stats = _build_stage_stats(active_deals)
    owner_stats = _build_owner_stats(active_deals)

    metrics = {
        "new_deals_today": sum(
            1
            for deal in active_deals
            if deal.get("today_moved") and _is_brief_prep_deal(deal)
        ),
        "new_deals_yesterday": len(new_deals_yesterday),
        "conducted_meetings_today": sum(1 for item in conducted_meetings if item.get("today_moved")),
        "conducted_meetings_yesterday": sum(1 for item in conducted_meetings if item.get("yesterday_moved")),
        "accepted_briefs_today": sum(1 for item in accepted_briefs if item.get("today_moved")),
        "accepted_briefs_yesterday": sum(1 for item in accepted_briefs if item.get("yesterday_moved")),
        "lost_deals_yesterday": len(lost_deals_yesterday),
        "lost_deals_yesterday_amount": sum(float(deal.get("amount") or 0.0) for deal in lost_deals_yesterday),
        "deals_in_work": len(active_deals),
        "moving_deals": len(moving_deals),
        "moving_deals_last_week": sum(1 for deal in active_deals if deal.get("moved_in_last_week")),
        "stagnant_deals_last_week": sum(1 for deal in active_deals if not deal.get("moved_in_last_week")),
        "pipeline_amount": sum(float(deal.get("amount") or 0.0) for deal in active_deals),
        "hot_stage_deals": len(hot_stage_deals),
        "hot_stage_amount": sum(float(deal.get("amount") or 0.0) for deal in hot_stage_deals),
        "high_probability_deals": sum(1 for deal in active_deals if deal.get("high_probability")),
        "high_probability_amount": sum(
            float(deal.get("amount") or 0.0)
            for deal in active_deals
            if deal.get("high_probability")
        ),
        "deals_without_next_step": len(deals_without_next_step),
        "deals_without_next_step_amount": sum(float(deal.get("amount") or 0.0) for deal in deals_without_next_step),
        "deals_without_next_step_late_stage": sum(1 for deal in deals_without_next_step if deal.get("late_stage")),
        "stuck_deals": sum(1 for deal in active_deals if int(deal.get("inactive_days") or 0) >= int(inactivity_days)),
        "stale_communication_deals": len(stale_communication_deals),
        "stale_communication_amount": sum(float(deal.get("amount") or 0.0) for deal in stale_communication_deals),
        "overdue_deal_tasks": len(overdue_tasks),
        "overdue_deal_task_deals": len(overdue_task_deal_ids),
        "overdue_deal_task_amount": sum(
            float(active_deals_by_id[deal_id].get("amount") or 0.0)
            for deal_id in overdue_task_deal_ids
            if deal_id in active_deals_by_id
        ),
        "expected_forecast_amount": sum(
            float(deal.get("amount") or 0.0) * max(float(deal.get("effective_probability") or 0.0), 0.0) / 100.0
            for deal in active_deals
        ),
    }

    return {
        "now": now,
        "timezone": "Europe/Moscow",
        "source": snapshot.get("source") or "unknown",
        "portal_base_url": portal_base_url,
        "limitations": list(dict.fromkeys(limitations)),
        "users": user_map,
        "deals": recent_deals,
        "active_deals": active_deals,
        "closed_deals": closed_deals,
        "lost_deals_yesterday": lost_deals_yesterday,
        "new_deals_yesterday": new_deals_yesterday,
        "new_deal_sources_yesterday": source_stats_yesterday,
        "leads": recent_leads,
        "active_leads": active_leads,
        "conducted_meetings": conducted_meetings,
        "accepted_briefs": accepted_briefs,
        "hot_stage_deals": sorted(
            hot_stage_deals,
            key=lambda item: float(item.get("amount") or 0.0),
            reverse=True,
        ),
        "deals_without_next_step_items": sorted(
            deals_without_next_step,
            key=lambda item: (
                int(bool(item.get("late_stage"))),
                float(item.get("amount") or 0.0),
                int(item.get("inactive_days") or 0),
            ),
            reverse=True,
        ),
        "stale_communication_deals": sorted(
            stale_communication_deals,
            key=lambda item: (int(item.get("communication_gap_days") or 0), float(item.get("amount") or 0.0)),
            reverse=True,
        ),
        "overdue_deal_tasks": overdue_tasks,
        "overdue_deal_tasks_by_manager": overdue_tasks_by_manager,
        "deadline_reschedule_focus_tasks": deadline_reschedule_focus_tasks,
        "stage_stats": stage_stats,
        "owner_stats": owner_stats,
        "metrics": metrics,
    }
