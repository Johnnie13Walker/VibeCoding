"""HTML-форматирование управленческих sales-отчетов для Telegram."""

from __future__ import annotations

from datetime import datetime, timedelta
from html import escape
from typing import Any
from zoneinfo import ZoneInfo

MOSCOW_TZ = ZoneInfo("Europe/Moscow")
DEFAULT_TELEMARKETING_MIN_DIALS = 40
DEFAULT_TELEMARKETING_HIGH_DIALS = 30
DEFAULT_TELEMARKETING_VERY_LOW_CALLS = 1


def _format_money(amount: float | int | None) -> str:
    if amount in (None, ""):
        return "данных недостаточно"
    return f"{int(round(float(amount))):,}".replace(",", " ") + " ₽"


def _money_html(amount: float | int | None) -> str:
    return f"<b>{_safe(_format_money(amount))}</b>"


def _format_dt(value: datetime | None) -> str:
    if value is None:
        return "без даты"
    return value.astimezone(MOSCOW_TZ).strftime("%d.%m %H:%M")


def _safe(value: Any) -> str:
    return escape(str(value or "").strip(), quote=False)


def _safe_attr(value: Any) -> str:
    return escape(str(value or "").strip(), quote=True)


def _short_title(value: Any, *, max_len: int = 72) -> str:
    raw = str(value or "").strip()
    if len(raw) <= max_len:
        return raw
    shortened = raw[: max_len - 1].rsplit(" ", 1)[0].strip()
    if len(shortened) < max_len // 2:
        shortened = raw[: max_len - 1].strip()
    return f"{shortened.rstrip(' /,-')}\u2026"


def _truncate_with_dots(value: Any, *, max_len: int = 70) -> str:
    raw = " ".join(str(value or "").split()).strip()
    if len(raw) <= max_len:
        return raw
    shortened = raw[: max_len - 3].rsplit(" ", 1)[0].strip()
    if len(shortened) < max_len // 2:
        shortened = raw[: max_len - 3].strip()
    return f"{shortened.rstrip(' /,-')}..."


def _entity_html(item: dict[str, Any]) -> str:
    kind = str(item.get("kind") or item.get("entity_type") or "").strip().lower()
    raw_title = item.get("title") or item.get("name") or "Без названия"
    max_len = 56 if kind == "lead" else 84
    title = _safe(_short_title(raw_title, max_len=max_len))
    url = str(item.get("card_url") or "").strip()
    manager_name = str(item.get("assigned_name") or "").strip() or "без ответственного"
    manager_html = f"<b>{_safe(manager_name)}</b>"
    if url:
        return f'<a href="{_safe_attr(url)}">{title}</a> — {manager_html}'
    return f"{title} — {manager_html}"


def _bullet_list(items: list[str], fallback: str) -> list[str]:
    return [f"• {item}" for item in items] if items else [f"• {_safe(fallback)}"]


def _numbered_list(items: list[str], fallback: str) -> list[str]:
    if not items:
        return [f"1. {_safe(fallback)}"]
    return [f"{idx}. {item}" for idx, item in enumerate(items[:3], start=1)]


def _append_limitations(lines: list[str], limitations: list[str]) -> list[str]:
    if not limitations:
        return lines
    lines.extend(["", "ℹ️ Ограничения"])
    lines.extend(f"• {_safe(item)}" for item in limitations[:2])
    return lines


def _preformatted_block(lines: list[str]) -> str:
    return "<pre>" + "\n".join(escape(str(line), quote=False) for line in lines) + "</pre>"


def _reason_block(item: dict[str, Any]) -> str:
    detail_parts = []
    if item.get("amount") not in (None, ""):
        detail_parts.append(f"сумма: {_money_html(item.get('amount'))}")
    detail_parts.append(_safe(", ".join(item.get("reasons") or []) or "нужен контроль"))
    detail = "; ".join(detail_parts)
    return f"{_entity_html(item)}\n{detail}"


def _signal_html(value: Any) -> str:
    raw = str(value or "").strip()
    if " — " not in raw:
        return _safe(raw)
    manager_name, detail = raw.split(" — ", 1)
    return f"<b>{_safe(manager_name)}</b> — {_safe(detail)}"


def _source_line(item: dict[str, Any]) -> str:
    return f"{_safe(item.get('source_name') or 'Источник не указан')} — {_safe(str(item.get('count') or 0))}"


def _new_deal_item(item: dict[str, Any]) -> str:
    source = str(item.get("source_name") or "Источник не указан").strip()
    if item.get("source_description"):
        source_description = " ".join(str(item.get("source_description") or "").split())
        source = f"{source} ({_short_title(source_description, max_len=72)})"
    return f"{_entity_html(item)}\nсумма: {_money_html(item.get('amount'))}; источник: {_safe(source)}"


def _lost_deal_item(item: dict[str, Any]) -> str:
    reason = " ".join(str(item.get("lost_reason") or "").split()) or "причина не указана в CRM"
    reason = _short_title(reason, max_len=140)
    return f"{_entity_html(item)}\nсумма: {_money_html(item.get('amount'))}; причина: {_safe(reason)}"


def _meeting_item(item: dict[str, Any]) -> str:
    return f"{_entity_html(item)}\nпроведена: {_safe(_format_dt(item.get('moved_at')))}"


def _brief_item(item: dict[str, Any]) -> str:
    return f"{_entity_html(item)}\nпринят: {_safe(_format_dt(item.get('moved_at')))}"


def _task_item(item: dict[str, Any]) -> str:
    deal_title = _safe(_short_title(item.get("deal_title") or "Сделка"))
    deal_url = str(item.get("deal_card_url") or "").strip()
    deal_html = f'<a href="{_safe_attr(deal_url)}">{deal_title}</a>' if deal_url else deal_title
    days_overdue = int(item.get("days_overdue") or 0)
    overdue_text = "срок прошёл сегодня" if days_overdue <= 0 else f"просрочено на {days_overdue} дн."
    return (
        f"{deal_html} — <b>{_safe(item.get('manager_name') or 'без ответственного')}</b>\n"
        f"{_safe(overdue_text)}; "
        f"задача: {_safe(item.get('task_title') or '-')}; дедлайн: {_safe(_format_dt(item.get('deadline')))}"
    )


def _deal_link(title: Any, url: Any) -> str:
    deal_title = _safe(_short_title(title or "Сделка", max_len=64))
    raw_url = str(url or "").strip()
    if raw_url:
        return f'<a href="{_safe_attr(raw_url)}">{deal_title}</a>'
    return deal_title


def _focus_manager_task_item(item: dict[str, Any]) -> str:
    examples: list[str] = []
    seen_keys: set[str] = set()
    for example in item.get("deals") or []:
        deal_title = str(example.get("deal_title") or "").strip()
        deal_url = str(example.get("deal_card_url") or "").strip()
        key = deal_url or deal_title
        if not key or key in seen_keys:
            continue
        seen_keys.add(key)
        examples.append(_deal_link(deal_title, deal_url))
        if len(examples) >= 3:
            break
    max_days_overdue = int(item.get("max_days_overdue") or 0)
    overdue_text = "макс просрочка: сегодня" if max_days_overdue <= 0 else f"макс просрочка: {max_days_overdue} дн."
    lines = [
        f"{_safe(item.get('manager_name') or 'без ответственного')} — {_safe(str(item.get('count') or 0))}",
        _safe(overdue_text),
    ]
    if examples:
        lines.append(f"примеры: {', '.join(examples)}")
    return "\n".join(lines)


def _rop_focus_task_item(item: dict[str, Any]) -> str:
    manager_name = _safe(item.get("manager_name") or "без ответственного")
    deal_html = _deal_link(item.get("deal_title") or "Сделка", item.get("deal_card_url"))
    task_title = _safe(_truncate_with_dots(item.get("task_title") or "Без названия", max_len=70))
    move_count = int(item.get("deadline_change_count") or 0)
    move_label = _ru_noun(move_count, "перенос", "переноса", "переносов")
    return f"{manager_name} — {deal_html} → {task_title} — {_safe(str(move_count))} {_safe(move_label)}"


def _overdue_manager_lines(items: list[dict[str, Any]]) -> list[str]:
    filtered = [item for item in items if int(item.get("count") or 0) > 0]
    if not filtered:
        return ["🗂 Просрочки по менеджерам: нет"]
    return [
        "🗂 Просрочки по менеджерам",
        *_bullet_list([_focus_manager_task_item(item) for item in filtered], "Просрочек по менеджерам нет."),
    ]


def _no_next_step_item(item: dict[str, Any]) -> str:
    details = [f"сумма: {_money_html(item.get('amount'))}"]
    if item.get("stage_name"):
        details.append(f"стадия: {_safe(item.get('stage_name'))}")
    if item.get("inactive_days") is not None:
        details.append(f"без движения: {_safe(str(item.get('inactive_days')))} дн.")
    return f"{_entity_html(item)}\n{'; '.join(details)}"


def _daily_no_next_step_item(item: dict[str, Any]) -> str:
    return (
        f"{_entity_html(item)}\n"
        f"сумма: {_money_html(item.get('amount'))}; стадия: {_safe(item.get('stage_name') or '-')}; "
        "следующего шага нет"
    )


def _stale_deal_item(item: dict[str, Any]) -> str:
    return (
        f"{_entity_html(item)}\n"
        f"сумма: {_money_html(item.get('amount'))}; стадия: {_safe(item.get('stage_name') or '-')}; "
        f"без коммуникации: {_safe(str(item.get('communication_gap_days') or 0))} дн."
    )


def _sorted_stale_deals(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(
        items,
        key=lambda item: (
            int(item.get("communication_gap_days") or 0),
            float(item.get("amount") or 0.0),
        ),
        reverse=True,
    )


def _sorted_no_next_step_deals(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(
        items,
        key=lambda item: (
            float(item.get("amount") or 0.0),
            int(bool(item.get("late_stage"))),
            float(item.get("effective_probability") or 0.0),
            int(item.get("inactive_days") or 0),
        ),
        reverse=True,
    )


def _format_share(part: int, total: int) -> str:
    if total <= 0:
        return "0%"
    share = round((float(part) / float(total)) * 100.0, 1)
    if float(share).is_integer():
        return f"{int(share)}%"
    return f"{share:.1f}%"


def _ru_noun(count: int, one: str, few: str, many: str) -> str:
    value = abs(int(count)) % 100
    if 11 <= value <= 14:
        return many
    tail = value % 10
    if tail == 1:
        return one
    if 2 <= tail <= 4:
        return few
    return many


def _rop_deal_reason(item: dict[str, Any], risk_item: dict[str, Any] | None) -> str:
    communication_gap = int(item.get("communication_gap_days") or 0)
    inactive_days = int(item.get("inactive_days") or 0)
    if communication_gap > 0:
        return f"{communication_gap} дн без коммуникации"
    if item.get("missing_next_step"):
        return "нет следующего шага"
    if item.get("late_stage") and inactive_days > 0:
        return f"{inactive_days} дн без движения"
    if item.get("late_stage"):
        return "поздняя стадия"
    if item.get("large_deal"):
        return "крупная сумма"
    if risk_item and risk_item.get("reasons"):
        return str((risk_item.get("reasons") or ["нужен контроль"])[0] or "нужен контроль").strip()
    if item.get("needs_leader"):
        return "нужен контроль РОПа"
    return "сделка требует внимания"


def _rop_deal_priority(item: dict[str, Any], risk_item: dict[str, Any] | None) -> tuple[float, int, int, int, int, int]:
    return (
        float(item.get("amount") or 0.0),
        int(bool(item.get("late_stage"))),
        int(item.get("communication_gap_days") or 0),
        int(bool(item.get("missing_next_step"))),
        int((risk_item or {}).get("severity") or 0),
        int(bool(item.get("needs_leader"))),
    )


def _build_rop_focus_lines(
    analysis: dict[str, Any],
    risk_report: dict[str, Any],
    communications_summary: dict[str, Any] | None = None,
) -> list[str]:
    communications_summary = communications_summary or {}
    metrics = analysis.get("metrics") or {}
    stale_days_limit = 14
    thresholds = communications_summary.get("thresholds") or {}
    if thresholds:
        stale_days_limit = int(thresholds.get("stale_communication_days") or stale_days_limit)

    risk_by_deal_id = {
        str(item.get("entity_id") or "").strip(): item
        for item in (risk_report.get("deal_risks") or [])
        if str(item.get("entity_id") or "").strip()
    }
    candidate_deals: dict[str, dict[str, Any]] = {}
    for source_items in (
        risk_report.get("high_risk_deals") or [],
        risk_report.get("leader_attention") or [],
        risk_report.get("focus_deals") or [],
        analysis.get("deals_without_next_step_items") or [],
        analysis.get("stale_communication_deals") or [],
    ):
        for item in source_items:
            deal_id = str(item.get("id") or item.get("entity_id") or "").strip()
            if not deal_id or deal_id in candidate_deals:
                continue
            candidate_deals[deal_id] = item

    control_items: list[str] = []
    for item in sorted(
        candidate_deals.values(),
        key=lambda row: _rop_deal_priority(row, risk_by_deal_id.get(str(row.get("id") or "").strip())),
        reverse=True,
    )[:7]:
        risk_item = risk_by_deal_id.get(str(item.get("id") or "").strip())
        detail = " • ".join(
            [
                _money_html(item.get("amount")),
                _safe(item.get("stage_name") or "Без стадии"),
                _safe(_rop_deal_reason(item, risk_item)),
            ]
        )
        control_items.append(f"{_entity_html(item)}\n{detail}")

    manager_stats = list(communications_summary.get("manager_stats") or communications_summary.get("managers") or [])
    team_metrics = communications_summary.get("team_metrics") or {}
    manager_count = int(team_metrics.get("manager_count") or len(manager_stats) or 0)
    overdue_limit = int(thresholds.get("overdue_tasks_limit") or 1)
    missing_next_step_limit = int(thresholds.get("missing_next_step_limit") or 3)
    lost_deals_limit = int(thresholds.get("lost_deals_limit") or 2)
    late_stage_stuck_limit = int(thresholds.get("late_stage_stuck_limit") or 2)

    team_rows: list[tuple[tuple[int, int, int], str, str, dict[str, Any]]] = []
    for item in manager_stats:
        manager_name = str(item.get("manager_name") or "без ответственного").strip()
        reason = ""
        priority = (0, 0, 0)
        if int(item.get("overdue_tasks_count") or 0) >= overdue_limit:
            count = int(item.get("overdue_tasks_count") or 0)
            reason = f"{count} {_ru_noun(count, 'просрочка', 'просрочки', 'просрочек')}"
            priority = (7, count, int(item.get("max_days_overdue") or 0))
        elif bool(item.get("no_activity")):
            reason = "нет активности за предыдущий рабочий день"
            priority = (6, 0, 0)
        elif bool(item.get("low_connect")):
            reason = "много наборов, мало разговоров"
            priority = (5, int(item.get("dials") or 0), 0)
        elif int(item.get("missing_next_step_count") or 0) >= missing_next_step_limit:
            count = int(item.get("missing_next_step_count") or 0)
            reason = f"{count} {_ru_noun(count, 'сделка', 'сделки', 'сделок')} без следующего шага"
            priority = (4, count, int(item.get("total_known") or 0))
        elif int(item.get("stale_communication_count") or 0) > 0:
            count = int(item.get("stale_communication_count") or 0)
            reason = f"{count} {_ru_noun(count, 'сделка', 'сделки', 'сделок')} без коммуникации > {stale_days_limit} дн."
            priority = (3, count, int(item.get("total_known") or 0))
        elif int(item.get("lost_deals_yesterday_count") or 0) >= lost_deals_limit:
            count = int(item.get("lost_deals_yesterday_count") or 0)
            reason = f"{count} {_ru_noun(count, 'отказ', 'отказа', 'отказов')} за предыдущий рабочий день"
            priority = (2, count, 0)
        elif int(item.get("late_stage_stuck_count") or 0) >= late_stage_stuck_limit:
            count = int(item.get("late_stage_stuck_count") or 0)
            reason = f"{count} {_ru_noun(count, 'поздняя стадия', 'поздние стадии', 'поздних стадий')} без движения"
            priority = (1, count, 0)
        elif bool(item.get("low_activity")):
            reason = "низкая коммуникационная активность"
            priority = (0, int(item.get("total_known") or 0), 0)
        if reason:
            team_rows.append((priority, manager_name, f"<b>{_safe(manager_name)}</b> — {_safe(reason)}", item))

    team_rows.sort(key=lambda row: row[0], reverse=True)
    team_items = [row[2] for row in team_rows[:7]]

    deals_in_work = int(metrics.get("deals_in_work") or 0)
    without_next_step = int(metrics.get("deals_without_next_step") or 0)
    stuck_deals = int(metrics.get("stuck_deals") or 0)
    stale_deals = int(metrics.get("stale_communication_deals") or 0)
    managers_with_overdue_tasks = int(team_metrics.get("managers_with_overdue_tasks") or 0)
    managers_with_low_communication = int(team_metrics.get("managers_with_low_communication") or 0)
    managers_with_no_activity = int(team_metrics.get("managers_with_no_activity") or 0)
    lost_count = int(metrics.get("lost_deals_yesterday") or 0)
    lost_amount = metrics.get("lost_deals_yesterday_amount")
    department_items = [
        f"сделок без следующего шага: {_safe(str(without_next_step))} из {_safe(str(deals_in_work))} ({_safe(_format_share(without_next_step, deals_in_work))})",
        f"сделок без движения: {_safe(str(stuck_deals))} из {_safe(str(deals_in_work))} ({_safe(_format_share(stuck_deals, deals_in_work))})",
        f"сделок без коммуникации > {_safe(str(stale_days_limit))} дн.: {_safe(str(stale_deals))} из {_safe(str(deals_in_work))} ({_safe(_format_share(stale_deals, deals_in_work))})",
        f"менеджеров с просрочками: {_safe(str(managers_with_overdue_tasks))} из {_safe(str(manager_count))} ({_safe(_format_share(managers_with_overdue_tasks, manager_count))})",
        f"менеджеров со слабой коммуникацией: {_safe(str(managers_with_low_communication))} из {_safe(str(manager_count))} ({_safe(_format_share(managers_with_low_communication, manager_count))})",
        f"менеджеров без активности за предыдущий рабочий день: {_safe(str(managers_with_no_activity))} из {_safe(str(manager_count))}",
        f"отказов за предыдущий рабочий день: {_safe(str(lost_count))} / {_money_html(lost_amount)}",
    ]

    actions: list[str] = []
    used_keys: set[str] = set()
    if team_rows:
        top_team_item = team_rows[0][3]
        manager_name = str(top_team_item.get("manager_name") or "менеджера").strip()
        if int(top_team_item.get("overdue_tasks_count") or 0) >= overdue_limit:
            count = int(top_team_item.get("overdue_tasks_count") or 0)
            actions.append(
                f"Разобрать {_safe(str(count))} {_safe(_ru_noun(count, 'просроченную задачу', 'просроченные задачи', 'просроченных задач'))} {_safe(manager_name)}"
            )
            used_keys.add(f"manager:{manager_name}:overdue")
        elif bool(top_team_item.get("no_activity")):
            actions.append(f"Проверить, почему у {_safe(manager_name)} не было активности за предыдущий рабочий день")
            used_keys.add(f"manager:{manager_name}:inactive")

    for item in analysis.get("stale_communication_deals") or []:
        deal_id = str(item.get("id") or "").strip()
        if not deal_id or deal_id in used_keys:
            continue
        actions.append(
            f"Вернуть в контакт {_entity_html(item)}\n{_safe(str(item.get('communication_gap_days') or 0))} дн без коммуникации"
        )
        used_keys.add(deal_id)
        break

    for item in sorted(
        manager_stats,
        key=lambda row: int(row.get("missing_next_step_count") or 0),
        reverse=True,
    ):
        count = int(item.get("missing_next_step_count") or 0)
        manager_name = str(item.get("manager_name") or "").strip()
        key = f"manager:{manager_name}:next_step"
        if count < missing_next_step_limit or key in used_keys:
            continue
        actions.append(
            f"Проверить {_safe(str(count))} {_safe(_ru_noun(count, 'сделку', 'сделки', 'сделок'))} без следующего шага у {_safe(manager_name)}"
        )
        used_keys.add(key)
        break

    for item in sorted(
        manager_stats,
        key=lambda row: int(row.get("lost_deals_yesterday_count") or 0),
        reverse=True,
    ):
        count = int(item.get("lost_deals_yesterday_count") or 0)
        manager_name = str(item.get("manager_name") or "").strip()
        key = f"manager:{manager_name}:lost"
        if count < lost_deals_limit or key in used_keys:
            continue
        actions.append(f"Разобрать {_safe(str(count))} {_safe(_ru_noun(count, 'отказ', 'отказа', 'отказов'))} {_safe(manager_name)} за предыдущий рабочий день")
        used_keys.add(key)
        break

    for item in sorted(
        candidate_deals.values(),
        key=lambda row: _rop_deal_priority(row, risk_by_deal_id.get(str(row.get("id") or "").strip())),
        reverse=True,
    ):
        deal_id = str(item.get("id") or "").strip()
        if not deal_id or deal_id in used_keys:
            continue
        if item.get("missing_next_step"):
            actions.append(f"Зафиксировать следующий шаг по {_entity_html(item)}")
        else:
            actions.append(f"Проверить движение по {_entity_html(item)}")
        used_keys.add(deal_id)
        if len(actions) >= 5:
            break

    focus_task_items = [
        _rop_focus_task_item(item)
        for item in (analysis.get("deadline_reschedule_focus_tasks") or [])[:10]
        if str(item.get("deal_id") or "").strip() and str(item.get("manager_name") or "").strip()
    ]
    overdue_manager_lines = _overdue_manager_lines(list(analysis.get("overdue_deal_tasks_by_manager") or []))

    lines = [
        *_bullet_list(focus_task_items, "Задач с переносом срока более 2 раз нет"),
        "",
        "📌 Сделки под контролем",
        *_bullet_list(control_items[:7], "Сделок для личного контроля РОПа не найдено."),
        "",
        "👥 Команда и дисциплина",
        *_bullet_list(team_items[:7], "Явных управленческих просадок по менеджерам не найдено."),
        "",
        *overdue_manager_lines,
        "",
        "🧊 Сделки без следующего шага",
        *_bullet_list(
            [
                f"Всего: {_safe(str(metrics.get('deals_without_next_step', 0)))} / {_money_html(metrics.get('deals_without_next_step_amount'))}; "
                f"поздняя стадия: {_safe(str(metrics.get('deals_without_next_step_late_stage', 0)))}"
            ]
            + [_no_next_step_item(item) for item in (analysis.get("deals_without_next_step_items") or [])[:7]],
            "Сделок без следующего шага нет.",
        ),
        "",
        "📊 Сигналы по отделу",
        *_bullet_list(department_items, "Данных для управленческих метрик по отделу недостаточно."),
        "",
        "➡️ Что сделать РОПу сегодня",
        *_numbered_list(actions[:7], "Пройти сделки без следующего шага и просроченные задачи по отделу."),
    ]
    return lines


def _timed_entity_block(item: dict[str, Any], *, time_label: str = "дата") -> str:
    moved_at = item.get("moved_at")
    suffix = _format_dt(moved_at) if isinstance(moved_at, datetime) else "без даты"
    return f"{_entity_html(item)}\n{_safe(time_label)}: {_safe(suffix)}"


def _meeting_counts_by_manager(analysis: dict[str, Any] | None) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in (analysis or {}).get("conducted_meetings") or []:
        if not item.get("yesterday_moved"):
            continue
        manager_name = str(item.get("assigned_name") or "без ответственного").strip()
        if not manager_name:
            continue
        counts[manager_name] = counts.get(manager_name, 0) + 1
    return counts


def _communications_scorecard(
    item: dict[str, Any],
    *,
    meetings_count: int = 0,
    telemarketing_min_dials: int = DEFAULT_TELEMARKETING_MIN_DIALS,
) -> dict[str, Any]:
    role = str(item.get("employee_role") or "").strip().lower()
    if role not in {"sales", "telemarketing"}:
        role = "sales"

    dials = int(item.get("dials") or 0)
    normal_calls = int(item.get("normal_calls") or 0)
    messenger_dialogs = int(item.get("messenger_dialogs") or 0)
    connect_rate = item.get("connect_rate")
    connect_percent = int(round(float(connect_rate) * 100)) if connect_rate is not None else 0

    if role == "telemarketing":
        operational_minutes = (dials * 0.7) + (normal_calls * 12) + (messenger_dialogs * 8)
        corrections = 0
        if connect_percent >= 20:
            corrections += 1
        if connect_percent >= 30:
            corrections += 2
        if dials >= telemarketing_min_dials:
            corrections += 1
        if dials >= DEFAULT_TELEMARKETING_HIGH_DIALS and normal_calls <= DEFAULT_TELEMARKETING_VERY_LOW_CALLS:
            corrections -= 1
        if dials > 40 and normal_calls == 0:
            corrections -= 2
        if messenger_dialogs == 0 and normal_calls < 2:
            corrections -= 1
        meetings_label = "—"
        effective_meetings = 0
    else:
        operational_minutes = (meetings_count * 60) + (normal_calls * 10) + (messenger_dialogs * 7) + (dials * 0.5)
        corrections = 0
        if meetings_count >= 1:
            corrections += 1
        if meetings_count >= 2:
            corrections += 2
        if connect_percent < 10:
            corrections -= 1
        if dials > 30 and normal_calls == 0:
            corrections -= 2
        if meetings_count == 0 and normal_calls < 2 and messenger_dialogs < 3:
            corrections -= 2
        meetings_label = str(meetings_count)
        effective_meetings = meetings_count

    base_score = min(10.0, operational_minutes / 30.0)
    operational_score = max(1.0, min(10.0, base_score + corrections))

    if role == "telemarketing":
        if dials <= 0 and normal_calls <= 0 and messenger_dialogs <= 0:
            status = (2, "❌", "СТОП")
        elif dials > 40 and normal_calls == 0:
            status = (2, "❌", "СТОП")
        elif operational_score >= 7.0 or (
            dials >= telemarketing_min_dials and normal_calls >= 4 and connect_percent >= 20
        ):
            status = (0, "🔥", "НОРМ")
        elif operational_score >= 3.5 or dials >= 15 or normal_calls >= 2 or messenger_dialogs >= 3:
            status = (1, "⚠️", "РИСК")
        else:
            status = (2, "❌", "СТОП")
    else:
        if dials <= 0 and normal_calls <= 0 and messenger_dialogs <= 0 and meetings_count <= 0:
            status = (2, "❌", "СТОП")
        elif dials > 30 and normal_calls == 0:
            status = (2, "❌", "СТОП")
        elif operational_score >= 6.0 or (meetings_count >= 2 and operational_score >= 5.0):
            status = (0, "🔥", "НОРМ")
        elif operational_score >= 3.0 or meetings_count >= 1 or normal_calls >= 2 or messenger_dialogs >= 3:
            status = (1, "⚠️", "РИСК")
        else:
            status = (2, "❌", "СТОП")

    return {
        "employee_role": role,
        "connect_percent": connect_percent,
        "meetings_count": effective_meetings,
        "meetings_label": meetings_label,
        "operational_minutes": operational_minutes,
        "operational_score": operational_score,
        "operational_score_label": f"{operational_score:.1f}",
        "status_rank": status[0],
        "status_icon": status[1],
        "status_code": status[2],
    }


def _communications_items(summary: dict[str, Any], analysis: dict[str, Any] | None = None) -> list[str]:
    managers = list(summary.get("managers") or [])
    if not managers:
        return []

    def _status_meta(item: dict[str, Any]) -> tuple[int, str, str]:
        return tuple(item.get("_scorecard_status") or (2, "❌", "СТОП"))  # type: ignore[return-value]

    def _avg_percent_label(values: list[float]) -> str:
        if not values:
            return "0%"
        avg = sum(values) / len(values)
        rounded = round(avg, 1)
        if rounded.is_integer():
            return f"{int(rounded)}%"
        return f"{rounded:.1f}%"

    meeting_counts = _meeting_counts_by_manager(analysis)
    telemarketing_min_dials = int(
        (summary.get("thresholds") or {}).get("telemarketing_min_dials") or DEFAULT_TELEMARKETING_MIN_DIALS
    )

    prepared_rows: list[dict[str, Any]] = []
    for item in managers:
        manager_name = str(item.get("manager_name") or "без ответственного").strip()
        scorecard = _communications_scorecard(
            item,
            meetings_count=meeting_counts.get(manager_name, 0),
            telemarketing_min_dials=telemarketing_min_dials,
        )
        prepared_rows.append({**item, "_scorecard": scorecard, "_scorecard_status": (
            scorecard["status_rank"],
            scorecard["status_icon"],
            scorecard["status_code"],
        )})

    ordered = sorted(
        prepared_rows,
        key=lambda item: (
            _status_meta(item)[0],
            -float((item.get("_scorecard") or {}).get("operational_score") or 0.0),
            -int((item.get("_scorecard") or {}).get("meetings_count") or 0),
            -int(item.get("total_known") or 0),
            -int(item.get("dials") or 0),
            str(item.get("manager_name") or ""),
        ),
    )

    manager_rows: list[str] = []
    total_dials = 0
    total_calls = 0
    total_messenger_dialogs = 0
    total_meetings = 0
    operational_scores: list[float] = []
    connect_rates_for_average: list[float] = []
    ordered_rows: list[dict[str, Any]] = []

    for item in ordered:
        scorecard = item.get("_scorecard") or {}
        manager_name = _truncate_with_dots(item.get("manager_name") or "без ответственного", max_len=24)
        dials = int(item.get("dials") or 0)
        normal_calls = int(item.get("normal_calls") or 0)
        messenger_dialogs = int(item.get("messenger_dialogs") or 0)
        connect_percent = int(scorecard.get("connect_percent") or 0)
        total_dials += dials
        total_calls += normal_calls
        total_messenger_dialogs += messenger_dialogs
        total_meetings += int(scorecard.get("meetings_count") or 0)
        operational_scores.append(float(scorecard.get("operational_score") or 0.0))
        if int(item.get("total_known") or 0) > 0 and item.get("connect_rate") is not None:
            connect_rates_for_average.append(float(item.get("connect_rate") or 0.0) * 100)
        _, _, status_code = _status_meta(item)
        ordered_rows.append(
            {
                "status_code": status_code,
                "manager_name": manager_name,
                "dials": dials,
                "normal_calls": normal_calls,
                "connect_percent": connect_percent,
                "messenger_dialogs": messenger_dialogs,
                "meetings_label": str(scorecard.get("meetings_label") or "0"),
                "operational_score_label": str(scorecard.get("operational_score_label") or "1.0"),
            }
        )

    manager_width = max(
        len("Менеджер"),
        max(len(str(item.get("manager_name") or "")) for item in ordered_rows) if ordered_rows else 0,
    )
    manager_rows.append(
        f"{'Статус':<6} {'Менеджер':<{manager_width}} {'Наб':>4} {'Дзв':>4} {'Конв':>5} {'Чаты':>4} {'Встр':>4} {'Опер':>4}"
    )
    for item in ordered_rows:
        manager_rows.append(
            f"{str(item['status_code']):<6} "
            f"{str(item['manager_name']):<{manager_width}} "
            f"{int(item['dials']):>4} "
            f"{int(item['normal_calls']):>4} "
            f"{str(item['connect_percent']) + '%':>5} "
            f"{int(item['messenger_dialogs']):>4} "
            f"{str(item['meetings_label']):>4} "
            f"{str(item['operational_score_label']):>4}"
        )

    average_percent = sum(connect_rates_for_average) / len(connect_rates_for_average) if connect_rates_for_average else None
    average_operational_score = sum(operational_scores) / len(operational_scores) if operational_scores else None
    if average_percent is None:
        average_label = "0%"
        average_comment = "Данных по конверсии в дозвон пока недостаточно"
    else:
        average_label = _avg_percent_label(connect_rates_for_average)
        if average_percent < 15:
            average_comment = "Общий дозвон ниже нормы, нужно усиливать телефон"
        elif average_percent <= 20:
            average_comment = "Средний уровень, есть точки роста"
        else:
            average_comment = "Хороший уровень дозвона"

    rows: list[str] = [
        "Статус: 🔥 НОРМ | ⚠️ РИСК | ❌ СТОП",
        _preformatted_block(manager_rows),
    ]

    rows.extend(
        [
            "",
            "Итого по отделу:",
            _preformatted_block(
                [
                    (
                        f"Наб {int(total_dials):>4} | "
                        f"Дзв {int(total_calls):>4} | "
                        f"Конв {average_label:>5} | "
                        f"Чаты {int(total_messenger_dialogs):>4} | "
                        f"Встр {int(total_meetings):>4} | "
                        f"Опер {f'{average_operational_score:.1f}' if average_operational_score is not None else '0.0':>4}"
                    )
                ]
            ),
            "",
            _safe(average_comment),
            "",
            "Расшифровка:",
            "Наб — наборы",
            "Дзв — дозвон более 60 сек",
            "Конв — конверсия в дозвон",
            "Чаты — диалоги в мессенджерах",
            "Встр — проведённые встречи; для телемаркетинга не применяется",
            "Опер — оценка операционной вовлечённости по 10-балльной шкале",
            "Продажи: встречи, дозвоны, чаты и наборы",
            "Телемаркетинг: наборы, дозвоны, конверсия и чаты",
        ]
    )
    return rows


def _communications_fallback(summary: dict[str, Any]) -> list[str]:
    if summary.get("managers"):
        return []
    items: list[str] = []
    department_filter = summary.get("department_filter") or {}
    if int(department_filter.get("allowlist_count") or 0) == 0:
        items.append("Фильтр продажных подразделений не собран")
        return items
    if not (summary.get("calls") or {}).get("available"):
        items.append("Данные по звонкам недоступны")
    else:
        items.append("Коммуникаций за предыдущий рабочий день не найдено")
    if not (summary.get("messengers") or {}).get("available"):
        items.append("Диалоги в мессенджерах недоступны")
    return items


def format_sales_brief(
    analysis: dict[str, Any],
    risk_report: dict[str, Any],
    *,
    communications_summary: dict[str, Any] | None = None,
    monthly_target: float | None = None,
) -> str:
    metrics = analysis.get("metrics") or {}
    communications_summary = communications_summary or {}
    report_now = analysis.get("now")
    conducted_meetings = list(analysis.get("conducted_meetings") or [])
    accepted_briefs = list(analysis.get("accepted_briefs") or [])
    new_deals_yesterday = list(analysis.get("new_deals_yesterday") or [])
    lost_deals_yesterday = list(analysis.get("lost_deals_yesterday") or [])
    stale_communication_deals = _sorted_stale_deals(list(analysis.get("stale_communication_deals") or []))
    no_next_step_deals = _sorted_no_next_step_deals(list(analysis.get("deals_without_next_step_items") or []))
    yesterday_meetings = [item for item in conducted_meetings if item.get("yesterday_moved")]
    yesterday_briefs = [item for item in accepted_briefs if item.get("yesterday_moved")]
    source_lines = [_source_line(item) for item in (analysis.get("new_deal_sources_yesterday") or [])[:5]]
    lost_by_manager: dict[str, int] = {}
    for item in lost_deals_yesterday:
        manager_name = str(item.get("assigned_name") or "без ответственного").strip()
        lost_by_manager[manager_name] = lost_by_manager.get(manager_name, 0) + 1
    lost_manager_line = "; ".join(
        f"<b>{_safe(name)}</b> — {_safe(str(count))}"
        for name, count in sorted(lost_by_manager.items(), key=lambda row: (int(row[1]), row[0]), reverse=True)[:5]
    )

    forecast_gap = None
    forecast_amount = metrics.get("expected_forecast_amount")
    if monthly_target is not None and forecast_amount is not None:
        gap = float(monthly_target) - float(forecast_amount)
        if gap > 0:
            forecast_gap = _format_money(gap)

    communications_items = _communications_items(communications_summary, analysis)
    if not communications_items:
        communications_items = _communications_fallback(communications_summary)

    system_limitations = list(communications_summary.get("system_limitations") or [])[:5]

    limitations = list(analysis.get("limitations") or [])
    limitations.extend(item for item in (communications_summary.get("limitations") or []) if item and item not in system_limitations)
    stale_days_limit = 14
    thresholds = communications_summary.get("thresholds") or {}
    if thresholds:
        stale_days_limit = int(thresholds.get("stale_communication_days") or stale_days_limit)
    stale_deals_header = f"🚨 Сделки без коммуникации > {_safe(str(stale_days_limit))} дн."
    stale_deals_count = len(stale_communication_deals)
    stale_deals_amount = sum(float(item.get("amount") or 0.0) for item in stale_communication_deals)
    stale_deals_lines = [stale_deals_header]
    if stale_communication_deals:
        stale_deals_lines.extend(
            [
                f"Всего: {_safe(str(stale_deals_count))} / {_money_html(stale_deals_amount)}",
                *_bullet_list(
                    [_stale_deal_item(item) for item in stale_communication_deals],
                    f"Нет сделок без коммуникации более {stale_days_limit} дней",
                ),
            ]
        )
    else:
        stale_deals_lines.append(f"Нет сделок без коммуникации более {_safe(str(stale_days_limit))} дней")
    no_next_step_count = len(no_next_step_deals)
    no_next_step_amount = sum(float(item.get("amount") or 0.0) for item in no_next_step_deals)
    no_next_step_lines = ["⚠️ Сделки без следующего шага"]
    if no_next_step_deals:
        no_next_step_lines.extend(
            [
                f"Всего: {_safe(str(no_next_step_count))} / {_money_html(no_next_step_amount)}",
                *_bullet_list(
                    [_daily_no_next_step_item(item) for item in no_next_step_deals],
                    "Нет сделок без следующего шага",
                ),
            ]
        )
    else:
        no_next_step_lines.append("Нет сделок без следующего шага")

    flow_lines = [
        f"Новые сделки: {_safe(str(metrics.get('new_deals_yesterday', 0)))}",
        f"Источники: {'; '.join(source_lines) if source_lines else 'новых сделок за предыдущий рабочий день нет'}",
        f"Проведено встреч: {_safe(str(metrics.get('conducted_meetings_yesterday', 0)))}",
        f"Брифов принято производством: {_safe(str(metrics.get('accepted_briefs_yesterday', 0)))}",
        f"Сделок ушло в отказ: {_safe(str(metrics.get('lost_deals_yesterday', 0)))}",
    ]
    if lost_manager_line:
        flow_lines.append(f"Отказы по менеджерам: {lost_manager_line}")

    funnel_lines = [
        f"• Активные сделки: {_safe(str(metrics.get('deals_in_work', 0)))} / {_money_html(metrics.get('pipeline_amount'))}",
        f"• С движением за последнюю неделю: {_safe(str(metrics.get('moving_deals_last_week', 0)))}",
        f"• Без движения за последнюю неделю: {_safe(str(metrics.get('stagnant_deals_last_week', 0)))}",
        f"• Этап договора: {_safe(str(metrics.get('hot_stage_deals', 0)))} / {_money_html(metrics.get('hot_stage_amount'))}",
        "",
        f"• Под риском: {_safe(str(risk_report.get('totals', {}).get('deal_risks', 0)))} / {_money_html(risk_report.get('totals', {}).get('risk_amount'))}",
        f"  - Без следующего шага: {_safe(str(metrics.get('deals_without_next_step', 0)))} / {_money_html(metrics.get('deals_without_next_step_amount'))}",
        f"  - Без коммуникации > {_safe(str(stale_days_limit))} дн.: {_safe(str(metrics.get('stale_communication_deals', 0)))} / {_money_html(metrics.get('stale_communication_amount'))}",
        f"  - С просроченными задачами: {_safe(str(metrics.get('overdue_deal_task_deals', 0)))} / {_money_html(metrics.get('overdue_deal_task_amount'))}",
    ]
    if forecast_gap:
        limitations.append(f"Недобор к плану по текущему прогнозу: {forecast_gap}")
    rop_focus_lines = _build_rop_focus_lines(analysis, risk_report, communications_summary)

    lines = [
        "📊 Sales Copilot",
        "",
        f"Срез на {_safe(_format_dt(report_now))} МСК" if isinstance(report_now, datetime) else "Срез на текущее утро",
        "",
        "🧾 Поток за предыдущий рабочий день",
        *_bullet_list(flow_lines, "За вчера изменений по воронке не было."),
        "",
        "📈 Воронка в работе",
        *(funnel_lines or ["• Данных по воронке недостаточно."]),
        "",
        "🆕 Новые сделки за предыдущий рабочий день",
        *_bullet_list([_new_deal_item(item) for item in new_deals_yesterday[:5]], "Новых сделок за предыдущий рабочий день нет."),
        "",
        "📞 Коммуникации за предыдущий рабочий день",
        *(communications_items or ["Данных по коммуникациям недостаточно."]),
        "",
        "🤝 Проведенные встречи",
        *_bullet_list([_meeting_item(item) for item in yesterday_meetings[:5]], "Проведённых встреч за предыдущий рабочий день нет."),
        "",
        "📈 Принятые брифы",
        *_bullet_list([_brief_item(item) for item in yesterday_briefs[:5]], "Брифов, принятых производством за предыдущий рабочий день, нет."),
        "",
        "📉 Отказы за предыдущий рабочий день",
        *_bullet_list([_lost_deal_item(item) for item in lost_deals_yesterday[:5]], "Отказов за предыдущий рабочий день нет."),
        "",
        *stale_deals_lines,
        "",
        *no_next_step_lines,
        "",
        "🎯 Фокус РОПа",
        *(rop_focus_lines or ["• Данных для блока Фокус РОПа недостаточно."]),
    ]
    return "\n".join(_append_limitations(lines, list(dict.fromkeys(system_limitations + limitations))))


def format_pipeline_report(
    analysis: dict[str, Any],
    risk_report: dict[str, Any],
    *,
    monthly_target: float | None = None,
) -> str:
    return format_sales_brief(
        analysis,
        risk_report,
        communications_summary={},
        monthly_target=monthly_target,
    )


def format_risks_report(
    analysis: dict[str, Any],
    risk_report: dict[str, Any],
    *,
    communications_summary: dict[str, Any] | None = None,
) -> str:
    return format_focus_sales_report(
        analysis,
        risk_report,
        communications_summary=communications_summary,
    )


def format_focus_sales_report(
    analysis: dict[str, Any],
    risk_report: dict[str, Any],
    *,
    communications_summary: dict[str, Any] | None = None,
) -> str:
    lines = ["🎯 Фокус РОПа", *_build_rop_focus_lines(analysis, risk_report, communications_summary)]
    return "\n".join(lines)


def format_followup_report(analysis: dict[str, Any], risk_report: dict[str, Any]) -> str:
    del analysis
    followups = [
        f"{_entity_html(item)}\n{_safe(item['actions'][0])}"
        for item in (risk_report.get("high_risk_deals") or [])[:5]
        if item.get("actions")
    ]
    lines = [
        "📌 Контроль до конца дня",
        "",
        "Что ещё висит",
        *_bullet_list(followups[:3], "Критичных хвостов к вечеру нет."),
        "",
        "Что требует реакции до конца дня",
        *_bullet_list(followups[3:5], "Срочных реакций не найдено."),
    ]
    return "\n".join(lines)


def _in_period(value: Any, start: datetime, end: datetime) -> bool:
    return isinstance(value, datetime) and start <= value.astimezone(MOSCOW_TZ) < end


def _period_label(start_value: Any, end_value: Any) -> str:
    start = start_value.strftime("%d.%m") if hasattr(start_value, "strftime") else "-"
    end = end_value.strftime("%d.%m") if hasattr(end_value, "strftime") else "-"
    return f"{start}–{end}"


def _role_label(role: str) -> str:
    normalized = str(role or "").strip().lower()
    if normalized == "telemarketing":
        return "телемаркетолог"
    if normalized == "sales":
        return "менеджер по продажам"
    return "сотрудник"


def _connect_label(value: Any) -> str:
    if value in (None, ""):
        return "0%"
    percent = round(float(value) * 100)
    return f"{int(percent)}%"


def _count_with_noun(count: int, one: str, few: str, many: str) -> str:
    return f"{_safe(str(count))} {_safe(_ru_noun(count, one, few, many))}"


def _weekly_meeting_counts(analysis: dict[str, Any], start: datetime, end: datetime) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in analysis.get("conducted_meetings") or []:
        if not _in_period(item.get("moved_at"), start, end):
            continue
        manager_name = str(item.get("assigned_name") or "без ответственного").strip()
        counts[manager_name] = counts.get(manager_name, 0) + 1
    return counts


def _weekly_reschedule_stats(analysis: dict[str, Any]) -> tuple[dict[str, int], dict[str, int]]:
    by_manager: dict[str, int] = {}
    by_deal: dict[str, int] = {}
    for item in analysis.get("deadline_reschedule_focus_tasks") or []:
        manager_key = str(item.get("manager_id") or item.get("manager_name") or "").strip()
        deal_key = str(item.get("deal_id") or "").strip()
        if manager_key:
            by_manager[manager_key] = by_manager.get(manager_key, 0) + 1
        if deal_key:
            by_deal[deal_key] = max(by_deal.get(deal_key, 0), int(item.get("deadline_change_count") or 0))
    return (by_manager, by_deal)


def _weekly_overdue_by_deal(analysis: dict[str, Any]) -> dict[str, int]:
    result: dict[str, int] = {}
    for item in analysis.get("overdue_deal_tasks") or []:
        deal_id = str(item.get("deal_id") or "").strip()
        if not deal_id:
            continue
        result[deal_id] = max(result.get(deal_id, 0), int(item.get("days_overdue") or 0))
    return result


def _manager_comparison_note(current_item: dict[str, Any], previous_map: dict[str, dict[str, Any]]) -> str:
    manager_id = str(current_item.get("manager_id") or "").strip()
    previous = previous_map.get(manager_id) or {}
    previous_total = int(previous.get("total_known") or 0)
    current_total = int(current_item.get("total_known") or 0)
    if previous_total <= 0:
        return ""
    if current_total < previous_total * 0.6:
        return f"просадка к прошлой неделе: {previous_total} -> {current_total} коммуникаций"
    return ""


def _weekly_people_sections(
    analysis: dict[str, Any],
    risk_report: dict[str, Any],
    weekly_context: dict[str, Any],
) -> tuple[list[str], list[dict[str, Any]], list[str]]:
    summary = weekly_context.get("communications_summary") or {}
    previous_summary = weekly_context.get("previous_communications_summary") or {}
    managers = list(summary.get("manager_stats") or summary.get("managers") or [])
    previous_map = {
        str(item.get("manager_id") or "").strip(): item
        for item in (previous_summary.get("manager_stats") or previous_summary.get("managers") or [])
        if str(item.get("manager_id") or "").strip()
    }
    if not managers:
        return (["• Данных по людям за неделю недостаточно."], [], [])

    start = weekly_context.get("start")
    end = weekly_context.get("end")
    meeting_counts = _weekly_meeting_counts(analysis, start, end) if isinstance(start, datetime) and isinstance(end, datetime) else {}
    reschedule_by_manager, _ = _weekly_reschedule_stats(analysis)

    risk_amount_by_manager: dict[str, float] = {}
    risk_count_by_manager: dict[str, int] = {}
    risky_deal_ids = {str(item.get("entity_id") or "").strip() for item in (risk_report.get("deal_risks") or [])}
    for deal in analysis.get("active_deals") or []:
        manager_key = str(deal.get("assigned_id") or deal.get("assigned_name") or "").strip()
        if not manager_key:
            continue
        if str(deal.get("id") or "").strip() in risky_deal_ids:
            risk_count_by_manager[manager_key] = risk_count_by_manager.get(manager_key, 0) + 1
            risk_amount_by_manager[manager_key] = risk_amount_by_manager.get(manager_key, 0.0) + float(deal.get("amount") or 0.0)

    sales_rows: list[dict[str, Any]] = []
    tele_rows: list[dict[str, Any]] = []
    all_rows: list[dict[str, Any]] = []
    for item in managers:
        role = str(item.get("employee_role") or "unknown").strip().lower()
        manager_key = str(item.get("manager_id") or item.get("manager_name") or "").strip()
        current_total = int(item.get("total_known") or 0)
        normal_calls = int(item.get("normal_calls") or 0)
        dials = int(item.get("dials") or 0)
        messenger_dialogs = int(item.get("messenger_dialogs") or 0)
        meetings = meeting_counts.get(str(item.get("manager_name") or ""), 0)
        missing_next_step_count = int(item.get("missing_next_step_count") or 0)
        stale_communication_count = int(item.get("stale_communication_count") or 0)
        late_stage_stuck_count = int(item.get("late_stage_stuck_count") or 0)
        overdue_tasks_count = int(item.get("overdue_tasks_count") or 0)
        reschedule_count = int(reschedule_by_manager.get(manager_key) or 0)
        risk_count = int(risk_count_by_manager.get(manager_key) or 0)
        risk_amount = float(risk_amount_by_manager.get(manager_key) or 0.0)
        comparison_note = _manager_comparison_note(item, previous_map)
        activity_imitation = role == "telemarketing" and dials >= 30 and normal_calls <= 1 and messenger_dialogs <= 1

        if role == "telemarketing":
            strength = (normal_calls * 3) + (dials / 8.0) + messenger_dialogs + (2 if (item.get("connect_rate") or 0) >= 0.2 else 0)
            weakness = (3 if activity_imitation else 0) + (2 if dials < DEFAULT_TELEMARKETING_MIN_DIALS else 0) + (
                2 if dials >= 15 and float(item.get("connect_rate") or 0.0) < 0.12 else 0
            ) + (1 if comparison_note else 0)
            row = {
                "role": role,
                "manager_name": str(item.get("manager_name") or "без ответственного").strip(),
                "summary_strong": (
                    f"{_safe(item.get('manager_name') or 'без ответственного')} — "
                    f"{_count_with_noun(dials, 'набор', 'набора', 'наборов')}, {_count_with_noun(normal_calls, 'дозвон', 'дозвона', 'дозвонов')}, "
                    f"конверсия {_safe(_connect_label(item.get('connect_rate')))}, "
                    f"{_count_with_noun(messenger_dialogs, 'чат', 'чата', 'чатов')}"
                ),
                "summary_weak": (
                    f"{_safe(item.get('manager_name') or 'без ответственного')} — "
                    f"{_count_with_noun(dials, 'набор', 'набора', 'наборов')}, {_count_with_noun(normal_calls, 'дозвон', 'дозвона', 'дозвонов')}, "
                    f"конверсия {_safe(_connect_label(item.get('connect_rate')))}"
                    + ("; признаки имитации активности" if activity_imitation else "")
                ),
                "summary_drop": (
                    f"{_safe(item.get('manager_name') or 'без ответственного')} — {comparison_note}; "
                    f"{_count_with_noun(normal_calls, 'дозвон', 'дозвона', 'дозвонов')}, {_count_with_noun(messenger_dialogs, 'чат', 'чата', 'чатов')}"
                )
                if comparison_note
                else "",
                "weakness": weakness,
                "strength": strength,
                "role_label": _role_label(role),
                "reason": (
                    "имитация активности" if activity_imitation else "слабый дозвон и конверсия"
                ),
            }
            tele_rows.append(row)
            all_rows.append(row)
            continue

        strength = (meetings * 3) + (normal_calls * 2) + messenger_dialogs + min(current_total, 8) - (
            risk_count + missing_next_step_count + stale_communication_count + overdue_tasks_count
        )
        weakness = (
            risk_count * 3
            + missing_next_step_count * 2
            + stale_communication_count * 2
            + late_stage_stuck_count * 2
            + overdue_tasks_count * 2
            + reschedule_count
            + (1 if comparison_note else 0)
        )
        weak_parts = [
            f"{_count_with_noun(missing_next_step_count, 'сделка', 'сделки', 'сделок')} без следующего шага" if missing_next_step_count else "",
            f"{_count_with_noun(late_stage_stuck_count, 'поздняя стадия', 'поздние стадии', 'поздних стадий')} без движения" if late_stage_stuck_count else "",
            f"{_count_with_noun(stale_communication_count, 'сделка', 'сделки', 'сделок')} без коммуникации > 14 дн." if stale_communication_count else "",
            f"{_count_with_noun(overdue_tasks_count, 'просроченная задача', 'просроченные задачи', 'просроченных задач')}" if overdue_tasks_count else "",
            f"{_count_with_noun(reschedule_count, 'задача', 'задачи', 'задач')} с 3+ переносами" if reschedule_count else "",
        ]
        weak_parts = [part for part in weak_parts if part]
        row = {
            "role": role,
            "manager_name": str(item.get("manager_name") or "без ответственного").strip(),
            "summary_strong": (
                f"{_safe(item.get('manager_name') or 'без ответственного')} — "
                f"{_count_with_noun(meetings, 'встреча', 'встречи', 'встреч')}, {_count_with_noun(normal_calls, 'дозвон', 'дозвона', 'дозвонов')}, "
                f"{_count_with_noun(missing_next_step_count, 'сделка', 'сделки', 'сделок')} без следующего шага"
            ),
            "summary_weak": (
                f"{_safe(item.get('manager_name') or 'без ответственного')} — "
                f"{'; '.join(weak_parts[:3]) if weak_parts else 'нужен разбор по рискам'}; "
                f"{_safe(_format_money(risk_amount))} под риском"
            ),
            "summary_drop": (
                f"{_safe(item.get('manager_name') or 'без ответственного')} — {comparison_note}; "
                f"сейчас {_count_with_noun(meetings, 'встреча', 'встречи', 'встреч')} и {_count_with_noun(normal_calls, 'дозвон', 'дозвона', 'дозвонов')}"
            )
            if comparison_note
            else "",
            "weakness": weakness,
            "strength": strength,
            "role_label": _role_label(role),
            "reason": "; ".join(weak_parts[:3]) if weak_parts else "деньги под риском",
        }
        sales_rows.append(row)
        all_rows.append(row)

    def _role_lines(title: str, rows: list[dict[str, Any]]) -> list[str]:
        if not rows:
            return [title, "• Данных недостаточно."]
        strong = [
            item["summary_strong"]
            for item in sorted(rows, key=lambda item: item["strength"], reverse=True)
            if item["strength"] >= 4 and int(item.get("weakness") or 0) == 0
        ][:2]
        weak = [item["summary_weak"] for item in sorted(rows, key=lambda item: item["weakness"], reverse=True) if item["weakness"] > 0][:2]
        drops = [item["summary_drop"] for item in rows if item.get("summary_drop")][:2]
        result = [title]
        result.extend(_bullet_list([f"Сильные: {'; '.join(strong)}"], "Сильных сигналов не найдено.") if strong else ["• Сильные: явных лидеров не выделено."])
        result.extend(_bullet_list([f"Слабые: {'; '.join(weak)}"], "Слабых сигналов не найдено.") if weak else ["• Слабые: выраженных просадок не найдено."])
        result.extend(_bullet_list([f"Просадка: {'; '.join(drops)}"], "Просадки к прошлой неделе не видно.") if drops else ["• Просадка: сравнение с прошлой неделей ограничено."])
        return result

    lines = [
        *_role_lines("Менеджеры по продажам", sales_rows),
        "",
        *_role_lines("Телемаркетинг", tele_rows),
    ]
    action_hints = [item["reason"] for item in sorted(all_rows, key=lambda item: item["weakness"], reverse=True) if item["weakness"] > 0][:3]
    return (
        lines,
        [item for item in sorted(all_rows, key=lambda item: item["weakness"], reverse=True) if int(item.get("weakness") or 0) > 0],
        action_hints,
    )


def _weekly_stage_lines(analysis: dict[str, Any], risk_report: dict[str, Any]) -> list[str]:
    risk_by_deal_id = {str(item.get("entity_id") or "").strip(): item for item in (risk_report.get("deal_risks") or [])}
    by_stage: dict[str, dict[str, Any]] = {}
    for deal in analysis.get("active_deals") or []:
        stage_name = str(deal.get("stage_name") or "Без стадии").strip()
        row = by_stage.setdefault(
            stage_name,
            {"stage_name": stage_name, "risk": 0, "missing_next_step": 0, "stuck": 0, "stale": 0, "late": 0, "amount": 0.0},
        )
        row["amount"] += float(deal.get("amount") or 0.0)
        if str(deal.get("id") or "").strip() in risk_by_deal_id:
            row["risk"] += 1
        if deal.get("missing_next_step"):
            row["missing_next_step"] += 1
        if int(deal.get("inactive_days") or 0) >= 5:
            row["stuck"] += 1
        if int(deal.get("communication_gap_days") or 0) >= 14:
            row["stale"] += 1
        if deal.get("late_stage"):
            row["late"] += 1

    problem_rows = [
        row
        for row in by_stage.values()
        if int(row["risk"]) or int(row["missing_next_step"]) or int(row["stuck"]) or int(row["stale"])
    ]
    problem_rows.sort(
        key=lambda item: (int(item["risk"]), int(item["missing_next_step"]), int(item["stuck"]), int(item["stale"]), float(item["amount"])),
        reverse=True,
    )
    return [
        f"{_safe(item['stage_name'])} — под риском {_safe(str(item['risk']))}, без следующего шага {_safe(str(item['missing_next_step']))}, без движения {_safe(str(item['stuck']))}, сумма {_money_html(item['amount'])}"
        for item in problem_rows[:3]
    ]


def _weekly_source_lines(analysis: dict[str, Any], weekly_context: dict[str, Any]) -> tuple[list[str], list[str]]:
    start = weekly_context.get("start")
    end = weekly_context.get("end")
    if not isinstance(start, datetime) or not isinstance(end, datetime):
        return (["Блок пока ограничен: период недели не определён."], [])

    by_source: dict[str, dict[str, Any]] = {}
    for deal in analysis.get("active_deals") or []:
        source_name = str(deal.get("source_name") or "Источник не указан").strip()
        row = by_source.setdefault(source_name, {"source_name": source_name, "moving": 0, "stuck": 0, "high_probability": 0, "lost": 0})
        if int(deal.get("inactive_days") or 0) < 5:
            row["moving"] += 1
        else:
            row["stuck"] += 1
        if deal.get("high_probability"):
            row["high_probability"] += 1
    for deal in analysis.get("closed_deals") or []:
        if not deal.get("lost") or not _in_period(deal.get("moved_at"), start, end):
            continue
        source_name = str(deal.get("source_name") or "Источник не указан").strip()
        row = by_source.setdefault(source_name, {"source_name": source_name, "moving": 0, "stuck": 0, "high_probability": 0, "lost": 0})
        row["lost"] += 1

    if not by_source:
        return (["Блок пока ограничен: по источникам нет live-данных."], [])

    ordered = sorted(by_source.values(), key=lambda item: (int(item["moving"]), int(item["high_probability"]), -int(item["lost"]), -int(item["stuck"])), reverse=True)
    lines = []
    weak_sources: list[str] = []
    for item in ordered[:4]:
        line = (
            f"{_safe(item['source_name'])} — живые сделки {_safe(str(item['moving']))}, "
            f"Высокая вероятность {_safe(str(item['high_probability']))}, "
            f"зависание {_safe(str(item['stuck']))}, отказов {_safe(str(item['lost']))}"
        )
        lines.append(line)
        if int(item["lost"]) > 0 or int(item["stuck"]) > int(item["moving"]):
            weak_sources.append(str(item["source_name"]))
    return (lines, weak_sources[:2])


def _weekly_money_lines(analysis: dict[str, Any], risk_report: dict[str, Any], weekly_context: dict[str, Any]) -> tuple[list[str], list[str]]:
    summary = weekly_context.get("communications_summary") or {}
    manager_roles = {
        str(item.get("manager_id") or "").strip(): str(item.get("employee_role") or "unknown").strip().lower()
        for item in (summary.get("manager_stats") or summary.get("managers") or [])
        if str(item.get("manager_id") or "").strip()
    }
    risky_amount_by_manager: dict[str, float] = {}
    risky_deal_ids = {str(item.get("entity_id") or "").strip() for item in (risk_report.get("deal_risks") or [])}
    for deal in analysis.get("active_deals") or []:
        manager_id = str(deal.get("assigned_id") or "").strip()
        if manager_roles.get(manager_id) != "sales":
            continue
        deal_id = str(deal.get("id") or "").strip()
        if deal_id in risky_deal_ids or deal.get("missing_next_step") or int(deal.get("inactive_days") or 0) >= 5:
            risky_amount_by_manager[manager_id] = risky_amount_by_manager.get(manager_id, 0.0) + float(deal.get("amount") or 0.0)
    top_managers = []
    manager_name_map = {
        str(item.get("manager_id") or "").strip(): str(item.get("manager_name") or "").strip()
        for item in (summary.get("manager_stats") or summary.get("managers") or [])
    }
    for manager_id, amount in sorted(risky_amount_by_manager.items(), key=lambda item: float(item[1]), reverse=True)[:3]:
        top_managers.append(f"{_safe(manager_name_map.get(manager_id) or manager_id)} — {_money_html(amount)}")
    lines = [
        f"Деньги под риском: {_money_html(risk_report.get('totals', {}).get('risk_amount'))}",
        f"Без движения: {_money_html(sum(float(item.get('amount') or 0.0) for item in (analysis.get('active_deals') or []) if int(item.get('inactive_days') or 0) >= 5))}",
        f"Без следующего шага: {_money_html(analysis.get('metrics', {}).get('deals_without_next_step_amount'))}",
        f"Без коммуникации > 14 дн.: {_money_html(analysis.get('metrics', {}).get('stale_communication_amount'))}",
    ]
    if top_managers:
        lines.append(f"Основной риск у менеджеров: {'; '.join(top_managers)}")
    return (lines, top_managers)


def _weekly_problem_deal_lines(
    analysis: dict[str, Any],
    risk_report: dict[str, Any],
    weekly_context: dict[str, Any],
) -> tuple[list[str], list[str]]:
    start = weekly_context.get("start")
    end = weekly_context.get("end")
    reschedule_by_deal = _weekly_reschedule_stats(analysis)[1]
    overdue_by_deal = _weekly_overdue_by_deal(analysis)
    summary = weekly_context.get("communications_summary") or {}
    role_by_manager = {
        str(item.get("manager_id") or "").strip(): _role_label(str(item.get("employee_role") or "unknown"))
        for item in (summary.get("manager_stats") or summary.get("managers") or [])
    }
    risk_by_deal_id = {
        str(item.get("entity_id") or "").strip(): item
        for item in (risk_report.get("deal_risks") or [])
        if str(item.get("entity_id") or "").strip()
    }
    candidates: dict[str, dict[str, Any]] = {}
    for collection in (
        risk_report.get("high_risk_deals") or [],
        analysis.get("deals_without_next_step_items") or [],
        analysis.get("stale_communication_deals") or [],
    ):
        for item in collection:
            deal_id = str(item.get("id") or "").strip()
            if deal_id:
                candidates[deal_id] = item
    if isinstance(start, datetime) and isinstance(end, datetime):
        for item in analysis.get("closed_deals") or []:
            if item.get("lost") and _in_period(item.get("moved_at"), start, end) and float(item.get("amount") or 0.0) > 0:
                deal_id = str(item.get("id") or "").strip()
                if deal_id:
                    candidates[deal_id] = item

    def _priority(item: dict[str, Any]) -> tuple[int, int, int, int, float]:
        deal_id = str(item.get("id") or "").strip()
        risk_item = risk_by_deal_id.get(deal_id) or {}
        return (
            int((risk_item.get("severity") or 0)),
            int(reschedule_by_deal.get(deal_id) or 0),
            int(overdue_by_deal.get(deal_id) or 0),
            int(bool(item.get("late_stage"))) + int(bool(item.get("missing_next_step"))) + int(int(item.get("communication_gap_days") or 0) >= 14),
            float(item.get("amount") or 0.0),
        )

    lines: list[str] = []
    actions: list[str] = []
    for item in sorted(candidates.values(), key=_priority, reverse=True)[:5]:
        deal_id = str(item.get("id") or "").strip()
        reasons: list[str] = []
        if item.get("late_stage") and int(item.get("inactive_days") or 0) >= 5:
            reasons.append(f"поздняя стадия без движения {int(item.get('inactive_days') or 0)} дн.")
        if item.get("missing_next_step"):
            reasons.append("нет следующего шага")
        if int(item.get("communication_gap_days") or 0) >= 14:
            reasons.append(f"нет коммуникации {int(item.get('communication_gap_days') or 0)} дн.")
        if int(overdue_by_deal.get(deal_id) or 0) > 0:
            reasons.append(f"просроченная задача {int(overdue_by_deal.get(deal_id) or 0)} дн.")
        if int(reschedule_by_deal.get(deal_id) or 0) >= 3:
            reasons.append(f"{int(reschedule_by_deal.get(deal_id) or 0)} переноса срока")
        role_label = role_by_manager.get(str(item.get("assigned_id") or "").strip())
        extra_role = f"; роль: {role_label}" if role_label else ""
        reason_text = "; ".join(reasons[:3]) or "крупная сумма под риском"
        lines.append(
            f"{_entity_html(item)}{extra_role}\nпроблема: {_safe(reason_text)}"
        )
        actions.append(f"Поднять {_entity_html(item)} и закрыть проблему: {_safe(reason_text)}")
    return (lines, actions)


def format_weekly_review(
    analysis: dict[str, Any],
    risk_report: dict[str, Any],
    *,
    weekly_context: dict[str, Any] | None = None,
    monthly_target: float | None = None,
) -> str:
    weekly_context = weekly_context or {}
    metrics = analysis.get("metrics") or {}
    start = weekly_context.get("start")
    end = weekly_context.get("end")
    custom_period = bool(weekly_context.get("custom_period"))
    title = str(weekly_context.get("title") or "🗓 Еженедельный отчёт Льва Петровича")
    summary_heading = str(weekly_context.get("summary_heading") or "1. Что произошло за неделю")
    people_heading = str(weekly_context.get("people_heading") or "3. Люди за неделю")
    problem_deals_heading = str(weekly_context.get("problem_deals_heading") or "5. Проблемные сделки недели")
    period_start_label = weekly_context.get("start_date") or start
    period_end_label = weekly_context.get("end_date") or ((end - timedelta(days=1)) if isinstance(end, datetime) else end)
    period_label = _period_label(period_start_label, period_end_label) if period_start_label and period_end_label else "текущая рабочая неделя"

    new_deals_week = [
        item
        for item in (analysis.get("deals") or [])
        if _in_period(item.get("created_at"), start, end)
    ] if isinstance(start, datetime) and isinstance(end, datetime) else []
    lost_deals_week = [
        item
        for item in (analysis.get("closed_deals") or [])
        if item.get("lost") and _in_period(item.get("moved_at"), start, end)
    ] if isinstance(start, datetime) and isinstance(end, datetime) else []

    stage_lines = _weekly_stage_lines(analysis, risk_report)
    people_lines, weak_people, people_hints = _weekly_people_sections(analysis, risk_report, weekly_context)
    money_lines, _ = _weekly_money_lines(analysis, risk_report, weekly_context)
    problem_deal_lines, problem_actions = _weekly_problem_deal_lines(analysis, risk_report, weekly_context)
    source_lines, weak_sources = _weekly_source_lines(analysis, weekly_context)

    planorka_lines = []
    for item in weak_people[:3]:
        planorka_lines.append(
            f"{_safe(item.get('manager_name') or 'без ответственного')} — {_safe(item.get('role_label') or 'сотрудник')}. {_safe(item.get('reason') or 'нужен разбор')}"
        )

    actions: list[str] = []
    if problem_actions:
        actions.append(problem_actions[0])
    if weak_people:
        first = weak_people[0]
        role_label = str(first.get("role_label") or "сотрудник")
        if role_label == "телемаркетолог":
            actions.append(f"Отдельно разобрать {_safe(first.get('manager_name') or 'сотрудника')} по дозвону, конверсии и полезной отдаче.")
        else:
            actions.append(f"Отдельно пройти {_safe(first.get('manager_name') or 'сотрудника')} по сделкам без следующего шага и деньгам под риском.")
    if weak_sources:
        actions.append(f"Проверить качество источников: {_safe(', '.join(weak_sources))}.")
    if len(weak_people) > 1:
        second = weak_people[1]
        actions.append(f"Усилить контроль по {_safe(second.get('manager_name') or 'команде')}: {_safe(second.get('reason') or 'есть повторяющийся риск')}.")
    if people_hints:
        actions.append(f"Не упустить: {_safe(people_hints[0])}.")

    summary_lines = [
        f"В работу пришло: {_safe(str(len(new_deals_week)))} / {_money_html(sum(float(item.get('amount') or 0.0) for item in new_deals_week))}",
        f"Ушло в отказ: {_safe(str(len(lost_deals_week)))} / {_money_html(sum(float(item.get('amount') or 0.0) for item in lost_deals_week))}",
        f"Высокая вероятность: {_safe(str(metrics.get('high_probability_deals', 0)))} / {_money_html(metrics.get('high_probability_amount'))}",
        f"Под риском: {_safe(str(risk_report.get('totals', {}).get('deal_risks', 0)))} / {_money_html(risk_report.get('totals', {}).get('risk_amount'))}",
        f"Без следующего шага: {_safe(str(metrics.get('deals_without_next_step', 0)))} / {_money_html(metrics.get('deals_without_next_step_amount'))}",
        f"Без коммуникации > 14 дн.: {_safe(str(metrics.get('stale_communication_deals', 0)))} / {_money_html(metrics.get('stale_communication_amount'))}",
    ]

    limitations = list(analysis.get("limitations") or [])
    for item in (weekly_context.get("communications_summary") or {}).get("limitations") or []:
        if item not in limitations:
            limitations.append(item)

    lines = [
        title,
        "",
        f"Период: {_safe(period_label)}",
        "",
        summary_heading,
        *_bullet_list(summary_lines, "Данных по неделе недостаточно."),
        "",
        "2. Где воронка просела",
        *_bullet_list(stage_lines, "Явных недельных провалов по воронке не найдено."),
        "",
        people_heading,
        *people_lines,
        "",
        "4. Деньги под риском",
        *_bullet_list(money_lines, "Данных по денежным рискам недостаточно."),
        "",
        problem_deals_heading,
        *_bullet_list(problem_deal_lines, "Критичных проблемных сделок на этой неделе не выделено."),
        "",
        "6. Источники",
        *_bullet_list(source_lines, "Блок пока ограничен отсутствием live-источников качества."),
        "",
        "7. Кого разбирать на планёрке",
        *_bullet_list(planorka_lines, "Планёрка может пройти без персональных эскалаций."),
        "",
        "8. Что делать дальше" if custom_period else "8. Что делать на следующей неделе",
        *_numbered_list(actions[:5], "Поднять сделки без следующего шага и деньги под риском."),
    ]
    if monthly_target is not None:
        lines.extend(["", f"Цель месяца: {_money_html(monthly_target)}", f"Прогноз месяца: {_money_html(metrics.get('expected_forecast_amount'))}"])
    return "\n".join(_append_limitations(lines, limitations))
