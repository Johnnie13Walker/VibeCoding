"""Sales Copilot agent package."""
