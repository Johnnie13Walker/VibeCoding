"""Метрики коммуникаций Sales Copilot по доступным данным Bitrix."""

from __future__ import annotations

from datetime import datetime
import json
import re
from pathlib import Path
from typing import Any, Mapping

from cloudbot.business_day import MOSCOW_TZ, now_moscow, previous_business_day_window
from cloudbot.providers.bitrix.bitrix_app_auth import BitrixAppAuth
from cloudbot.providers.bitrix.bitrix_sales_adapter import BitrixSalesAdapter
from cloudbot.providers.bitrix_provider import BitrixAPIError
from cloudbot.providers.wazzup_provider import WazzupProvider

DEFAULT_SALES_DEPARTMENT_NAMES = (
    "Группа продаж Belberry",
    "Группа продаж Acoola Team",
    "Телемаркетинг",
)
SALES_ROLE_DEPARTMENT_NAMES = (
    "Группа продаж Belberry",
    "Группа продаж Acoola Team",
)
TELEMARKETING_ROLE_DEPARTMENT_NAMES = ("Телемаркетинг",)
OPENLINES_EVENT_NAMES = {"ONIMCONNECTORMESSAGEADD", "ONIMCONNECTORMESSAGEUPDATE"}
DEFAULT_STALE_COMMUNICATION_DAYS = 14
DEFAULT_LOW_CONNECT_DIALS_MIN = 10
DEFAULT_LOW_CONNECT_RATIO = 0.34
DEFAULT_LOW_ACTIVITY_TOTAL = 2
DEFAULT_MANAGER_MISSING_NEXT_STEP_LIMIT = 3
DEFAULT_MANAGER_OVERDUE_TASKS_LIMIT = 1
DEFAULT_MANAGER_LOST_DEALS_LIMIT = 2
DEFAULT_MANAGER_LATE_STAGE_STUCK_LIMIT = 2


def _now_moscow(now: datetime | None = None) -> datetime:
    return now_moscow(now)


def _previous_business_day_window(now: datetime | None = None) -> tuple[datetime, datetime]:
    return previous_business_day_window(now)


def _as_iso(dt: datetime) -> str:
    return dt.astimezone(MOSCOW_TZ).replace(microsecond=0).isoformat()


def _window_bounds(
    now: datetime | None = None,
    *,
    period_start: datetime | None = None,
    period_end: datetime | None = None,
) -> tuple[datetime, datetime]:
    if period_start is not None and period_end is not None:
        return (period_start.astimezone(MOSCOW_TZ), period_end.astimezone(MOSCOW_TZ))
    return _previous_business_day_window(now)


def _extract_result_list(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        for key in ("items", "result", "history", "sessions"):
            nested = payload.get(key)
            if isinstance(nested, list):
                return [item for item in nested if isinstance(item, dict)]
    return []


def _pick_first(item: Mapping[str, Any], *keys: str) -> str:
    for key in keys:
        value = item.get(key)
        if value not in (None, ""):
            return str(value).strip()
    return ""


def _event_dt(item: Mapping[str, Any], *keys: str) -> datetime | None:
    for key in keys:
        value = item.get(key)
        raw = str(value or "").strip()
        if not raw:
            continue
        if raw.endswith("Z"):
            raw = raw[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(raw)
        except ValueError:
            continue
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=MOSCOW_TZ)
        return parsed.astimezone(MOSCOW_TZ)
    return None


def _csv_values(value: Any) -> list[str]:
    if value in (None, ""):
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(item).strip() for item in value if str(item).strip()]
    return [item.strip() for item in str(value).split(",") if item.strip()]


def _int_env(env: Mapping[str, Any] | None, key: str, default: int) -> int:
    raw = str((env or {}).get(key) or "").strip()
    if not raw:
        return int(default)
    try:
        return int(raw)
    except ValueError:
        return int(default)


def _float_env(env: Mapping[str, Any] | None, key: str, default: float) -> float:
    raw = str((env or {}).get(key) or "").strip()
    if not raw:
        return float(default)
    try:
        return float(raw.replace(",", "."))
    except ValueError:
        return float(default)


def _manager_name(user: Mapping[str, Any]) -> str:
    first_name = str(user.get("name") or "").strip()
    last_name = str(user.get("last_name") or "").strip()
    full_name = " ".join(part for part in (first_name, last_name) if part).strip()
    return full_name or str(user.get("full_name") or user.get("email") or "").strip()


def _manager_map(snapshot: Mapping[str, Any] | None) -> dict[str, str]:
    result: dict[str, str] = {}
    responsibles = (snapshot or {}).get("responsibles") or {}
    for user_id, user in responsibles.items():
        normalized_id = str(user_id or "").strip()
        if not normalized_id:
            continue
        full_name = _manager_name(user)
        if full_name:
            result[normalized_id] = full_name
    return result


def _normalize_person_name(value: Any) -> str:
    raw = str(value or "").strip().lower()
    if not raw:
        return ""
    cleaned = raw.replace('"', "").replace("ё", "е")
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned.strip(" :,-")


def _extract_operator_name_from_message(text: Any) -> str:
    raw = str(text or "").strip()
    if not raw:
        return ""
    bbcode_match = re.match(r"^\[b\](.+?)\:\[/b\](?:\[br\]|\s)", raw, flags=re.IGNORECASE)
    if bbcode_match:
        return str(bbcode_match.group(1) or "").strip()
    html_match = re.match(r"^<b>(.+?)\:</b><br\s*/?>", raw, flags=re.IGNORECASE)
    if html_match:
        return str(html_match.group(1) or "").strip()
    return ""


def _wazzup_message_dt(item: Mapping[str, Any]) -> datetime | None:
    return _event_dt(item, "dateTime", "timestamp", "createdAt")


def get_yesterday_wazzup_by_manager(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    now: datetime | None = None,
    allowed_manager_ids: set[str] | None = None,
) -> dict[str, Any]:
    start, end = _previous_business_day_window(now)
    return get_wazzup_by_manager_for_window(
        env,
        snapshot=snapshot,
        period_start=start,
        period_end=end,
        allowed_manager_ids=allowed_manager_ids,
        empty_message="За предыдущий рабочий день в Wazzup нет исходящей коммуникации менеджеров",
    )


def get_wazzup_by_manager_for_window(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    period_start: datetime,
    period_end: datetime,
    allowed_manager_ids: set[str] | None = None,
    empty_message: str | None = None,
) -> dict[str, Any]:
    provider = WazzupProvider.from_env(env)
    adapter = BitrixSalesAdapter.from_env(env)
    return provider.get_dialogs_by_manager_for_window(
        start=period_start,
        end=period_end,
        snapshot=snapshot,
        allowed_manager_ids=allowed_manager_ids,
        empty_message=empty_message,
        resolve_manager_names=lambda manager_ids, existing_map: _resolve_manager_names(
            adapter=adapter,
            manager_ids=manager_ids,
            existing_map=existing_map,
        ),
    )


def get_wazzup_archive_status(
    env: Mapping[str, Any] | None = None,
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    return WazzupProvider.from_env(env).get_archive_status(now=now)


def _message_groups_from_flat_payload(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, dict[str, Any]]] = {}
    pattern = re.compile(r"^(?:data|DATA)\[(\d+)\]\[([^\]]+)\]\[([^\]]+)\]$")

    for key, value in payload.items():
        match = pattern.match(str(key))
        if not match:
            continue
        index, section, field = match.groups()
        bucket = grouped.setdefault(index, {})
        section_bucket = bucket.setdefault(section.lower(), {})
        section_bucket[field.lower()] = value

    return [grouped[index] for index in sorted(grouped.keys(), key=int)]


def _event_messages(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    data = payload.get("DATA") or payload.get("data")
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    return _message_groups_from_flat_payload(payload)


def get_yesterday_openlines_from_event_archive(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    now: datetime | None = None,
    allowed_manager_ids: set[str] | None = None,
    period_start: datetime | None = None,
    period_end: datetime | None = None,
) -> dict[str, Any]:
    env_data = {str(key): str(value) for key, value in (env or {}).items()}
    state_dir = Path(str(env_data.get("BITRIX_APP_STATE_DIR") or "/opt/openclaw/state/bitrix_app")).expanduser()
    start, end = _window_bounds(now, period_start=period_start, period_end=period_end)
    manager_names = _manager_map(snapshot)

    allowed_names = {
        _normalize_person_name(manager_name): manager_id
        for manager_id, manager_name in manager_names.items()
        if manager_name and (allowed_manager_ids is None or manager_id in allowed_manager_ids)
    }

    counts: dict[str, dict[str, Any]] = {}
    total_messages = 0
    mapped_messages = 0
    files = sorted(state_dir.glob("handler*.json"))

    for path in files:
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(record, dict):
            continue
        payload = record.get("payload")
        if not isinstance(payload, dict):
            continue
        payload_event = str((record.get("summary") or {}).get("payload_event") or payload.get("event") or payload.get("EVENT") or "").strip().upper()
        if payload_event not in OPENLINES_EVENT_NAMES:
            continue
        saved_at = _event_dt(record, "saved_at")
        if saved_at is None or not (start <= saved_at < end):
            continue

        for item in _event_messages(payload):
            message = item.get("message")
            if not isinstance(message, Mapping):
                continue
            total_messages += 1
            operator_name = _extract_operator_name_from_message(message.get("text"))
            normalized_name = _normalize_person_name(operator_name)
            manager_id = allowed_names.get(normalized_name)
            if not manager_id:
                continue
            mapped_messages += 1
            row = counts.setdefault(
                manager_id,
                {
                    "manager_id": manager_id,
                    "manager_name": manager_names.get(manager_id) or operator_name or f"ID {manager_id}",
                    "openlines": 0,
                },
            )
            row["openlines"] += 1

    if total_messages <= 0:
        return {
            "available": False,
            "source": "bitrix_app_events",
            "status": "not configured",
            "message": "В архиве событий открытых линий за предыдущий рабочий день пока нет данных",
            "by_manager": [],
            "items": 0,
        }

    if mapped_messages <= 0:
        return {
            "available": False,
            "source": "bitrix_app_events",
            "status": "error",
            "message": "События открытых линий пришли, но не удалось сопоставить операторов",
            "by_manager": [],
            "items": total_messages,
        }

    rows = sorted(counts.values(), key=lambda item: int(item["openlines"]), reverse=True)
    return {
        "available": True,
        "source": "bitrix_app_events",
        "status": "ok",
        "message": f"Открытые линии из архива событий: {mapped_messages}/{total_messages}",
        "by_manager": rows,
        "items": total_messages,
    }


def _access_ok(snapshot: Mapping[str, Any] | None, key: str) -> bool:
    for item in (snapshot or {}).get("access_report") or []:
        if str(item.get("key") or "").strip() == key:
            return bool(item.get("ok"))
    return False


def _resolve_manager_names(
    adapter: BitrixSalesAdapter,
    manager_ids: list[str],
    existing_map: dict[str, str],
) -> dict[str, str]:
    pending_ids = [manager_id for manager_id in manager_ids if manager_id and manager_id not in existing_map]
    if not pending_ids:
        return dict(existing_map)

    resolved = dict(existing_map)
    for user in adapter.get_users(limit=max(len(pending_ids), 1) + 10, user_ids=pending_ids):
        manager_id = str(user.get("id") or "").strip()
        if not manager_id:
            continue
        full_name = _manager_name(user)
        if full_name:
            resolved[manager_id] = full_name
    return resolved


def _resolve_sales_team_filter(
    adapter: BitrixSalesAdapter,
    env: Mapping[str, Any] | None,
    snapshot: Mapping[str, Any] | None,
) -> dict[str, Any]:
    departments = [item for item in ((snapshot or {}).get("departments") or []) if isinstance(item, dict)]
    departments_by_id = {
        str(item.get("id") or "").strip(): item
        for item in departments
        if str(item.get("id") or "").strip()
    }
    departments_by_name: dict[str, list[dict[str, Any]]] = {}
    for item in departments:
        name = str(item.get("name") or "").strip()
        if not name:
            continue
        departments_by_name.setdefault(name, []).append(item)

    configured_ids = _csv_values((env or {}).get("SALES_DEPARTMENT_IDS"))
    configured_names = _csv_values((env or {}).get("SALES_DEPARTMENT_NAMES")) or list(DEFAULT_SALES_DEPARTMENT_NAMES)
    mode = "ids" if configured_ids else "names"

    found_departments: list[dict[str, Any]] = []
    missing_departments: list[str] = []
    warnings: list[str] = []

    if not _access_ok(snapshot, "departments"):
        warnings.append("Структура подразделений Bitrix недоступна")
    elif not departments:
        warnings.append("department.get не вернул подразделения")

    if configured_ids:
        for department_id in configured_ids:
            item = departments_by_id.get(department_id)
            if not item:
                missing_departments.append(department_id)
                warnings.append(f"Подразделение с ID {department_id} не найдено в структуре Bitrix")
                continue
            found_departments.append(item)
    else:
        for department_name in configured_names:
            exact_matches = departments_by_name.get(department_name) or []
            if not exact_matches:
                missing_departments.append(department_name)
                warnings.append(f'Подразделение "{department_name}" не найдено по точному совпадению')
                continue
            if len(exact_matches) > 1:
                warnings.append(
                    f'Подразделение "{department_name}" найдено несколько раз: '
                    + ", ".join(str(item.get("id") or "") for item in exact_matches if item.get("id"))
                )
            found_departments.extend(exact_matches)

    deduped_departments: list[dict[str, Any]] = []
    seen_department_ids: set[str] = set()
    for item in found_departments:
        department_id = str(item.get("id") or "").strip()
        if not department_id or department_id in seen_department_ids:
            continue
        seen_department_ids.add(department_id)
        deduped_departments.append(item)

    department_ids = [str(item.get("id") or "").strip() for item in deduped_departments if str(item.get("id") or "").strip()]
    department_names_by_id = {
        str(item.get("id") or "").strip(): str(item.get("name") or "").strip()
        for item in deduped_departments
        if str(item.get("id") or "").strip()
    }

    allowlist_users: list[dict[str, Any]] = []
    manager_allowlist: dict[str, str] = {}

    if department_ids:
        if not _access_ok(snapshot, "users"):
            warnings.append("Список сотрудников Bitrix недоступен")
        else:
            try:
                users = adapter.get_users(limit=500, department_ids=department_ids)
            except BitrixAPIError as error:
                users = []
                warnings.append(f"Не удалось загрузить сотрудников sales-подразделений: {error.message}")
            if not users:
                try:
                    fallback_users = adapter.get_users(limit=500)
                except BitrixAPIError as error:
                    fallback_users = []
                    warnings.append(f"Fallback user.get по всем сотрудникам не сработал: {error.message}")
                users = [
                    user
                    for user in fallback_users
                    if set(user.get("department_ids") or []).intersection(department_ids)
                ]
                if users:
                    warnings.append("UF_DEPARTMENT filter вернул пустой список; использован fallback по полному user.get")

            for user in users:
                if not bool(user.get("active", True)):
                    continue
                manager_id = str(user.get("id") or "").strip()
                if not manager_id:
                    continue
                memberships = [
                    department_id
                    for department_id in (user.get("department_ids") or [])
                    if department_id in department_names_by_id
                ]
                if not memberships:
                    continue
                manager_name = _manager_name(user) or f"ID {manager_id}"
                allowlist_users.append(
                    {
                        "manager_id": manager_id,
                        "manager_name": manager_name,
                        "department_ids": memberships,
                        "department_names": [department_names_by_id[department_id] for department_id in memberships],
                    }
                )
                manager_allowlist[manager_id] = manager_name

            allowlist_users.sort(key=lambda item: item["manager_name"])
            if not allowlist_users:
                warnings.append("В выбранных продажных подразделениях не найдено активных сотрудников")

    return {
        "mode": mode,
        "configured_ids": configured_ids,
        "configured_names": configured_names,
        "found_departments": [
            {
                "id": str(item.get("id") or "").strip(),
                "name": str(item.get("name") or "").strip(),
            }
            for item in deduped_departments
        ],
        "missing_departments": missing_departments,
        "warnings": warnings,
        "manager_ids": sorted(manager_allowlist),
        "manager_allowlist": manager_allowlist,
        "allowlist_users": allowlist_users,
        "allowlist_count": len(allowlist_users),
    }


def resolve_sales_team_filter(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    adapter: BitrixSalesAdapter | None = None,
) -> dict[str, Any]:
    active_adapter = adapter or BitrixSalesAdapter.from_env(env)
    return _resolve_sales_team_filter(active_adapter, env, snapshot)


def _employee_role_from_departments(department_names: list[str] | tuple[str, ...] | None) -> tuple[str, str]:
    normalized = {str(item).strip() for item in (department_names or []) if str(item).strip()}
    if normalized.intersection(TELEMARKETING_ROLE_DEPARTMENT_NAMES):
        return ("telemarketing", "телемаркетинг")
    if normalized.intersection(SALES_ROLE_DEPARTMENT_NAMES):
        return ("sales", "продажи")
    return ("unknown", "не определена")


def get_yesterday_calls_by_manager(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    now: datetime | None = None,
    allowed_manager_ids: set[str] | None = None,
) -> dict[str, Any]:
    start, end = _previous_business_day_window(now)
    return get_calls_by_manager_for_window(
        env,
        snapshot=snapshot,
        period_start=start,
        period_end=end,
        allowed_manager_ids=allowed_manager_ids,
    )


def get_calls_by_manager_for_window(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    period_start: datetime,
    period_end: datetime,
    allowed_manager_ids: set[str] | None = None,
) -> dict[str, Any]:
    adapter = BitrixSalesAdapter.from_env(env)

    try:
        activities = adapter.get_activities(
            limit=250,
            filter_params={
                "TYPE_ID": "2",
                ">=CREATED": _as_iso(period_start),
                "<CREATED": _as_iso(period_end),
            },
            order={"CREATED": "DESC"},
        )
    except BitrixAPIError as error:
        return {
            "available": False,
            "source": "crm.activity.list",
            "status": error.to_status(),
            "message": error.message,
            "by_manager": [],
            "items": 0,
        }

    manager_names = _manager_map(snapshot)
    calls_by_manager: dict[str, dict[str, Any]] = {}

    for activity in activities:
        activity_type = str(activity.get("type_id") or "").strip()
        if activity_type and activity_type != "2":
            continue
        provider_id = str(activity.get("provider_id") or "").upper()
        provider_type = str(activity.get("provider_type_id") or "").upper()
        if provider_type != "CALL" and "CALL" not in provider_id:
            continue

        manager_id = str(activity.get("responsible_id") or activity.get("author_id") or "").strip()
        if not manager_id:
            continue
        if allowed_manager_ids is not None and manager_id not in allowed_manager_ids:
            continue

        item = calls_by_manager.setdefault(
            manager_id,
            {
                "manager_id": manager_id,
                "manager_name": manager_names.get(manager_id, ""),
                "dials": 0,
                "normal_calls": 0,
                "calls_total_duration_sec": 0,
                "source_items": 0,
            },
        )
        item["dials"] += 1
        item["source_items"] += 1
        duration_sec = int(activity.get("duration_sec") or 0)
        item["calls_total_duration_sec"] += duration_sec
        if duration_sec >= 60:
            item["normal_calls"] += 1

    manager_names = _resolve_manager_names(adapter, list(calls_by_manager.keys()), manager_names)
    for manager_id, item in calls_by_manager.items():
        item["manager_name"] = manager_names.get(manager_id) or f"ID {manager_id}"

    rows = sorted(
        calls_by_manager.values(),
        key=lambda item: (int(item["dials"]), int(item["normal_calls"]), int(item["calls_total_duration_sec"])),
        reverse=True,
    )
    return {
        "available": True,
        "source": "crm.activity.list",
        "status": "ok",
        "message": f"Звонки из crm.activity.list: {len(activities)}",
        "by_manager": rows,
        "items": len(activities),
    }


def get_yesterday_openlines_by_manager(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    now: datetime | None = None,
    allowed_manager_ids: set[str] | None = None,
) -> dict[str, Any]:
    start, end = _previous_business_day_window(now)
    return get_openlines_by_manager_for_window(
        env,
        snapshot=snapshot,
        period_start=start,
        period_end=end,
        allowed_manager_ids=allowed_manager_ids,
    )


def get_openlines_by_manager_for_window(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    period_start: datetime,
    period_end: datetime,
    allowed_manager_ids: set[str] | None = None,
) -> dict[str, Any]:
    adapter = BitrixSalesAdapter.from_env(env)
    provider = adapter.provider
    app_auth = BitrixAppAuth.from_env(env)
    use_app_auth = app_auth.is_configured()

    wazzup = get_wazzup_by_manager_for_window(
        env,
        snapshot=snapshot,
        period_start=period_start,
        period_end=period_end,
        allowed_manager_ids=allowed_manager_ids,
    )
    if wazzup.get("available"):
        return wazzup

    if provider.mode() == "fixture":
        return {
            "available": False,
            "source": "imopenlines.session.history.get",
            "status": "not configured",
            "message": "Во fixture нет данных по открытым линиям",
            "by_manager": [],
            "items": 0,
        }

    try:
        if use_app_auth:
            payload = app_auth.call_method(
                "imopenlines.session.history.get",
                params={"FILTER": {">=DATE_MODIFY": _as_iso(period_start), "<DATE_MODIFY": _as_iso(period_end)}},
                default=[],
            )
            source = "bitrix_app:imopenlines.session.history.get"
        else:
            payload = provider.call_method(
                "imopenlines.session.history.get",
                params={"FILTER": {">=DATE_MODIFY": _as_iso(period_start), "<DATE_MODIFY": _as_iso(period_end)}},
                default=[],
            )
            source = "imopenlines.session.history.get"
    except BitrixAPIError as error:
        if "session id or chat id must be provided" in str(error.message or "").strip().lower():
            event_fallback = get_yesterday_openlines_from_event_archive(
                env,
                snapshot=snapshot,
                allowed_manager_ids=allowed_manager_ids,
                period_start=period_start,
                period_end=period_end,
            )
            if event_fallback.get("available"):
                return event_fallback
            combined_message = (
                f"{error.message}. "
                f"{event_fallback.get('message') or event_fallback.get('status')}"
            )
            return {
                "available": False,
                "source": event_fallback.get("source") or "bitrix_app:imopenlines.session.history.get",
                "status": event_fallback.get("status") or error.to_status(),
                "message": combined_message,
                "by_manager": [],
                "items": int(event_fallback.get("items") or 0),
            }
        return {
            "available": False,
            "source": "bitrix_app:imopenlines.session.history.get" if use_app_auth else "imopenlines.session.history.get",
            "status": error.to_status(),
            "message": error.message,
            "by_manager": [],
            "items": 0,
        }

    items = _extract_result_list(payload)
    manager_names = _manager_map(snapshot)
    counts: dict[str, dict[str, Any]] = {}

    for item in items:
        manager_id = _pick_first(item, "OPERATOR_ID", "RESPONSIBLE_ID", "ASSIGNED_BY_ID", "USER_ID")
        if not manager_id:
            continue
        if allowed_manager_ids is not None and manager_id not in allowed_manager_ids:
            continue
        occurred_at = _event_dt(item, "DATE_MODIFY", "DATE_CREATE", "START_DATE")
        if occurred_at is None or not (period_start <= occurred_at < period_end):
            continue
        row = counts.setdefault(
            manager_id,
            {
                "manager_id": manager_id,
                "manager_name": manager_names.get(manager_id, ""),
                "openlines": 0,
            },
        )
        row["openlines"] += 1

    manager_names = _resolve_manager_names(adapter, list(counts.keys()), manager_names)
    for manager_id, item in counts.items():
        item["manager_name"] = manager_names.get(manager_id) or f"ID {manager_id}"

    rows = sorted(counts.values(), key=lambda item: int(item["openlines"]), reverse=True)
    return {
        "available": True,
        "source": source,
        "status": "ok",
        "message": f"Коммуникации open lines: {len(items)}",
        "by_manager": rows,
        "items": len(items),
    }


def get_yesterday_communications_summary(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    analysis: Mapping[str, Any] | None = None,
    now: datetime | None = None,
    department_filter: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    start, end = _previous_business_day_window(now)
    return get_communications_summary_for_window(
        env,
        snapshot=snapshot,
        analysis=analysis,
        period_start=start,
        period_end=end,
        department_filter=department_filter,
    )


def get_communications_summary_for_window(
    env: Mapping[str, Any] | None = None,
    *,
    snapshot: Mapping[str, Any] | None = None,
    analysis: Mapping[str, Any] | None = None,
    period_start: datetime,
    period_end: datetime,
    department_filter: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    adapter = BitrixSalesAdapter.from_env(env)
    resolved_department_filter = dict(department_filter or {}) or resolve_sales_team_filter(
        env,
        snapshot=snapshot,
        adapter=adapter,
    )
    allowed_manager_ids = set(resolved_department_filter.get("manager_ids") or [])
    stale_communication_days = _int_env(env, "SALES_STALE_COMMUNICATION_DAYS", DEFAULT_STALE_COMMUNICATION_DAYS)
    low_connect_dials_min = _int_env(env, "SALES_SIGNAL_LOW_CONNECT_DIALS_MIN", DEFAULT_LOW_CONNECT_DIALS_MIN)
    low_connect_ratio = _float_env(env, "SALES_SIGNAL_LOW_CONNECT_RATIO", DEFAULT_LOW_CONNECT_RATIO)
    low_activity_total = _int_env(env, "SALES_SIGNAL_LOW_ACTIVITY_TOTAL", DEFAULT_LOW_ACTIVITY_TOTAL)
    missing_next_step_limit = _int_env(
        env, "SALES_SIGNAL_MANAGER_MISSING_NEXT_STEP_LIMIT", DEFAULT_MANAGER_MISSING_NEXT_STEP_LIMIT
    )
    overdue_tasks_limit = _int_env(env, "SALES_SIGNAL_MANAGER_OVERDUE_TASKS_LIMIT", DEFAULT_MANAGER_OVERDUE_TASKS_LIMIT)
    lost_deals_limit = _int_env(env, "SALES_SIGNAL_MANAGER_LOST_DEALS_LIMIT", DEFAULT_MANAGER_LOST_DEALS_LIMIT)
    late_stage_stuck_limit = _int_env(
        env, "SALES_SIGNAL_MANAGER_LATE_STAGE_STUCK_LIMIT", DEFAULT_MANAGER_LATE_STAGE_STUCK_LIMIT
    )

    calls = get_calls_by_manager_for_window(
        env,
        snapshot=snapshot,
        period_start=period_start,
        period_end=period_end,
        allowed_manager_ids=allowed_manager_ids,
    )
    messengers = get_wazzup_by_manager_for_window(
        env,
        snapshot=snapshot,
        period_start=period_start,
        period_end=period_end,
        allowed_manager_ids=allowed_manager_ids,
    )

    expected_managers = dict(resolved_department_filter.get("manager_allowlist") or {})
    allowlist_meta_by_manager: dict[str, dict[str, Any]] = {}
    for item in resolved_department_filter.get("allowlist_users") or []:
        manager_id = str(item.get("manager_id") or "").strip()
        if not manager_id:
            continue
        department_names = [str(name).strip() for name in (item.get("department_names") or []) if str(name).strip()]
        employee_role, employee_role_label = _employee_role_from_departments(department_names)
        allowlist_meta_by_manager[manager_id] = {
            "department_names": department_names,
            "employee_role": employee_role,
            "employee_role_label": employee_role_label,
        }
    combined: dict[str, dict[str, Any]] = {}

    for item in calls.get("by_manager") or []:
        manager_id = str(item.get("manager_id") or "").strip()
        if not manager_id:
            continue
        role_meta = allowlist_meta_by_manager.get(manager_id) or {}
        combined.setdefault(
            manager_id,
            {
                "manager_id": manager_id,
                "manager_name": item.get("manager_name") or expected_managers.get(manager_id) or f"ID {manager_id}",
                "department_names": list(role_meta.get("department_names") or []),
                "employee_role": str(role_meta.get("employee_role") or "unknown"),
                "employee_role_label": str(role_meta.get("employee_role_label") or "не определена"),
                "dials": 0,
                "normal_calls": 0,
                "messenger_dialogs": None if not messengers.get("available") else 0,
                "connect_rate": None,
                "total_known": 0,
            },
        )
        combined[manager_id]["dials"] = int(item.get("dials") or 0)
        combined[manager_id]["normal_calls"] = int(item.get("normal_calls") or 0)
        combined[manager_id]["connect_rate"] = (
            round(int(item.get("normal_calls") or 0) / int(item.get("dials") or 0), 2)
            if int(item.get("dials") or 0) > 0
            else None
        )

    for item in messengers.get("by_manager") or []:
        manager_id = str(item.get("manager_id") or "").strip()
        if not manager_id:
            continue
        role_meta = allowlist_meta_by_manager.get(manager_id) or {}
        combined.setdefault(
            manager_id,
            {
                "manager_id": manager_id,
                "manager_name": item.get("manager_name") or expected_managers.get(manager_id) or f"ID {manager_id}",
                "department_names": list(role_meta.get("department_names") or []),
                "employee_role": str(role_meta.get("employee_role") or "unknown"),
                "employee_role_label": str(role_meta.get("employee_role_label") or "не определена"),
                "dials": 0,
                "normal_calls": 0,
                "messenger_dialogs": 0,
                "connect_rate": None,
                "total_known": 0,
            },
        )
        combined[manager_id]["messenger_dialogs"] = int(item.get("messenger_dialogs") or 0)

    for manager_id, manager_name in expected_managers.items():
        role_meta = allowlist_meta_by_manager.get(manager_id) or {}
        combined.setdefault(
            manager_id,
            {
                "manager_id": manager_id,
                "manager_name": manager_name or f"ID {manager_id}",
                "department_names": list(role_meta.get("department_names") or []),
                "employee_role": str(role_meta.get("employee_role") or "unknown"),
                "employee_role_label": str(role_meta.get("employee_role_label") or "не определена"),
                "dials": 0,
                "normal_calls": 0,
                "messenger_dialogs": None if not messengers.get("available") else 0,
                "connect_rate": None,
                "total_known": 0,
            },
        )

    for item in combined.values():
        role_meta = allowlist_meta_by_manager.get(str(item.get("manager_id") or "").strip()) or {}
        if role_meta:
            item["department_names"] = list(role_meta.get("department_names") or [])
            item["employee_role"] = str(role_meta.get("employee_role") or "unknown")
            item["employee_role_label"] = str(role_meta.get("employee_role_label") or "не определена")
        messenger_value = item.get("messenger_dialogs")
        item["total_known"] = int(item.get("dials") or 0) + (
            int(messenger_value or 0) if messenger_value is not None else 0
        )

    analysis_payload = analysis or {}
    overdue_tasks_by_manager = {
        str(item.get("manager_id") or item.get("manager_name") or "").strip(): item
        for item in analysis_payload.get("overdue_deal_tasks_by_manager") or []
        if str(item.get("manager_id") or item.get("manager_name") or "").strip()
    }
    missing_next_step_by_manager: dict[str, int] = {}
    stale_communication_by_manager: dict[str, int] = {}
    late_stage_stuck_by_manager: dict[str, int] = {}
    lost_deals_by_manager: dict[str, int] = {}

    for deal in analysis_payload.get("active_deals") or []:
        manager_id = str(deal.get("assigned_id") or "").strip()
        if not manager_id:
            continue
        if deal.get("missing_next_step"):
            missing_next_step_by_manager[manager_id] = missing_next_step_by_manager.get(manager_id, 0) + 1
        if int(deal.get("communication_gap_days") or 0) >= stale_communication_days:
            stale_communication_by_manager[manager_id] = stale_communication_by_manager.get(manager_id, 0) + 1
        if deal.get("late_stage") and int(deal.get("inactive_days") or 0) >= _int_env(
            env, "SALES_LATE_STAGE_INACTIVITY_DAYS", 5
        ):
            late_stage_stuck_by_manager[manager_id] = late_stage_stuck_by_manager.get(manager_id, 0) + 1

    for deal in analysis_payload.get("lost_deals_yesterday") or []:
        manager_id = str(deal.get("assigned_id") or "").strip()
        if manager_id:
            lost_deals_by_manager[manager_id] = lost_deals_by_manager.get(manager_id, 0) + 1

    can_assess_calls = bool(calls.get("available"))
    can_assess_messengers = bool(messengers.get("available"))
    manager_rows: list[dict[str, Any]] = []
    for item in combined.values():
        manager_id = str(item.get("manager_id") or "").strip()
        dials = int(item.get("dials") or 0)
        normal_calls = int(item.get("normal_calls") or 0)
        messenger_dialogs = item.get("messenger_dialogs")
        total_known = int(item.get("total_known") or 0)
        connect_rate = item.get("connect_rate")
        overdue_count = int((overdue_tasks_by_manager.get(manager_id) or {}).get("count") or 0)
        max_days_overdue = int((overdue_tasks_by_manager.get(manager_id) or {}).get("max_days_overdue") or 0)
        missing_next_step_count = int(missing_next_step_by_manager.get(manager_id) or 0)
        stale_communication_count = int(stale_communication_by_manager.get(manager_id) or 0)
        late_stage_stuck_count = int(late_stage_stuck_by_manager.get(manager_id) or 0)
        lost_deals_count = int(lost_deals_by_manager.get(manager_id) or 0)
        no_activity = bool((can_assess_calls or can_assess_messengers) and total_known == 0)
        low_connect = bool(
            can_assess_calls
            and dials >= low_connect_dials_min
            and connect_rate is not None
            and float(connect_rate) < low_connect_ratio
        )
        messenger_only = bool(can_assess_calls and dials == 0 and can_assess_messengers and int(messenger_dialogs or 0) > 0)
        low_activity = bool((can_assess_calls or can_assess_messengers) and 0 < total_known <= low_activity_total)
        low_communication = bool(no_activity or low_connect or low_activity)

        manager_rows.append(
            {
                **item,
                "overdue_tasks_count": overdue_count,
                "max_days_overdue": max_days_overdue,
                "missing_next_step_count": missing_next_step_count,
                "stale_communication_count": stale_communication_count,
                "late_stage_stuck_count": late_stage_stuck_count,
                "lost_deals_yesterday_count": lost_deals_count,
                "no_activity": no_activity,
                "low_connect": low_connect,
                "low_activity": low_activity,
                "low_communication": low_communication,
                "messenger_only": messenger_only,
            }
        )

    manager_rows.sort(
        key=lambda item: (
            int(item.get("total_known") or 0),
            int(item.get("dials") or 0),
            int(item.get("normal_calls") or 0),
            str(item.get("manager_name") or ""),
        ),
        reverse=True,
    )

    signals: list[str] = []
    for item in sorted(
        manager_rows,
        key=lambda row: (
            int(row.get("no_activity") or 0),
            int(row.get("overdue_tasks_count") or 0),
            int(row.get("missing_next_step_count") or 0),
            int(row.get("stale_communication_count") or 0),
            int(row.get("dials") or 0),
        ),
        reverse=True,
    ):
        manager_name = str(item.get("manager_name") or "без ответственного").strip()
        dials = int(item.get("dials") or 0)
        messenger_dialogs = item.get("messenger_dialogs")
        connect_rate = item.get("connect_rate")

        if can_assess_calls and dials >= low_connect_dials_min and connect_rate is not None and connect_rate < low_connect_ratio:
            signals.append(f"{manager_name} — много наборов, мало разговоров")
            continue
        if can_assess_calls and dials == 0 and can_assess_messengers and int(messenger_dialogs or 0) > 0:
            signals.append(f"{manager_name} — активность только в мессенджерах")
            continue
        if can_assess_calls and dials == 0 and (not can_assess_messengers or int(messenger_dialogs or 0) == 0):
            signals.append(f"{manager_name} — отсутствуют коммуникации за предыдущий рабочий день")
            continue
        overdue_count = int(item.get("overdue_tasks_count") or 0)
        if overdue_count >= overdue_tasks_limit:
            signals.append(f"{manager_name} — есть просроченные задачи по сделкам ({overdue_count})")
            continue
        if int(item.get("missing_next_step_count") or 0) >= missing_next_step_limit:
            signals.append(
                f"{manager_name} — много сделок без следующего шага ({int(item.get('missing_next_step_count') or 0)})"
            )
            continue
        if int(item.get("stale_communication_count") or 0) > 0:
            signals.append(
                f"{manager_name} — есть запущенные сделки без коммуникации > {stale_communication_days} дн."
            )
            continue
        if int(item.get("lost_deals_yesterday_count") or 0) >= lost_deals_limit:
            signals.append(f"{manager_name} — много отказов за предыдущий рабочий день ({int(item.get('lost_deals_yesterday_count') or 0)})")
            continue
        if int(item.get("late_stage_stuck_count") or 0) >= late_stage_stuck_limit:
            signals.append(
                f"{manager_name} — нет движения по поздним стадиям ({int(item.get('late_stage_stuck_count') or 0)})"
            )
            continue
        if (can_assess_calls or can_assess_messengers) and 0 < int(item.get("total_known") or 0) <= low_activity_total:
            signals.append(f"{manager_name} — низкая коммуникационная активность")
            continue

    detailed_limitations: list[str] = list(resolved_department_filter.get("warnings") or [])
    system_limitations: list[str] = []
    if resolved_department_filter.get("warnings"):
        system_limitations.extend(resolved_department_filter.get("warnings") or [])
    if not can_assess_calls:
        detailed_limitations.append(f"Данные по звонкам недоступны: {calls.get('message') or calls.get('status')}")
        system_limitations.append(f"Данные по звонкам недоступны: {calls.get('message') or calls.get('status')}")
    if not can_assess_messengers:
        detailed_limitations.append(
            f"Диалоги в мессенджерах недоступны: {messengers.get('message') or messengers.get('status')}"
        )
        system_limitations.append(
            f"Диалоги в мессенджерах недоступны: {messengers.get('message') or messengers.get('status')}"
        )

    return {
        "period_start": _as_iso(period_start),
        "period_end": _as_iso(period_end),
        "calls": calls,
        "messengers": messengers,
        "managers": manager_rows,
        "manager_stats": manager_rows,
        "team_metrics": {
            "manager_count": len(manager_rows),
            "managers_with_overdue_tasks": sum(
                1 for item in manager_rows if int(item.get("overdue_tasks_count") or 0) >= overdue_tasks_limit
            ),
            "managers_with_low_communication": sum(1 for item in manager_rows if bool(item.get("low_communication"))),
            "managers_with_no_activity": sum(1 for item in manager_rows if bool(item.get("no_activity"))),
        },
        "thresholds": {
            "stale_communication_days": stale_communication_days,
            "low_connect_dials_min": low_connect_dials_min,
            "low_connect_ratio": low_connect_ratio,
            "low_activity_total": low_activity_total,
            "missing_next_step_limit": missing_next_step_limit,
            "overdue_tasks_limit": overdue_tasks_limit,
            "lost_deals_limit": lost_deals_limit,
            "late_stage_stuck_limit": late_stage_stuck_limit,
        },
        "signals": signals[:5],
        "limitations": list(dict.fromkeys(item for item in detailed_limitations if item)),
        "system_limitations": list(dict.fromkeys(item for item in system_limitations if item)),
        "department_filter": resolved_department_filter,
    }
