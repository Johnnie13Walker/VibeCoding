from __future__ import annotations

import json
import tempfile
import unittest
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from agents.sales_agent.pipeline_analyzer import BRIEF_PREP_STAGE_ID, analyze_pipeline
from cloudbot.business_day import (
    current_business_week,
    current_business_week_window,
    previous_business_day,
    previous_business_day_window,
    previous_business_week,
    previous_business_week_window,
)
from cloudbot.providers.wazzup_provider import WazzupProvider

MOSCOW_TZ = ZoneInfo("Europe/Moscow")


class BusinessDayTests(unittest.TestCase):
    def test_previous_business_day_skips_weekend(self) -> None:
        self.assertEqual(previous_business_day(date(2026, 3, 16)), date(2026, 3, 13))
        self.assertEqual(previous_business_day(date(2026, 3, 15)), date(2026, 3, 13))
        self.assertEqual(previous_business_day(date(2026, 3, 17)), date(2026, 3, 16))

    def test_previous_business_day_window_for_monday_points_to_friday(self) -> None:
        start, end = previous_business_day_window(datetime(2026, 3, 16, 9, 30, tzinfo=MOSCOW_TZ))
        self.assertEqual(start, datetime(2026, 3, 13, 0, 0, tzinfo=MOSCOW_TZ))
        self.assertEqual(end, datetime(2026, 3, 14, 0, 0, tzinfo=MOSCOW_TZ))

    def test_current_business_week_returns_monday_to_friday(self) -> None:
        self.assertEqual(current_business_week(date(2026, 3, 21)), (date(2026, 3, 16), date(2026, 3, 20)))
        self.assertEqual(current_business_week(date(2026, 3, 18)), (date(2026, 3, 16), date(2026, 3, 20)))

    def test_previous_business_week_returns_previous_monday_to_friday(self) -> None:
        self.assertEqual(previous_business_week(date(2026, 3, 21)), (date(2026, 3, 9), date(2026, 3, 13)))

    def test_current_business_week_window_uses_full_workweek(self) -> None:
        start, end = current_business_week_window(datetime(2026, 3, 21, 18, 30, tzinfo=MOSCOW_TZ))
        self.assertEqual(start, datetime(2026, 3, 16, 0, 0, tzinfo=MOSCOW_TZ))
        self.assertEqual(end, datetime(2026, 3, 21, 0, 0, tzinfo=MOSCOW_TZ))

    def test_previous_business_week_window_uses_previous_full_workweek(self) -> None:
        start, end = previous_business_week_window(datetime(2026, 3, 21, 18, 30, tzinfo=MOSCOW_TZ))
        self.assertEqual(start, datetime(2026, 3, 9, 0, 0, tzinfo=MOSCOW_TZ))
        self.assertEqual(end, datetime(2026, 3, 14, 0, 0, tzinfo=MOSCOW_TZ))

    def test_pipeline_uses_previous_business_day_on_monday(self) -> None:
        snapshot = {
            "source": "fixture",
            "portal_base_url": "https://belberrycrm.bitrix24.ru",
            "limitations": [],
            "responsibles": {"2818": {"name": "Иван", "last_name": "Халин"}},
            "companies": [],
            "contacts": [],
            "departments": [],
            "deal_stage_map": [{"STATUS_ID": BRIEF_PREP_STAGE_ID, "NAME": "Подготовка БРИФа"}],
            "meeting_stage_map": [],
            "brief_stage_map": [],
            "recent_deals": [],
            "active_deals": [
                {
                    "id": "1",
                    "title": "Сделка пятницы",
                    "assigned_id": "2818",
                    "created_at": "2026-03-10T10:00:00+03:00",
                    "updated_at": "2026-03-13T13:00:00+03:00",
                    "moved_at": "2026-03-13T13:00:00+03:00",
                    "stage_id": BRIEF_PREP_STAGE_ID,
                    "semantic_id": "P",
                    "amount": "90000",
                    "source_id": "SEO",
                },
                {
                    "id": "2",
                    "title": "Сделка воскресенья",
                    "assigned_id": "2818",
                    "created_at": "2026-03-10T10:00:00+03:00",
                    "updated_at": "2026-03-15T13:00:00+03:00",
                    "moved_at": "2026-03-15T13:00:00+03:00",
                    "stage_id": BRIEF_PREP_STAGE_ID,
                    "semantic_id": "P",
                    "amount": "91000",
                    "source_id": "SEO",
                },
            ],
            "conducted_meetings": [],
            "accepted_briefs": [],
            "task_status_map": {"5": "Завершена"},
            "next_step_source": "crm.activity.list",
        }

        result = analyze_pipeline(snapshot, now=datetime(2026, 3, 16, 9, 30, tzinfo=MOSCOW_TZ))

        self.assertEqual(result["metrics"]["new_deals_yesterday"], 1)
        self.assertEqual(result["new_deals_yesterday"][0]["title"], "Сделка пятницы")

    def test_wazzup_provider_uses_previous_business_day_on_monday(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            state_dir = Path(tmp_dir)
            record = {
                "saved_at": "2026-03-16T10:49:00+03:00",
                "event": "wazzup",
                "payload": {
                    "messages": [
                        {
                            "messageId": "m1",
                            "chatId": "chat-friday",
                            "authorId": "2806",
                            "isEcho": True,
                            "dateTime": "2026-03-13T07:10:00.001Z",
                            "text": "пятница",
                        },
                        {
                            "messageId": "m2",
                            "chatId": "chat-sunday",
                            "authorId": "2806",
                            "isEcho": True,
                            "dateTime": "2026-03-15T07:10:00.001Z",
                            "text": "воскресенье",
                        },
                    ],
                },
            }
            (state_dir / "wazzup.20260316T104900000000.json").write_text(json.dumps(record, ensure_ascii=False), encoding="utf-8")

            provider = WazzupProvider(state_dir=state_dir)
            result = provider.get_archive_status(now=datetime(2026, 3, 16, 9, 0, 0, tzinfo=MOSCOW_TZ))

            self.assertTrue(result["available"])
            self.assertEqual(result["dialogs_yesterday"], 1)
            self.assertEqual(result["messages_yesterday"], 1)


if __name__ == "__main__":
    unittest.main()
