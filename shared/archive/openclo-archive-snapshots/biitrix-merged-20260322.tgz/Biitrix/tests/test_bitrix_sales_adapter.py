from __future__ import annotations

import unittest

from cloudbot.providers.bitrix.bitrix_sales_adapter import BitrixSalesAdapter
from cloudbot.providers.bitrix_provider import BitrixAPIError


class _ProviderStub:
    def list_tasks(self, *, limit=None):  # noqa: ANN001
        raise BitrixAPIError(
            "The request requires higher privileges than provided by the webhook token",
            code="insufficient_scope",
            category="access_denied",
            http_status=401,
        )

    def mode(self) -> str:
        return "webhook"


class _AppAuthStub:
    def is_configured(self) -> bool:
        return True

    def call_method(self, method: str, params=None, *, default=None):  # noqa: ANN001
        if method == "tasks.task.getFields":
            return {
                "fields": {
                    "STATUS": {
                        "values": {
                            "2": "Ждёт выполнения",
                            "5": "Завершена",
                        }
                    }
                }
            }
        if method != "tasks.task.list":
            raise AssertionError(method)
        return {
            "tasks": [
                {
                    "id": "101",
                    "title": "Task 101",
                    "status": "2",
                    "deadline": "2026-03-14T15:00:00+03:00",
                    "ufCrmTask": ["D_123"],
                }
            ]
        }

    def list_method(self, method: str, params=None, *, limit=None):  # noqa: ANN001
        if method == "tasks.task.list":
            return [
                {
                    "id": "101",
                    "title": "Task 101",
                    "status": "2",
                    "deadline": "2026-03-14T15:00:00+03:00",
                    "ufCrmTask": ["D_123"],
                }
            ]
        if method != "crm.deal.list":
            raise AssertionError(method)
        return [
            {
                "ID": "500",
                "TITLE": "Сделка через app oauth",
                "ASSIGNED_BY_ID": "2818",
                "CATEGORY_ID": "10",
                "STAGE_ID": "C10:EXECUTING",
                "DATE_CREATE": "2026-03-13T10:00:00+03:00",
                "DATE_MODIFY": "2026-03-13T12:00:00+03:00",
                "LAST_ACTIVITY_TIME": "2026-03-13T12:00:00+03:00",
                "LAST_COMMUNICATION_TIME": "2026-03-13T12:00:00+03:00",
                "CLOSED": "N",
            }
        ]


class _BatchAppAuthStub(_AppAuthStub):
    def __init__(self) -> None:
        self.batch_calls: list[dict[str, object]] = []
        self.sequential_activity_calls = 0

    def call_payload(self, method: str, params=None, *, default=None):  # noqa: ANN001
        if method != "batch":
            raise AssertionError(method)
        self.batch_calls.append(params or {})
        return {
            "result": {
                "result": {
                    "deal_1001": [
                        {
                            "ID": "701",
                            "SUBJECT": "Созвон по alpha.ru",
                            "DEADLINE": "2026-03-14T10:00:00+03:00",
                            "START_TIME": "2026-03-14T10:00:00+03:00",
                            "COMPLETED": "N",
                            "TYPE_ID": "2",
                            "PROVIDER_ID": "VOXIMPLANT_CALL",
                            "PROVIDER_TYPE_ID": "CALL",
                        }
                    ],
                    "deal_1002": [],
                },
                "result_error": {},
            }
        }

    def list_method(self, method: str, params=None, *, limit=None):  # noqa: ANN001
        if method == "crm.activity.list":
            self.sequential_activity_calls += 1
            raise AssertionError("crm.activity.list fallback не должен вызываться при успешном batch")
        return super().list_method(method, params=params, limit=limit)


class BitrixSalesAdapterTests(unittest.TestCase):
    def test_tasks_bundle_falls_back_to_app_oauth(self) -> None:
        adapter = BitrixSalesAdapter(provider=_ProviderStub(), app_auth=_AppAuthStub())

        result = adapter.get_tasks_bundle(limit=5)

        self.assertTrue(result["available"])
        self.assertEqual(result["source"], "app_oauth:tasks.task.list")
        self.assertEqual(result["items"][0]["id"], "101")
        self.assertEqual(result["items"][0]["title"], "Task 101")

    def test_deals_prefer_app_oauth_for_sales_contour(self) -> None:
        adapter = BitrixSalesAdapter(provider=_ProviderStub(), app_auth=_AppAuthStub())

        deals = adapter.get_deals(limit=5, category_id=10)

        self.assertEqual(adapter.sales_read_mode(), "app_oauth")
        self.assertEqual(deals[0]["id"], "500")
        self.assertEqual(deals[0]["category_id"], "10")
        self.assertEqual(deals[0]["raw"]["CATEGORY_ID"], "10")

    def test_deal_next_steps_use_batch_for_app_oauth(self) -> None:
        app_auth = _BatchAppAuthStub()
        adapter = BitrixSalesAdapter(provider=_ProviderStub(), app_auth=app_auth)

        result = adapter.get_deal_next_steps(["1001", "1002"], limit_per_deal=10)

        self.assertEqual(len(app_auth.batch_calls), 1)
        self.assertEqual(app_auth.sequential_activity_calls, 0)
        self.assertIn("1001", result)
        self.assertNotIn("1002", result)
        self.assertEqual(result["1001"]["next_step_activity_id"], "701")
        self.assertEqual(result["1001"]["next_step_subject"], "Созвон по alpha.ru")


if __name__ == "__main__":
    unittest.main()
