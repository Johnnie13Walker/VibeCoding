from __future__ import annotations

import unittest
from unittest.mock import Mock, patch

from agents.larisa_ivanovna.agent import LarisaDependencies, LarisaIvanovnaAgent
from agents.larisa_ivanovna.config import DEFAULT_CONFIG
from agents.larisa_ivanovna.providers import (
    NullCalendarProvider,
    NullNewsProvider,
    NullSearchProvider,
    NullTasksProvider,
    NullTelegramProvider,
    NullWeatherProvider,
)
from agents.larisa_ivanovna.schemas.brief import DayBriefRequest
from cloudbot.orchestrator.router import select_workflow
from cloudbot.workflows import day_briefing


class LarisaAgentTests(unittest.TestCase):
    def _build_agent(self) -> LarisaIvanovnaAgent:
        return LarisaIvanovnaAgent(
            config=DEFAULT_CONFIG,
            dependencies=LarisaDependencies(
                calendar_provider=NullCalendarProvider(),
                tasks_provider=NullTasksProvider(),
                weather_provider=NullWeatherProvider(),
                news_provider=NullNewsProvider(),
                search_provider=NullSearchProvider(),
                telegram_provider=NullTelegramProvider(),
            ),
        )

    def test_registry_contains_expected_commands(self) -> None:
        agent = self._build_agent()

        for key in (
            "get_day_brief",
            "/today",
            "/brief",
            "/day",
            "/add-meeting",
            "/weather",
            "/search",
            "/plan-day",
        ):
            self.assertIn(key, agent.registry)

    def test_policy_blocks_sales_domain(self) -> None:
        agent = self._build_agent()

        decision = agent.policy.can_access("sales")

        self.assertFalse(decision.allowed)
        self.assertIn("не работает с доменом sales", decision.reason)

    def test_day_brief_command_returns_telegram_friendly_sections(self) -> None:
        agent = self._build_agent()

        result = agent.execute(
            "get_day_brief",
            DayBriefRequest(date_msk="22.03.2026", weekday_msk="воскресенье"),
        )

        text = result["text"]
        self.assertIn("Фокус дня:", text)
        self.assertIn("Встречи:", text)
        self.assertIn("Задачи:", text)
        self.assertIn("Ограничения:", text)


class LarisaWorkflowRoutingTests(unittest.TestCase):
    def test_router_maps_larisa_commands(self) -> None:
        self.assertEqual(select_workflow({"command": "/brief"}), "day_briefing")
        self.assertEqual(select_workflow({"command": "/weather"}), "larisa_weather")
        self.assertEqual(select_workflow({"command": "/search"}), "larisa_search")
        self.assertEqual(select_workflow({"command": "/plan-day"}), "larisa_plan_day")
        self.assertEqual(select_workflow({"command": "/add-meeting"}), "larisa_create_event")

    def test_day_briefing_workflow_delegates_to_larisa_agent(self) -> None:
        fake_agent = Mock()
        fake_agent.execute.return_value = {"text": "brief ok", "payload": {"kind": "brief"}}

        with patch("cloudbot.workflows.larisa_runtime.build_larisa_agent_from_env", return_value=fake_agent):
            result = day_briefing.run({"message": {"text": "/today", "command": "/today"}})

        self.assertTrue(result["ok"])
        self.assertEqual(result["workflow"], "day_briefing")
        self.assertEqual(result["agent_id"], "larisa_ivanovna")
        self.assertEqual(result["text"], "brief ok")
        fake_agent.execute.assert_called_once()


if __name__ == "__main__":
    unittest.main()
