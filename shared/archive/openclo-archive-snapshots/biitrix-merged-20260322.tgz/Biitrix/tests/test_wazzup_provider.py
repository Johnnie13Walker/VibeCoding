from __future__ import annotations

import json
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

from cloudbot.providers.wazzup_provider import WazzupProvider

MOSCOW_TZ = ZoneInfo("Europe/Moscow")


class _FakeResponse:
    def __init__(self, payload: object) -> None:
        self._payload = json.dumps(payload).encode("utf-8")

    def read(self) -> bytes:
        return self._payload

    def __enter__(self) -> "_FakeResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


class WazzupProviderTests(unittest.TestCase):
    def test_archive_status_reports_payloads_and_dialogs(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            state_dir = Path(tmp_dir)
            record = {
                "saved_at": "2026-03-13T10:49:00+03:00",
                "event": "wazzup",
                "payload": {
                    "messages": [
                        {
                            "messageId": "m1",
                            "chatId": "chat-1",
                            "authorId": "2806",
                            "authorName": "Дарья Исаева",
                            "isEcho": True,
                            "dateTime": "2026-03-12T07:10:00.001Z",
                            "text": "тест",
                        },
                        {
                            "messageId": "m2",
                            "chatId": "chat-2",
                            "isEcho": False,
                            "dateTime": "2026-03-12T07:11:00.001Z",
                            "text": "входящее",
                        },
                    ],
                },
            }
            (state_dir / "wazzup.20260313T104900000000.json").write_text(
                json.dumps(record, ensure_ascii=False),
                encoding="utf-8",
            )

            provider = WazzupProvider(state_dir=state_dir)
            result = provider.get_archive_status(now=datetime(2026, 3, 13, 9, 0, 0, tzinfo=MOSCOW_TZ))

            self.assertTrue(result["available"])
            self.assertEqual(result["payloads"], 1)
            self.assertEqual(result["messages"], 2)
            self.assertEqual(result["dialogs_yesterday"], 2)
            self.assertEqual(result["messages_yesterday"], 2)

    def test_yesterday_dialogs_by_manager_uses_archive_and_resolver(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            state_dir = Path(tmp_dir)
            record = {
                "saved_at": "2026-03-13T10:49:00+03:00",
                "event": "wazzup",
                "payload": {
                    "messages": [
                        {
                            "messageId": "m1",
                            "chatId": "chat-1",
                            "authorId": "2806",
                            "isEcho": True,
                            "dateTime": "2026-03-12T07:10:00.001Z",
                            "text": "тест",
                        },
                        {
                            "messageId": "m2",
                            "chatId": "chat-1",
                            "authorId": "2806",
                            "isEcho": True,
                            "dateTime": "2026-03-12T08:10:00.001Z",
                            "text": "тест 2",
                        },
                    ],
                },
            }
            (state_dir / "wazzup.20260313T104900000000.json").write_text(
                json.dumps(record, ensure_ascii=False),
                encoding="utf-8",
            )

            provider = WazzupProvider(state_dir=state_dir)
            result = provider.get_yesterday_dialogs_by_manager(
                snapshot={"responsibles": {}},
                now=datetime(2026, 3, 13, 9, 0, 0, tzinfo=MOSCOW_TZ),
                allowed_manager_ids={"2806"},
                resolve_manager_names=lambda manager_ids, existing_map: {
                    **existing_map,
                    **{manager_id: "Дарья Исаева" for manager_id in manager_ids},
                },
            )

            self.assertTrue(result["available"])
            self.assertEqual(result["dialogs"], 1)
            self.assertEqual(result["by_manager"][0]["manager_id"], "2806")
            self.assertEqual(result["by_manager"][0]["manager_name"], "Дарья Исаева")
            self.assertEqual(result["by_manager"][0]["messenger_dialogs"], 1)

    def test_dialogs_by_manager_for_window_uses_custom_period(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            state_dir = Path(tmp_dir)
            record = {
                "saved_at": "2026-03-21T18:31:00+03:00",
                "event": "wazzup",
                "payload": {
                    "messages": [
                        {
                            "messageId": "m1",
                            "chatId": "chat-1",
                            "authorId": "2806",
                            "isEcho": True,
                            "dateTime": "2026-03-17T07:10:00.001Z",
                            "text": "понедельник",
                        },
                        {
                            "messageId": "m2",
                            "chatId": "chat-2",
                            "authorId": "2806",
                            "isEcho": True,
                            "dateTime": "2026-03-20T09:10:00.001Z",
                            "text": "пятница",
                        },
                    ],
                },
            }
            (state_dir / "wazzup.20260321T183100000000.json").write_text(
                json.dumps(record, ensure_ascii=False),
                encoding="utf-8",
            )

            provider = WazzupProvider(state_dir=state_dir)
            result = provider.get_dialogs_by_manager_for_window(
                start=datetime(2026, 3, 17, 0, 0, tzinfo=MOSCOW_TZ),
                end=datetime(2026, 3, 21, 0, 0, tzinfo=MOSCOW_TZ),
                snapshot={"responsibles": {}},
                allowed_manager_ids={"2806"},
                resolve_manager_names=lambda manager_ids, existing_map: {
                    **existing_map,
                    **{manager_id: "Дарья Исаева" for manager_id in manager_ids},
                },
            )

            self.assertTrue(result["available"])
            self.assertEqual(result["dialogs"], 2)
            self.assertEqual(result["by_manager"][0]["manager_id"], "2806")
            self.assertEqual(result["by_manager"][0]["messenger_dialogs"], 2)
            self.assertIn("17.03 00:00", result["message"])

    def test_api_status_checks_channels_and_webhooks(self) -> None:
        calls: list[str] = []

        def _fake_urlopen(request, timeout=0):  # type: ignore[no-untyped-def]
            calls.append(str(request.full_url))
            if request.full_url.endswith("/v3/channels"):
                return _FakeResponse([{"channelId": "c1"}])
            if request.full_url.endswith("/v3/webhooks"):
                return _FakeResponse([{"uri": "https://api.larisabot.ru/bitrix/app/handler"}])
            raise AssertionError(f"Unexpected URL: {request.full_url}")

        provider = WazzupProvider(api_key="mask-me", base_url="https://api.wazzup24.com")
        with patch("cloudbot.providers.wazzup_provider.urlopen", side_effect=_fake_urlopen):
            result = provider.get_api_status()

        self.assertTrue(result["available"])
        self.assertEqual(result["source"], "wazzup_api")
        self.assertEqual(result["status"], "ok")
        self.assertEqual(len(result["checks"]), 2)
        self.assertEqual(
            calls,
            [
                "https://api.wazzup24.com/v3/channels",
                "https://api.wazzup24.com/v3/webhooks",
            ],
        )

    def test_history_source_status_prefers_archive_and_marks_api_as_unconfirmed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            state_dir = Path(tmp_dir)
            record = {
                "saved_at": "2026-03-13T10:49:00+03:00",
                "event": "wazzup",
                "payload": {
                    "messages": [
                        {
                            "messageId": "m1",
                            "chatId": "chat-1",
                            "authorId": "2806",
                            "isEcho": True,
                            "dateTime": "2026-03-12T07:10:00.001Z",
                            "text": "тест",
                        }
                    ],
                },
            }
            (state_dir / "wazzup.20260313T104900000000.json").write_text(
                json.dumps(record, ensure_ascii=False),
                encoding="utf-8",
            )

            provider = WazzupProvider(state_dir=state_dir)
            result = provider.get_history_source_status(now=datetime(2026, 3, 13, 9, 0, 0, tzinfo=MOSCOW_TZ))

            self.assertTrue(result["available"])
            self.assertEqual(result["mode"], "webhook_archive")
            self.assertFalse(result["api_history_supported"])
            self.assertIn("webhook archive", result["message"])
            self.assertIn("unanswered_counter", result["documented_api"])


if __name__ == "__main__":
    unittest.main()
