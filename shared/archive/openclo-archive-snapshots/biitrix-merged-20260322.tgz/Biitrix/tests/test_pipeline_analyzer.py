from __future__ import annotations

import unittest
from datetime import datetime
from zoneinfo import ZoneInfo

from agents.sales_agent.pipeline_analyzer import BRIEF_PREP_STAGE_ID, HOT_STAGE_STAGE_ID, analyze_pipeline


MOSCOW_TZ = ZoneInfo("Europe/Moscow")


class PipelineAnalyzerTests(unittest.TestCase):
    def test_uses_category_10_stage_map_dynamic_items_and_real_next_step(self) -> None:
        snapshot = {
            "source": "webhook",
            "portal_base_url": "https://belberrycrm.bitrix24.ru",
            "limitations": [],
            "responsibles": {
                "2818": {"name": "Иван", "last_name": "Халин"},
            },
            "companies": [],
            "contacts": [],
            "departments": [],
            "deal_stage_map": [
                {"STATUS_ID": "C10:EXECUTING", "NAME": "Подготовка КП"},
                {"STATUS_ID": HOT_STAGE_STAGE_ID, "NAME": "Подготовка договора"},
                {"STATUS_ID": BRIEF_PREP_STAGE_ID, "NAME": "Подготовка БРИФа"},
            ],
            "meeting_stage_map": [
                {"STATUS_ID": "DT1048_24:SUCCESS", "NAME": "Встреча проведена"},
            ],
            "brief_stage_map": [
                {"STATUS_ID": "DT1056_28:SUCCESS", "NAME": "Бриф принят производством"},
            ],
            "recent_deals": [
                {
                    "id": "1",
                    "title": "Сделка А",
                    "assigned_id": "2818",
                    "created_at": "2026-03-13T10:00:00+03:00",
                    "updated_at": "2026-03-13T12:00:00+03:00",
                    "stage_id": "C10:EXECUTING",
                    "semantic_id": "P",
                    "amount": "100000",
                    "next_step_at": "2026-03-14T15:00:00+03:00",
                    "next_step_subject": "Назначить встречу по защите КП",
                    "next_step_source": "crm.activity.list",
                },
                {
                    "id": "2",
                    "title": "Сделка Б",
                    "assigned_id": "2818",
                    "created_at": "2026-03-12T10:00:00+03:00",
                    "updated_at": "2026-03-13T12:30:00+03:00",
                    "stage_id": HOT_STAGE_STAGE_ID,
                    "semantic_id": "P",
                    "amount": "150000",
                },
                {
                    "id": "3",
                    "title": "Сделка В",
                    "assigned_id": "2818",
                    "created_at": "2026-03-10T10:00:00+03:00",
                    "updated_at": "2026-03-13T13:00:00+03:00",
                    "moved_at": "2026-03-13T13:00:00+03:00",
                    "stage_id": BRIEF_PREP_STAGE_ID,
                    "semantic_id": "P",
                    "amount": "90000",
                    "source_id": "SEO",
                }
            ],
            "active_deals": [
                {
                    "id": "1",
                    "title": "Сделка А",
                    "assigned_id": "2818",
                    "created_at": "2026-03-13T10:00:00+03:00",
                    "updated_at": "2026-03-13T12:00:00+03:00",
                    "stage_id": "C10:EXECUTING",
                    "semantic_id": "P",
                    "amount": "100000",
                    "next_step_at": "2026-03-14T15:00:00+03:00",
                    "next_step_subject": "Назначить встречу по защите КП",
                    "next_step_source": "crm.activity.list",
                },
                {
                    "id": "2",
                    "title": "Сделка Б",
                    "assigned_id": "2818",
                    "created_at": "2026-03-12T10:00:00+03:00",
                    "updated_at": "2026-03-13T12:30:00+03:00",
                    "stage_id": HOT_STAGE_STAGE_ID,
                    "semantic_id": "P",
                    "amount": "150000",
                },
                {
                    "id": "3",
                    "title": "Сделка В",
                    "assigned_id": "2818",
                    "created_at": "2026-03-10T10:00:00+03:00",
                    "updated_at": "2026-03-13T13:00:00+03:00",
                    "moved_at": "2026-03-13T13:00:00+03:00",
                    "stage_id": BRIEF_PREP_STAGE_ID,
                    "semantic_id": "P",
                    "amount": "90000",
                    "source_id": "SEO",
                }
            ],
            "conducted_meetings": [
                {
                    "id": "10",
                    "title": "Встреча 1",
                    "assigned_id": "2818",
                    "category_id": "24",
                    "stage_id": "DT1048_24:SUCCESS",
                    "moved_at": "2026-03-13T11:00:00+03:00",
                }
            ],
            "accepted_briefs": [
                {
                    "id": "20",
                    "title": "Бриф 1",
                    "assigned_id": "2818",
                    "category_id": "28",
                    "stage_id": "DT1056_28:SUCCESS",
                    "moved_at": "2026-03-13T12:00:00+03:00",
                }
            ],
            "next_step_source": "crm.activity.list",
        }

        result = analyze_pipeline(snapshot, now=datetime(2026, 3, 14, 9, 0, tzinfo=MOSCOW_TZ))

        deal = result["active_deals"][0]
        self.assertEqual(deal["stage_name"], "Подготовка КП")
        self.assertEqual(deal["next_step_subject"], "Назначить встречу по защите КП")
        self.assertEqual(result["metrics"]["conducted_meetings_yesterday"], 1)
        self.assertEqual(result["metrics"]["accepted_briefs_yesterday"], 1)
        self.assertEqual(result["metrics"]["hot_stage_deals"], 1)
        self.assertEqual(result["metrics"]["moving_deals_last_week"], 1)
        self.assertEqual(result["metrics"]["stagnant_deals_last_week"], 2)
        self.assertEqual(result["metrics"]["new_deals_yesterday"], 1)
        self.assertEqual(result["new_deals_yesterday"][0]["stage_name"], "Подготовка БРИФа")
        self.assertEqual(result["new_deal_sources_yesterday"][0]["source_name"], "SEO")
        self.assertEqual(result["hot_stage_deals"][0]["stage_name"], "Подготовка договора")
        self.assertEqual(result["conducted_meetings"][0]["stage_name"], "Встреча проведена")
        self.assertEqual(result["accepted_briefs"][0]["stage_name"], "Бриф принят производством")
        self.assertNotIn("proxy-эвристикой", " ".join(result["limitations"]))

    def test_collects_focus_tasks_with_multiple_deadline_changes(self) -> None:
        snapshot = {
            "source": "fixture",
            "portal_base_url": "https://belberrycrm.bitrix24.ru",
            "limitations": [],
            "responsibles": {
                "2818": {"name": "Иван", "last_name": "Халин"},
            },
            "companies": [],
            "contacts": [],
            "departments": [],
            "deal_stage_map": [
                {"STATUS_ID": "C10:EXECUTING", "NAME": "Подготовка КП"},
            ],
            "meeting_stage_map": [],
            "brief_stage_map": [],
            "recent_deals": [],
            "active_deals": [
                {
                    "id": "1",
                    "title": "vogerus.ru",
                    "assigned_id": "2818",
                    "created_at": "2026-03-01T10:00:00+03:00",
                    "updated_at": "2026-03-14T12:00:00+03:00",
                    "stage_id": "C10:EXECUTING",
                    "semantic_id": "P",
                    "amount": "100000",
                    "next_step_at": "2026-03-20T18:00:00+03:00",
                }
            ],
            "conducted_meetings": [],
            "accepted_briefs": [],
            "tasks": [
                {
                    "id": "801",
                    "title": "КП и повторный дожим",
                    "status": "2",
                    "deadline": "2026-03-12T11:00:00+03:00",
                    "crm_bindings": ["D_1"],
                    "deadlineChangeCount": "4",
                    "changedDate": "2026-03-18T19:00:00+03:00",
                },
                {
                    "id": "802",
                    "title": "Обычная задача",
                    "status": "2",
                    "deadline": "2026-03-18T11:00:00+03:00",
                    "crm_bindings": ["D_1"],
                    "deadlineChangeCount": "2",
                    "changedDate": "2026-03-18T19:00:00+03:00",
                },
            ],
            "task_status_map": {"5": "Завершена"},
            "next_step_source": "crm.activity.list",
        }

        result = analyze_pipeline(snapshot, now=datetime(2026, 3, 20, 9, 0, tzinfo=MOSCOW_TZ))

        focus_tasks = result["deadline_reschedule_focus_tasks"]
        self.assertEqual(result["metrics"]["overdue_deal_task_deals"], 1)
        self.assertEqual(result["metrics"]["overdue_deal_task_amount"], 100000)
        self.assertEqual(len(focus_tasks), 1)
        self.assertEqual(focus_tasks[0]["task_id"], "801")
        self.assertEqual(focus_tasks[0]["deadline_change_count"], 4)
        self.assertEqual(focus_tasks[0]["manager_name"], "Иван Халин")
        self.assertEqual(focus_tasks[0]["deal_title"], "vogerus.ru")
        self.assertEqual(focus_tasks[0]["days_overdue"], 7)
        self.assertFalse(result["active_deals"][0]["moved_in_last_week"])


if __name__ == "__main__":
    unittest.main()
