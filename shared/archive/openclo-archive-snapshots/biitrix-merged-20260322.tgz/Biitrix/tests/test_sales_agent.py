from __future__ import annotations

import json
import tempfile
import unittest
from datetime import date, datetime
from pathlib import Path
from unittest.mock import Mock, patch
from zoneinfo import ZoneInfo

from agents.sales_agent import sales_agent


MOSCOW_TZ = ZoneInfo("Europe/Moscow")


class _FakeResponse:
    def __init__(self, payload: dict[str, object]) -> None:
        self._payload = payload

    def __enter__(self) -> "_FakeResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        return False

    def read(self) -> bytes:
        return json.dumps(self._payload).encode("utf-8")


class SalesAgentTelegramTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.log_file = Path(self.temp_dir.name) / "sales_agent.log"
        self.log_patch = patch.object(sales_agent, "DEFAULT_SALES_LOG_FILE", self.log_file)
        self.log_patch.start()
        self.addCleanup(self.log_patch.stop)

    def _build_agent(self, **env_data: str) -> sales_agent.SalesAgent:
        return sales_agent.SalesAgent(
            provider=Mock(),
            now=datetime(2026, 3, 13, 12, 0, tzinfo=MOSCOW_TZ),
            env_data=env_data,
        )

    def test_mask_value(self) -> None:
        self.assertEqual(sales_agent._mask_value(""), "-")
        self.assertEqual(sales_agent._mask_value("1234"), "***")
        self.assertEqual(sales_agent._mask_value("12345678"), "12***78")
        self.assertEqual(sales_agent._mask_value("123456789"), "12***89")

    def test_send_to_telegram_dry_run_masks_chat_id(self) -> None:
        agent = self._build_agent(TELEGRAM_CHAT_ID="81234599", SALES_TELEGRAM_DRY_RUN="1")

        result = agent.send_to_telegram("test")

        self.assertEqual(result["status"], "dry_run")
        self.assertEqual(result["chat_id_masked"], "81***99")
        log_data = self.log_file.read_text(encoding="utf-8")
        self.assertIn('"chat_id": "81***99"', log_data)
        self.assertNotIn("81234599", log_data)

    def test_send_to_telegram_success_masks_chat_id(self) -> None:
        agent = self._build_agent(
            TELEGRAM_CHAT_ID="81234599",
            TELEGRAM_BOT_TOKEN="token",
        )

        with patch.object(sales_agent, "urlopen", return_value=_FakeResponse({"ok": True, "result": {"message_id": 1}})):
            result = agent.send_to_telegram("test")

        self.assertEqual(result["status"], "sent")
        self.assertEqual(result["chat_id_masked"], "81***99")
        log_data = self.log_file.read_text(encoding="utf-8")
        self.assertIn('"chat_id": "81***99"', log_data)
        self.assertNotIn("81234599", log_data)

    def test_send_to_telegram_accepts_explicit_chat_id(self) -> None:
        agent = self._build_agent(
            TELEGRAM_CHAT_ID="81234599",
            TELEGRAM_BOT_TOKEN="token",
        )

        with patch.object(sales_agent, "urlopen", return_value=_FakeResponse({"ok": True, "result": {"message_id": 1}})):
            result = agent.send_to_telegram("test", chat_id="70070055")

        self.assertEqual(result["status"], "sent")
        self.assertEqual(result["chat_id_masked"], "70***55")
        log_data = self.log_file.read_text(encoding="utf-8")
        self.assertIn('"chat_id": "70***55"', log_data)
        self.assertNotIn("70070055", log_data)

    def test_send_to_telegram_uses_sales_chat_fallback(self) -> None:
        agent = self._build_agent(
            SALES_TELEGRAM_CHAT_ID="-5144911139",
            TELEGRAM_BOT_TOKEN="token",
        )

        with patch.object(sales_agent, "urlopen", return_value=_FakeResponse({"ok": True, "result": {"message_id": 1}})):
            result = agent.send_to_telegram("test")

        self.assertEqual(result["status"], "sent")
        self.assertEqual(result["chat_id_masked"], "-5***39")
        log_data = self.log_file.read_text(encoding="utf-8")
        self.assertIn('"chat_id": "-5***39"', log_data)
        self.assertNotIn("-5144911139", log_data)

    def test_send_to_telegram_uses_weekly_sales_chat_as_fallback(self) -> None:
        agent = self._build_agent(
            SALES_WEEKLY_TELEGRAM_CHAT_ID="-5144911139",
            SALES_TELEGRAM_DRY_RUN="1",
        )

        result = agent.send_to_telegram("test", report_type="sales")

        self.assertEqual(result["status"], "dry_run")
        self.assertEqual(result["chat_id_masked"], "-5***39")

    def test_resolve_period_override_returns_full_day_window(self) -> None:
        result = sales_agent._resolve_period_override(
            {
                "SALES_REPORT_DATE_FROM": "2026-03-01",
                "SALES_REPORT_DATE_TO": "2026-03-15",
            }
        )

        self.assertIsNotNone(result)
        self.assertEqual(result["start_date"], date(2026, 3, 1))
        self.assertEqual(result["end_date"], date(2026, 3, 15))
        self.assertEqual(result["start"], datetime(2026, 3, 1, 0, 0, tzinfo=MOSCOW_TZ))
        self.assertEqual(result["end"], datetime(2026, 3, 16, 0, 0, tzinfo=MOSCOW_TZ))

    def test_resolve_period_override_requires_both_dates(self) -> None:
        with self.assertRaises(sales_agent.SalesAgentError):
            sales_agent._resolve_period_override({"SALES_REPORT_DATE_FROM": "2026-03-01"})

    def test_resolve_period_override_validates_order(self) -> None:
        with self.assertRaises(sales_agent.SalesAgentError):
            sales_agent._resolve_period_override(
                {
                    "SALES_REPORT_DATE_FROM": "2026-03-15",
                    "SALES_REPORT_DATE_TO": "2026-03-01",
                }
            )

    def test_weekly_payload_reuses_window_communications_summary(self) -> None:
        agent = self._build_agent()
        snapshot = {
            "source": "app_oauth",
            "active_deals": [],
            "recent_deals": [],
            "active_leads": [],
            "recent_leads": [],
            "conducted_meetings": [],
            "accepted_briefs": [],
            "tasks": [],
        }
        summary_current = {"department_filter": {"manager_ids": []}, "managers": [{"manager_id": "1"}]}
        summary_previous = {"department_filter": {"manager_ids": []}, "managers": []}

        with patch.object(sales_agent, "get_sales_snapshot", return_value=snapshot):
            with patch.object(sales_agent, "analyze_pipeline", return_value={"limitations": []}):
                with patch.object(sales_agent, "detect_risks", return_value={}):
                    with patch.object(
                        sales_agent,
                        "resolve_sales_team_filter",
                        return_value={"manager_ids": [], "manager_allowlist": {}, "warnings": []},
                    ):
                        with patch.object(
                            sales_agent,
                            "get_communications_summary_for_window",
                            side_effect=[summary_current, summary_previous],
                        ) as get_window_summary:
                            with patch.object(sales_agent, "get_yesterday_communications_summary") as get_yesterday:
                                payload = agent.build_report_payload(report_type="weekly")

        get_yesterday.assert_not_called()
        self.assertEqual(get_window_summary.call_count, 2)
        self.assertIs(payload["communications_summary"], summary_current)
        self.assertIs(payload["weekly_context"]["communications_summary"], summary_current)
        self.assertIs(payload["weekly_context"]["previous_communications_summary"], summary_previous)


if __name__ == "__main__":
    unittest.main()
