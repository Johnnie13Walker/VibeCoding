from __future__ import annotations

import unittest
from datetime import date, datetime
from zoneinfo import ZoneInfo

from agents.sales_agent.sales_formatter import (
    format_focus_sales_report,
    format_risks_report,
    format_sales_brief,
    format_weekly_review,
)


MOSCOW_TZ = ZoneInfo("Europe/Moscow")


class SalesFormatterTests(unittest.TestCase):
    def test_sales_brief_uses_single_working_funnel_block(self) -> None:
        analysis = {
            "now": datetime(2026, 3, 14, 9, 0, tzinfo=MOSCOW_TZ),
            "metrics": {
                "new_deals_yesterday": 3,
                "conducted_meetings_yesterday": 4,
                "accepted_briefs_yesterday": 2,
                "deals_in_work": 12,
                "moving_deals_last_week": 7,
                "stagnant_deals_last_week": 5,
                "pipeline_amount": 360000,
                "hot_stage_deals": 2,
                "hot_stage_amount": 120000,
                "deals_without_next_step": 5,
                "deals_without_next_step_amount": 140000,
                "stuck_deals": 6,
                "stale_communication_deals": 1,
                "stale_communication_amount": 70000,
                "overdue_deal_task_deals": 2,
                "overdue_deal_task_amount": 160000,
                "lost_deals_yesterday": 1,
                "lost_deals_yesterday_amount": 25000,
            },
            "stale_communication_deals": [
                {
                    "id": "d7",
                    "kind": "deal",
                    "title": "omega.ru",
                    "assigned_name": "Иван Халин",
                    "card_url": "https://example.com/d7",
                    "amount": 70000,
                    "stage_name": "Подготовка договора",
                    "communication_gap_days": 16,
                }
            ],
            "deals_without_next_step_items": [
                {
                    "id": "d10",
                    "kind": "deal",
                    "title": "atlas.ru",
                    "assigned_name": "Иван Халин",
                    "card_url": "https://example.com/d10",
                    "amount": 50000,
                    "stage_name": "Подготовка КП",
                    "missing_next_step": True,
                },
                {
                    "id": "d11",
                    "kind": "deal",
                    "title": "bravo.ru",
                    "assigned_name": "Елизавета Деговцова",
                    "card_url": "https://example.com/d11",
                    "amount": 30000,
                    "stage_name": "Подготовка договора",
                    "missing_next_step": True,
                },
                {
                    "id": "d12",
                    "kind": "deal",
                    "title": "cetus.ru",
                    "assigned_name": "Петр Дудин",
                    "card_url": "https://example.com/d12",
                    "amount": 25000,
                    "stage_name": "Догрев и переговоры",
                    "missing_next_step": True,
                },
                {
                    "id": "d13",
                    "kind": "deal",
                    "title": "delta.ru",
                    "assigned_name": "Анна Гудинова",
                    "card_url": "https://example.com/d13",
                    "amount": 20000,
                    "stage_name": "Подготовка БРИФа",
                    "missing_next_step": True,
                },
                {
                    "id": "d14",
                    "kind": "deal",
                    "title": "element.ru",
                    "assigned_name": "Илья Смирнов",
                    "card_url": "https://example.com/d14",
                    "amount": 15000,
                    "stage_name": "Подготовка КП",
                    "missing_next_step": True,
                },
            ],
            "conducted_meetings": [
                {
                    "kind": "meeting",
                    "title": "Тестовая встреча",
                    "assigned_name": "Иван Халин",
                    "card_url": "https://example.com/m1",
                    "moved_at": datetime(2026, 3, 13, 11, 0, tzinfo=MOSCOW_TZ),
                    "yesterday_moved": True,
                }
            ],
            "accepted_briefs": [
                {
                    "kind": "brief",
                    "title": "Тестовый бриф",
                    "assigned_name": "Елизавета Деговцова",
                    "card_url": "https://example.com/b1",
                    "moved_at": datetime(2026, 3, 13, 12, 0, tzinfo=MOSCOW_TZ),
                    "yesterday_moved": True,
                }
            ],
            "limitations": [],
        }
        risk_report = {
            "focus_deals": [],
            "alerts": [],
            "high_risk_deals": [],
            "lead_risks": [],
            "leader_attention": [],
            "totals": {"deal_risks": 3, "risk_amount": 90000},
        }
        communications_summary = {
            "managers": [
                {
                    "manager_name": "Иван Халин",
                    "employee_role": "sales",
                    "employee_role_label": "продажи",
                    "dials": 22,
                    "normal_calls": 5,
                    "connect_rate": 0.23,
                    "messenger_dialogs": 7,
                    "total_known": 29,
                },
                {
                    "manager_name": "Елизавета Деговцова",
                    "employee_role": "telemarketing",
                    "employee_role_label": "телемаркетинг",
                    "dials": 55,
                    "normal_calls": 9,
                    "connect_rate": 0.16,
                    "messenger_dialogs": 10,
                    "total_known": 65,
                },
                {
                    "manager_name": "Илья Смирнов",
                    "employee_role": "sales",
                    "employee_role_label": "продажи",
                    "dials": 0,
                    "normal_calls": 0,
                    "connect_rate": None,
                    "messenger_dialogs": 0,
                    "total_known": 0,
                },
            ],
            "thresholds": {"stale_communication_days": 14, "telemarketing_min_dials": 40},
        }

        text = format_sales_brief(analysis, risk_report, communications_summary=communications_summary)

        self.assertIn("Срез на 14.03 09:00 МСК", text)
        self.assertIn("📈 Воронка в работе", text)
        self.assertIn("• Активные сделки: 12 / <b>360 000 ₽</b>", text)
        self.assertIn("• С движением за последнюю неделю: 7", text)
        self.assertIn("• Без движения за последнюю неделю: 5", text)
        self.assertIn("• Этап договора: 2 / <b>120 000 ₽</b>", text)
        self.assertIn("• Под риском: 3 / <b>90 000 ₽</b>", text)
        self.assertIn("  - Без следующего шага: 5 / <b>140 000 ₽</b>", text)
        self.assertIn("  - Без коммуникации > 14 дн.: 1 / <b>70 000 ₽</b>", text)
        self.assertIn("  - С просроченными задачами: 2 / <b>160 000 ₽</b>", text)
        self.assertNotIn("📈 Состояние воронки на сейчас", text)
        self.assertNotIn("💰 Деньги", text)
        self.assertIn("🤝 Проведенные встречи", text)
        self.assertIn("📈 Принятые брифы", text)
        self.assertIn("🚨 Сделки без коммуникации > 14 дн.", text)
        self.assertIn("Всего: 1 / <b>70 000 ₽</b>", text)
        self.assertIn("omega.ru", text)
        self.assertIn("⚠️ Сделки без следующего шага", text)
        self.assertIn("Всего: 5 / <b>140 000 ₽</b>", text)
        self.assertIn("atlas.ru", text)
        self.assertIn("🎯 Фокус РОПа", text)
        self.assertIn("📌 Сделки под контролем", text)
        self.assertIn("👥 Команда и дисциплина", text)
        self.assertIn("➡️ Что сделать РОПу сегодня", text)
        self.assertIn("🗂 Просрочки по менеджерам: нет", text)
        self.assertIn("🧊 Сделки без следующего шага", text)
        self.assertNotIn("Горячая стадия — Подготовка договора", text)
        self.assertIn("📞 Коммуникации за предыдущий рабочий день", text)
        self.assertIn("Статус: 🔥 НОРМ | ⚠️ РИСК | ❌ СТОП", text)
        self.assertIn("<pre>Статус", text)
        self.assertIn("Менеджер", text)
        self.assertIn("Иван Халин", text)
        self.assertIn("Конв", text)
        self.assertIn("Чаты", text)
        self.assertIn("Встр", text)
        self.assertIn("Опер", text)
        self.assertIn("Продажи: встречи, дозвоны, чаты и наборы", text)
        self.assertIn("Телемаркетинг: наборы, дозвоны, конверсия и чаты", text)
        self.assertNotIn("🔥 <b>Иван Халин</b> —", text)
        self.assertRegex(text, r"Иван Халин\s+22\s+5\s+23%\s+7\s+1\s+6\.7")
        self.assertRegex(text, r"Елизавета Деговцова\s+55\s+9\s+16%\s+10\s+—\s+8\.6")
        self.assertRegex(text, r"Илья Смирнов\s+0\s+0\s+0%\s+0\s+0\s+1\.0")

    def test_sales_brief_shows_all_stale_deals_without_limit_and_sorted(self) -> None:
        analysis = {
            "now": datetime(2026, 3, 14, 9, 0, tzinfo=MOSCOW_TZ),
            "metrics": {
                "deals_in_work": 6,
                "pipeline_amount": 710000,
                "moving_deals_last_week": 2,
                "stagnant_deals_last_week": 4,
                "hot_stage_deals": 1,
                "hot_stage_amount": 120000,
                "deals_without_next_step": 0,
                "deals_without_next_step_amount": 0,
                "stale_communication_deals": 6,
                "stale_communication_amount": 710000,
                "overdue_deal_task_deals": 0,
                "overdue_deal_task_amount": 0,
            },
            "stale_communication_deals": [
                {
                    "id": "d1",
                    "kind": "deal",
                    "title": "beta.ru",
                    "assigned_name": "Менеджер 1",
                    "card_url": "https://example.com/d1",
                    "amount": 90000,
                    "stage_name": "Подготовка КП",
                    "communication_gap_days": 21,
                },
                {
                    "id": "d2",
                    "kind": "deal",
                    "title": "delta.ru",
                    "assigned_name": "Менеджер 2",
                    "card_url": "https://example.com/d2",
                    "amount": 110000,
                    "stage_name": "Подготовка договора",
                    "communication_gap_days": 35,
                },
                {
                    "id": "d3",
                    "kind": "deal",
                    "title": "zeta.ru",
                    "assigned_name": "Менеджер 3",
                    "card_url": "https://example.com/d3",
                    "amount": 80000,
                    "stage_name": "Согласование",
                    "communication_gap_days": 17,
                },
                {
                    "id": "d4",
                    "kind": "deal",
                    "title": "alpha.ru",
                    "assigned_name": "Менеджер 4",
                    "card_url": "https://example.com/d4",
                    "amount": 95000,
                    "stage_name": "Подготовка КП",
                    "communication_gap_days": 21,
                },
                {
                    "id": "d5",
                    "kind": "deal",
                    "title": "epsilon.ru",
                    "assigned_name": "Менеджер 5",
                    "card_url": "https://example.com/d5",
                    "amount": 210000,
                    "stage_name": "Договор",
                    "communication_gap_days": 28,
                },
                {
                    "id": "d6",
                    "kind": "deal",
                    "title": "gamma.ru",
                    "assigned_name": "Менеджер 6",
                    "card_url": "https://example.com/d6",
                    "amount": 125000,
                    "stage_name": "Подготовка договора",
                    "communication_gap_days": 35,
                },
            ],
            "conducted_meetings": [],
            "accepted_briefs": [],
            "limitations": [],
        }
        risk_report = {
            "focus_deals": [],
            "alerts": [],
            "high_risk_deals": [],
            "lead_risks": [],
            "leader_attention": [],
            "totals": {"deal_risks": 0, "risk_amount": 0},
        }

        text = format_sales_brief(
            analysis,
            risk_report,
            communications_summary={"thresholds": {"stale_communication_days": 14}},
        )

        self.assertIn("🚨 Сделки без коммуникации > 14 дн.", text)
        self.assertIn("Всего: 6 / <b>710 000 ₽</b>", text)
        self.assertIn("alpha.ru", text)
        self.assertIn("beta.ru", text)
        self.assertIn("gamma.ru", text)
        self.assertIn("delta.ru", text)
        self.assertIn("epsilon.ru", text)
        self.assertIn("zeta.ru", text)
        stale_block = text.split("🚨 Сделки без коммуникации > 14 дн.", 1)[1]
        self.assertLess(stale_block.find("gamma.ru"), stale_block.find("delta.ru"))
        self.assertLess(stale_block.find("delta.ru"), stale_block.find("epsilon.ru"))
        self.assertLess(stale_block.find("epsilon.ru"), stale_block.find("alpha.ru"))
        self.assertLess(stale_block.find("alpha.ru"), stale_block.find("beta.ru"))
        self.assertLess(stale_block.find("beta.ru"), stale_block.find("zeta.ru"))

    def test_sales_brief_shows_all_no_next_step_deals_without_limit_and_sorted(self) -> None:
        analysis = {
            "now": datetime(2026, 3, 14, 9, 0, tzinfo=MOSCOW_TZ),
            "metrics": {
                "deals_in_work": 6,
                "pipeline_amount": 775000,
                "moving_deals_last_week": 3,
                "stagnant_deals_last_week": 3,
                "hot_stage_deals": 1,
                "hot_stage_amount": 180000,
                "deals_without_next_step": 6,
                "deals_without_next_step_amount": 775000,
                "stale_communication_deals": 0,
                "stale_communication_amount": 0,
                "overdue_deal_task_deals": 0,
                "overdue_deal_task_amount": 0,
            },
            "stale_communication_deals": [],
            "deals_without_next_step_items": [
                {
                    "id": "n1",
                    "kind": "deal",
                    "title": "alpha.ru",
                    "assigned_name": "Менеджер 1",
                    "card_url": "https://example.com/n1",
                    "amount": 120000,
                    "stage_name": "Подготовка КП",
                    "late_stage": False,
                    "effective_probability": 35,
                    "missing_next_step": True,
                },
                {
                    "id": "n2",
                    "kind": "deal",
                    "title": "beta.ru",
                    "assigned_name": "Менеджер 2",
                    "card_url": "https://example.com/n2",
                    "amount": 250000,
                    "stage_name": "Подготовка договора",
                    "late_stage": True,
                    "effective_probability": 75,
                    "missing_next_step": True,
                },
                {
                    "id": "n3",
                    "kind": "deal",
                    "title": "gamma.ru",
                    "assigned_name": "Менеджер 3",
                    "card_url": "https://example.com/n3",
                    "amount": 250000,
                    "stage_name": "Подготовка КП",
                    "late_stage": False,
                    "effective_probability": 55,
                    "missing_next_step": True,
                },
                {
                    "id": "n4",
                    "kind": "deal",
                    "title": "delta.ru",
                    "assigned_name": "Менеджер 4",
                    "card_url": "https://example.com/n4",
                    "amount": 90000,
                    "stage_name": "Подготовка БРИФа",
                    "late_stage": False,
                    "effective_probability": 20,
                    "missing_next_step": True,
                },
                {
                    "id": "n5",
                    "kind": "deal",
                    "title": "epsilon.ru",
                    "assigned_name": "Менеджер 5",
                    "card_url": "https://example.com/n5",
                    "amount": 35000,
                    "stage_name": "Договор",
                    "late_stage": True,
                    "effective_probability": 65,
                    "missing_next_step": True,
                },
                {
                    "id": "n6",
                    "kind": "deal",
                    "title": "zeta.ru",
                    "assigned_name": "Менеджер 6",
                    "card_url": "https://example.com/n6",
                    "amount": 30000,
                    "stage_name": "Подготовка КП",
                    "late_stage": False,
                    "effective_probability": 25,
                    "missing_next_step": True,
                },
            ],
            "conducted_meetings": [],
            "accepted_briefs": [],
            "limitations": [],
        }
        risk_report = {
            "focus_deals": [],
            "alerts": [],
            "high_risk_deals": [],
            "lead_risks": [],
            "leader_attention": [],
            "totals": {"deal_risks": 0, "risk_amount": 0},
        }

        text = format_sales_brief(
            analysis,
            risk_report,
            communications_summary={"thresholds": {"stale_communication_days": 14}},
        )

        self.assertIn("⚠️ Сделки без следующего шага", text)
        self.assertIn("Всего: 6 / <b>775 000 ₽</b>", text)
        self.assertIn("alpha.ru", text)
        self.assertIn("beta.ru", text)
        self.assertIn("gamma.ru", text)
        self.assertIn("delta.ru", text)
        self.assertIn("epsilon.ru", text)
        self.assertIn("zeta.ru", text)
        self.assertIn("следующего шага нет", text)
        no_next_step_block = text.split("⚠️ Сделки без следующего шага", 1)[1]
        self.assertLess(no_next_step_block.find("beta.ru"), no_next_step_block.find("gamma.ru"))
        self.assertLess(no_next_step_block.find("gamma.ru"), no_next_step_block.find("alpha.ru"))
        self.assertLess(no_next_step_block.find("alpha.ru"), no_next_step_block.find("delta.ru"))
        self.assertLess(no_next_step_block.find("delta.ru"), no_next_step_block.find("epsilon.ru"))
        self.assertLess(no_next_step_block.find("epsilon.ru"), no_next_step_block.find("zeta.ru"))

    def test_sales_brief_shows_empty_stale_block_placeholder(self) -> None:
        analysis = {
            "now": datetime(2026, 3, 14, 9, 0, tzinfo=MOSCOW_TZ),
            "metrics": {
                "deals_in_work": 0,
                "pipeline_amount": 0,
                "moving_deals_last_week": 0,
                "stagnant_deals_last_week": 0,
                "hot_stage_deals": 0,
                "hot_stage_amount": 0,
                "deals_without_next_step": 0,
                "deals_without_next_step_amount": 0,
                "stale_communication_deals": 0,
                "stale_communication_amount": 0,
                "overdue_deal_task_deals": 0,
                "overdue_deal_task_amount": 0,
            },
            "stale_communication_deals": [],
            "deals_without_next_step_items": [],
            "conducted_meetings": [],
            "accepted_briefs": [],
            "limitations": [],
        }
        risk_report = {
            "focus_deals": [],
            "alerts": [],
            "high_risk_deals": [],
            "lead_risks": [],
            "leader_attention": [],
            "totals": {"deal_risks": 0, "risk_amount": 0},
        }

        text = format_sales_brief(
            analysis,
            risk_report,
            communications_summary={"thresholds": {"stale_communication_days": 14}},
        )

        self.assertIn("🚨 Сделки без коммуникации > 14 дн.", text)
        self.assertIn("Нет сделок без коммуникации более 14 дней", text)
        self.assertIn("⚠️ Сделки без следующего шага", text)
        self.assertIn("Нет сделок без следующего шага", text)

    def test_focus_report_shows_rescheduled_tasks_and_overdues_by_manager(self) -> None:
        analysis = {
            "metrics": {
                "deals_in_work": 10,
                "deals_without_next_step": 2,
                "deals_without_next_step_amount": 125000,
                "deals_without_next_step_late_stage": 1,
                "stuck_deals": 3,
                "stale_communication_deals": 1,
                "lost_deals_yesterday": 2,
                "lost_deals_yesterday_amount": 120000,
            },
            "deadline_reschedule_focus_tasks": [
                {
                    "task_id": "t1",
                    "manager_name": "Иван Халин",
                    "deal_id": "d2",
                    "deal_title": "vogerus.ru",
                    "deal_card_url": "https://example.com/d2",
                    "task_title": "КП и повторный дожим",
                    "deadline_change_count": 4,
                },
                {
                    "task_id": "t2",
                    "manager_name": "Петр Дудин",
                    "deal_id": "d7",
                    "deal_title": "flebolog-arm.ru",
                    "deal_card_url": "https://example.com/d7",
                    "task_title": "Согласовать дату встречи с клиентом по новому коммерческому предложению и финальному обсуждению",
                    "deadline_change_count": 3,
                },
            ],
            "deals_without_next_step_items": [
                {
                    "id": "d3",
                    "kind": "deal",
                    "title": "aeka.su",
                    "assigned_name": "Елизавета Деговцова",
                    "card_url": "https://example.com/d3",
                    "amount": 75000,
                    "stage_name": "Подготовка КП",
                    "inactive_days": 0,
                }
            ],
            "overdue_deal_tasks_by_manager": [
                {
                    "manager_name": "Елизавета Деговцова",
                    "count": 3,
                    "max_days_overdue": 0,
                    "deals": [
                        {
                            "deal_title": "pro.market",
                            "deal_card_url": "https://example.com/d4",
                        },
                        {
                            "deal_title": "medexpert.website",
                            "deal_card_url": "https://example.com/d6",
                        },
                    ],
                },
                {
                    "manager_name": "Иван Халин",
                    "count": 2,
                    "max_days_overdue": 1,
                    "deals": [
                        {
                            "deal_title": "starline.ru",
                            "deal_card_url": "https://example.com/d5",
                        }
                    ],
                },
            ],
            "stale_communication_deals": [
                {
                    "id": "d2",
                    "kind": "deal",
                    "title": "vogerus.ru",
                    "assigned_name": "Евгения Гордиенко",
                    "card_url": "https://example.com/d2",
                    "amount": 768570,
                    "stage_name": "Подготовка КП",
                    "communication_gap_days": 51,
                    "late_stage": True,
                    "missing_next_step": False,
                    "needs_leader": True,
                }
            ],
        }
        risk_report = {
            "deal_risks": [
                {
                    "entity_id": "d2",
                    "severity": 7,
                    "reasons": ["без коммуникации 51 дн."],
                }
            ],
            "high_risk_deals": [
                {
                    "id": "d2",
                    "kind": "deal",
                    "title": "vogerus.ru",
                    "assigned_name": "Евгения Гордиенко",
                    "card_url": "https://example.com/d2",
                    "amount": 768570,
                    "stage_name": "Подготовка КП",
                    "communication_gap_days": 51,
                    "late_stage": True,
                    "missing_next_step": False,
                    "needs_leader": True,
                }
            ],
            "leader_attention": [],
            "focus_deals": [],
        }
        communications_summary = {
            "manager_stats": [
                {
                    "manager_name": "Елизавета Деговцова",
                    "overdue_tasks_count": 3,
                    "missing_next_step_count": 5,
                    "stale_communication_count": 0,
                    "late_stage_stuck_count": 0,
                    "lost_deals_yesterday_count": 0,
                    "no_activity": False,
                    "low_connect": False,
                    "low_activity": False,
                    "total_known": 8,
                }
            ],
            "team_metrics": {
                "manager_count": 3,
                "managers_with_overdue_tasks": 2,
                "managers_with_low_communication": 1,
                "managers_with_no_activity": 0,
            },
            "thresholds": {
                "stale_communication_days": 14,
                "missing_next_step_limit": 3,
                "overdue_tasks_limit": 1,
                "lost_deals_limit": 2,
                "late_stage_stuck_limit": 2,
            },
        }

        text = format_focus_sales_report(
            analysis,
            risk_report,
            communications_summary=communications_summary,
        )

        self.assertIn("🎯 Фокус РОПа", text)
        self.assertIn("• Иван Халин — <a href=\"https://example.com/d2\">vogerus.ru</a> → КП и повторный дожим — 4 переноса", text)
        self.assertIn("Согласовать дату встречи с клиентом по новому коммерческому...", text)
        self.assertIn("📌 Сделки под контролем", text)
        self.assertIn("👥 Команда и дисциплина", text)
        self.assertIn("<b>Елизавета Деговцова</b> — 3 просрочки", text)
        self.assertIn("🗂 Просрочки по менеджерам", text)
        self.assertIn("• Елизавета Деговцова — 3", text)
        self.assertIn("макс просрочка: сегодня", text)
        self.assertIn("примеры: <a href=\"https://example.com/d4\">pro.market</a>, <a href=\"https://example.com/d6\">medexpert.website</a>", text)
        self.assertIn("• Иван Халин — 2", text)
        self.assertIn("макс просрочка: 1 дн.", text)
        self.assertIn("🧊 Сделки без следующего шага", text)
        self.assertIn("📊 Сигналы по отделу", text)
        self.assertIn("➡️ Что сделать РОПу сегодня", text)
        self.assertNotIn("🗂 Просроченные задачи по сделкам", text)
        self.assertNotIn("просроченных задач: 2", text)

    def test_risks_report_is_alias_to_focus_sales_with_empty_overdues(self) -> None:
        analysis = {
            "metrics": {
                "deals_in_work": 4,
                "deals_without_next_step": 1,
                "deals_without_next_step_amount": 75000,
                "deals_without_next_step_late_stage": 1,
                "stuck_deals": 1,
                "stale_communication_deals": 1,
                "lost_deals_yesterday": 0,
                "lost_deals_yesterday_amount": 0,
            },
            "deadline_reschedule_focus_tasks": [],
            "deals_without_next_step_items": [],
            "overdue_deal_tasks_by_manager": [],
            "stale_communication_deals": [],
        }
        risk_report = {
            "deal_risks": [],
            "high_risk_deals": [],
            "leader_attention": [],
            "focus_deals": [],
        }
        communications_summary = {
            "manager_stats": [],
            "team_metrics": {
                "manager_count": 0,
                "managers_with_overdue_tasks": 0,
                "managers_with_low_communication": 0,
                "managers_with_no_activity": 0,
            },
            "thresholds": {},
        }

        text = format_risks_report(
            analysis,
            risk_report,
            communications_summary=communications_summary,
        )

        self.assertIn("🎯 Фокус РОПа", text)
        self.assertIn("• Задач с переносом срока более 2 раз нет", text)
        self.assertIn("🗂 Просрочки по менеджерам: нет", text)
        self.assertIn("📌 Сделки под контролем", text)
        self.assertIn("📊 Сигналы по отделу", text)
        self.assertNotIn("Риски объединены с Фокусом РОПа", text)

    def test_weekly_review_uses_current_business_week_and_role_split(self) -> None:
        analysis = {
            "metrics": {
                "high_probability_deals": 3,
                "high_probability_amount": 550000,
                "deals_without_next_step": 2,
                "deals_without_next_step_amount": 210000,
                "stale_communication_deals": 1,
                "stale_communication_amount": 150000,
                "expected_forecast_amount": 730000,
            },
            "limitations": [],
            "deals": [
                {
                    "id": "d1",
                    "title": "alpha.ru",
                    "assigned_id": "10",
                    "assigned_name": "Иван Халин",
                    "card_url": "https://example.com/d1",
                    "amount": 120000,
                    "created_at": datetime(2026, 3, 17, 10, 0, tzinfo=MOSCOW_TZ),
                    "source_name": "SEO",
                },
                {
                    "id": "d2",
                    "title": "beta.ru",
                    "assigned_id": "11",
                    "assigned_name": "Петр Дудин",
                    "card_url": "https://example.com/d2",
                    "amount": 240000,
                    "created_at": datetime(2026, 3, 19, 12, 0, tzinfo=MOSCOW_TZ),
                    "source_name": "Реферал",
                },
            ],
            "active_deals": [
                {
                    "id": "d1",
                    "title": "alpha.ru",
                    "assigned_id": "10",
                    "assigned_name": "Иван Халин",
                    "card_url": "https://example.com/d1",
                    "amount": 120000,
                    "stage_name": "Подготовка КП",
                    "source_name": "SEO",
                    "inactive_days": 2,
                    "communication_gap_days": 2,
                    "missing_next_step": False,
                    "late_stage": False,
                    "high_probability": True,
                },
                {
                    "id": "d3",
                    "title": "gamma.ru",
                    "assigned_id": "11",
                    "assigned_name": "Петр Дудин",
                    "card_url": "https://example.com/d3",
                    "amount": 210000,
                    "stage_name": "Подготовка договора",
                    "source_name": "SEO",
                    "inactive_days": 8,
                    "communication_gap_days": 16,
                    "missing_next_step": True,
                    "late_stage": True,
                    "high_probability": True,
                },
            ],
            "closed_deals": [
                {
                    "id": "d4",
                    "title": "lost.ru",
                    "assigned_id": "11",
                    "assigned_name": "Петр Дудин",
                    "card_url": "https://example.com/d4",
                    "amount": 150000,
                    "moved_at": datetime(2026, 3, 20, 11, 0, tzinfo=MOSCOW_TZ),
                    "lost": True,
                    "source_name": "SEO",
                }
            ],
            "conducted_meetings": [
                {
                    "assigned_name": "Иван Халин",
                    "moved_at": datetime(2026, 3, 18, 14, 0, tzinfo=MOSCOW_TZ),
                }
            ],
            "deadline_reschedule_focus_tasks": [
                {
                    "deal_id": "d3",
                    "manager_id": "11",
                    "manager_name": "Петр Дудин",
                    "deal_title": "gamma.ru",
                    "deal_card_url": "https://example.com/d3",
                    "task_title": "Повторный дожим",
                    "deadline_change_count": 4,
                }
            ],
            "overdue_deal_tasks": [
                {
                    "deal_id": "d3",
                    "days_overdue": 3,
                }
            ],
            "deal_without_next_step_items": [],
            "deals_without_next_step_items": [
                {
                    "id": "d3",
                    "title": "gamma.ru",
                    "assigned_id": "11",
                    "assigned_name": "Петр Дудин",
                    "card_url": "https://example.com/d3",
                    "amount": 210000,
                    "stage_name": "Подготовка договора",
                    "inactive_days": 8,
                    "communication_gap_days": 16,
                    "missing_next_step": True,
                    "late_stage": True,
                }
            ],
            "stale_communication_deals": [
                {
                    "id": "d3",
                    "title": "gamma.ru",
                    "assigned_id": "11",
                    "assigned_name": "Петр Дудин",
                    "card_url": "https://example.com/d3",
                    "amount": 210000,
                    "stage_name": "Подготовка договора",
                    "inactive_days": 8,
                    "communication_gap_days": 16,
                    "missing_next_step": True,
                    "late_stage": True,
                }
            ],
        }
        risk_report = {
            "deal_risks": [
                {
                    "entity_id": "d3",
                    "severity": 8,
                }
            ],
            "high_risk_deals": [
                {
                    "id": "d3",
                    "title": "gamma.ru",
                    "assigned_id": "11",
                    "assigned_name": "Петр Дудин",
                    "card_url": "https://example.com/d3",
                    "amount": 210000,
                    "stage_name": "Подготовка договора",
                    "inactive_days": 8,
                    "communication_gap_days": 16,
                    "missing_next_step": True,
                    "late_stage": True,
                }
            ],
            "totals": {
                "deal_risks": 1,
                "risk_amount": 210000,
            },
        }
        weekly_context = {
            "start": datetime(2026, 3, 17, 0, 0, tzinfo=MOSCOW_TZ),
            "end": datetime(2026, 3, 21, 0, 0, tzinfo=MOSCOW_TZ),
            "start_date": date(2026, 3, 17),
            "end_date": date(2026, 3, 21),
            "communications_summary": {
                "manager_stats": [
                    {
                        "manager_id": "10",
                        "manager_name": "Иван Халин",
                        "employee_role": "sales",
                        "dials": 12,
                        "normal_calls": 4,
                        "messenger_dialogs": 5,
                        "connect_rate": 0.33,
                        "total_known": 17,
                        "missing_next_step_count": 0,
                        "stale_communication_count": 0,
                        "late_stage_stuck_count": 0,
                        "overdue_tasks_count": 0,
                    },
                    {
                        "manager_id": "11",
                        "manager_name": "Петр Дудин",
                        "employee_role": "sales",
                        "dials": 6,
                        "normal_calls": 1,
                        "messenger_dialogs": 1,
                        "connect_rate": 0.17,
                        "total_known": 7,
                        "missing_next_step_count": 2,
                        "stale_communication_count": 1,
                        "late_stage_stuck_count": 1,
                        "overdue_tasks_count": 1,
                    },
                    {
                        "manager_id": "20",
                        "manager_name": "Елизавета Деговцова",
                        "employee_role": "telemarketing",
                        "dials": 48,
                        "normal_calls": 7,
                        "messenger_dialogs": 6,
                        "connect_rate": 0.15,
                        "total_known": 54,
                        "missing_next_step_count": 0,
                        "stale_communication_count": 0,
                        "late_stage_stuck_count": 0,
                        "overdue_tasks_count": 0,
                    },
                ],
                "limitations": [],
            },
            "previous_communications_summary": {
                "manager_stats": [
                    {
                        "manager_id": "10",
                        "manager_name": "Иван Халин",
                        "total_known": 18,
                    },
                    {
                        "manager_id": "11",
                        "manager_name": "Петр Дудин",
                        "total_known": 16,
                    },
                    {
                        "manager_id": "20",
                        "manager_name": "Елизавета Деговцова",
                        "total_known": 60,
                    },
                ]
            },
        }

        text = format_weekly_review(
            analysis,
            risk_report,
            weekly_context=weekly_context,
            monthly_target=900000,
        )

        self.assertIn("🗓 Еженедельный отчёт Льва Петровича", text)
        self.assertIn("Период: 17.03–21.03", text)
        self.assertIn("1. Что произошло за неделю", text)
        self.assertIn("Высокая вероятность", text)
        self.assertIn("Без следующего шага", text)
        self.assertIn("Менеджеры по продажам", text)
        self.assertIn("Телемаркетинг", text)
        self.assertIn("5. Проблемные сделки недели", text)
        self.assertIn("роль: менеджер по продажам", text)
        self.assertIn("8. Что делать на следующей неделе", text)
        self.assertNotIn("High probability", text)
        self.assertNotIn("next step", text)
        self.assertNotIn("Weekly Pipeline Review", text)

    def test_period_review_uses_custom_title_and_headings(self) -> None:
        analysis = {
            "metrics": {
                "high_probability_deals": 1,
                "high_probability_amount": 120000,
                "deals_without_next_step": 1,
                "deals_without_next_step_amount": 80000,
                "stale_communication_deals": 0,
                "stale_communication_amount": 0,
                "expected_forecast_amount": 150000,
            },
            "limitations": [
                "Для прошедших периодов риск, люди и текущая воронка считаются по текущему состоянию открытых сделок; исторический снимок Bitrix на конец периода в этом отчёте не хранится."
            ],
            "deals": [
                {
                    "id": "d1",
                    "title": "alpha.ru",
                    "assigned_id": "10",
                    "assigned_name": "Иван Халин",
                    "card_url": "https://example.com/d1",
                    "amount": 120000,
                    "created_at": datetime(2026, 3, 1, 10, 0, tzinfo=MOSCOW_TZ),
                    "source_name": "SEO",
                }
            ],
            "active_deals": [],
            "closed_deals": [],
        }
        risk_report = {
            "deal_risks": [],
            "high_risk_deals": [],
            "totals": {"deal_risks": 0, "risk_amount": 0},
        }
        weekly_context = {
            "custom_period": True,
            "title": "📊 Отчёт Льва Петровича по периоду",
            "summary_heading": "1. Что произошло за период",
            "people_heading": "3. Люди за период",
            "problem_deals_heading": "5. Проблемные сделки периода",
            "start": datetime(2026, 3, 1, 0, 0, tzinfo=MOSCOW_TZ),
            "end": datetime(2026, 3, 16, 0, 0, tzinfo=MOSCOW_TZ),
            "start_date": date(2026, 3, 1),
            "end_date": date(2026, 3, 15),
            "communications_summary": {"manager_stats": [], "limitations": []},
            "previous_communications_summary": {"manager_stats": []},
        }

        text = format_weekly_review(analysis, risk_report, weekly_context=weekly_context)

        self.assertIn("📊 Отчёт Льва Петровича по периоду", text)
        self.assertIn("Период: 01.03–15.03", text)
        self.assertIn("1. Что произошло за период", text)
        self.assertIn("3. Люди за период", text)
        self.assertIn("5. Проблемные сделки периода", text)
        self.assertIn("8. Что делать дальше", text)


if __name__ == "__main__":
    unittest.main()
