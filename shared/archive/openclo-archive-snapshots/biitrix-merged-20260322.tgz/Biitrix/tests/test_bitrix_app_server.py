import contextlib
import importlib
import io
import json
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch


bitrix_app_server = importlib.import_module("cloudbot.providers.bitrix.bitrix_app_server")


class BitrixAppServerTests(unittest.TestCase):
    def test_empty_payload_is_detected_as_probe(self):
        self.assertFalse(bitrix_app_server._has_payload({}))
        self.assertFalse(bitrix_app_server._has_payload({"DOMAIN": "", "AUTH_ID": ""}))
        self.assertFalse(bitrix_app_server._has_payload({"items": ["", " "]}))
        self.assertTrue(bitrix_app_server._has_payload({"DOMAIN": "example.bitrix24.ru"}))

        log_output = bitrix_app_server._safe_log("install_probe", {})
        self.assertIn("bitrix_app_install_probe", log_output)
        self.assertIn("auth=-", log_output)

    def test_pick_helpers_support_real_bitrix_auth_brackets(self):
        payload = {
            "event": "ONAPPINSTALL",
            "auth[domain]": "belberrycrm.bitrix24.ru",
            "auth[member_id]": "member-123",
            "auth[status]": "L",
            "auth[access_token]": "access-token-123456",
            "auth[refresh_token]": "refresh-token-654321",
        }
        self.assertEqual(bitrix_app_server._pick_domain(payload), "belberrycrm.bitrix24.ru")
        self.assertEqual(bitrix_app_server._pick_member_id(payload), "member-123")
        self.assertEqual(bitrix_app_server._pick_status(payload), "L")
        self.assertEqual(bitrix_app_server._pick_access_token(payload), "access-token-123456")
        self.assertEqual(bitrix_app_server._pick_refresh_token(payload), "refresh-token-654321")
        self.assertEqual(bitrix_app_server._pick_payload_event(payload), "ONAPPINSTALL")

    def test_persist_writes_latest_and_archive(self):
        with TemporaryDirectory() as tmpdir:
            state_dir = Path(tmpdir)
            bitrix_app_server.STATE_DIR = Path(tmpdir)
            original_now_iso = bitrix_app_server._now_iso
            original_now_slug = bitrix_app_server._now_slug
            try:
                bitrix_app_server._now_iso = lambda: "2026-03-12T14:10:00+03:00"
                bitrix_app_server._now_slug = lambda: "20260312T141000123456"
                bitrix_app_server._persist_payload(
                    "install",
                    {
                        "event": "ONAPPINSTALL",
                        "DOMAIN": "example.bitrix24.ru",
                        "member_id": "test-member-001",
                        "AUTH_ID": "testauth1234567890",
                        "REFRESH_ID": "testrefresh0987654321",
                        "status": "L",
                    },
                    {"Content-Type": "application/x-www-form-urlencoded"},
                )
            finally:
                bitrix_app_server._now_iso = original_now_iso
                bitrix_app_server._now_slug = original_now_slug

            files = sorted(path.name for path in state_dir.glob("install*.json"))
            self.assertIn("install.latest.json", files)
            self.assertEqual(len(files), 2)
            self.assertIn("install.onappinstall.20260312T141000123456.json", files)

            record = json.loads((state_dir / "install.latest.json").read_text(encoding="utf-8"))
            self.assertTrue(record["summary"]["auth_present"])
            self.assertTrue(record["summary"]["refresh_present"])
            self.assertEqual(record["summary"]["domain"], "example.bitrix24.ru")
            self.assertEqual(record["summary"]["payload_event"], "ONAPPINSTALL")
            self.assertEqual(record["payload"]["AUTH_ID"], "testauth1234567890")
            self.assertEqual(record["headers"]["Content-Type"], "application/x-www-form-urlencoded")

    def test_persist_supports_real_bitrix_install_payload_shape(self):
        with TemporaryDirectory() as tmpdir:
            state_dir = Path(tmpdir)
            bitrix_app_server.STATE_DIR = Path(tmpdir)
            bitrix_app_server._persist_payload(
                "install",
                {
                    "event": "ONAPPINSTALL",
                    "auth[domain]": "belberrycrm.bitrix24.ru",
                    "auth[member_id]": "member-123",
                    "auth[status]": "L",
                    "auth[access_token]": "access-token-123456",
                    "auth[refresh_token]": "refresh-token-654321",
                },
                {"Content-Type": "application/x-www-form-urlencoded"},
            )

            record = json.loads((state_dir / "install.latest.json").read_text(encoding="utf-8"))
            self.assertEqual(record["summary"]["domain"], "belberrycrm.bitrix24.ru")
            self.assertEqual(record["summary"]["member_id"], "member-123")
            self.assertEqual(record["summary"]["status"], "L")
            self.assertEqual(record["summary"]["payload_event"], "ONAPPINSTALL")
            self.assertTrue(record["summary"]["auth_present"])
            self.assertTrue(record["summary"]["refresh_present"])

    def test_safe_log_masks_tokens(self):
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            print(
                bitrix_app_server._safe_log(
                    "install",
                    {
                        "event": "ONAPPINSTALL",
                        "DOMAIN": "example.bitrix24.ru",
                        "member_id": "test-member-001",
                        "AUTH_ID": "testauth1234567890",
                        "REFRESH_ID": "testrefresh0987654321",
                    },
                ),
                file=stderr,
            )

        log_output = stderr.getvalue()
        self.assertIn("bitrix_app_install ", log_output)
        self.assertIn("payload_event=ONAPPINSTALL", log_output)
        self.assertIn("test***7890", log_output)
        self.assertIn("test***4321", log_output)
        self.assertNotIn("testauth1234567890", log_output)

    def test_safe_log_masks_real_bitrix_auth_brackets(self):
        log_output = bitrix_app_server._safe_log(
            "install",
            {
                "event": "ONAPPINSTALL",
                "auth[domain]": "belberrycrm.bitrix24.ru",
                "auth[member_id]": "member-123",
                "auth[access_token]": "access-token-123456",
                "auth[refresh_token]": "refresh-token-654321",
            },
        )
        self.assertIn("domain=belberrycrm.bitrix24.ru", log_output)
        self.assertIn("member_id=member-123", log_output)
        self.assertIn("payload_event=ONAPPINSTALL", log_output)
        self.assertIn("acce***3456", log_output)
        self.assertIn("refr***4321", log_output)

    def test_detects_wazzup_payload(self):
        payload = {
            "source": "wazzup",
            "messages": [{"messageId": "m1"}],
            "statuses": [{"id": "s1"}],
        }
        self.assertTrue(bitrix_app_server._is_wazzup_payload(payload))
        summary = bitrix_app_server._wazzup_summary(payload)
        self.assertEqual(summary["messages_count"], 1)
        self.assertEqual(summary["statuses_count"], 1)
        self.assertFalse(summary["wazzup_test"])

    def test_persist_wazzup_payload_uses_wazzup_event_name(self):
        with TemporaryDirectory() as tmpdir:
            state_dir = Path(tmpdir)
            bitrix_app_server.STATE_DIR = state_dir
            original_now_iso = bitrix_app_server._now_iso
            original_now_slug = bitrix_app_server._now_slug
            try:
                bitrix_app_server._now_iso = lambda: "2026-03-13T10:15:00+03:00"
                bitrix_app_server._now_slug = lambda: "20260313T101500123456"
                bitrix_app_server._persist_payload(
                    "wazzup",
                    {
                        "source": "wazzup",
                        "messages": [{"messageId": "msg-1", "authorId": "2806"}],
                    },
                    {"Content-Type": "application/json"},
                )
            finally:
                bitrix_app_server._now_iso = original_now_iso
                bitrix_app_server._now_slug = original_now_slug

            self.assertTrue((state_dir / "wazzup.latest.json").exists())
            record = json.loads((state_dir / "wazzup.latest.json").read_text(encoding="utf-8"))
            self.assertEqual(record["summary"]["messages_count"], 1)
            self.assertEqual(record["summary"]["statuses_count"], 0)
            self.assertFalse(record["summary"]["wazzup_test"])

    def test_forward_wazzup_payload_posts_json_to_existing_webhook(self):
        class _Response:
            def read(self) -> bytes:
                return b"ok"

            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return False

        captured: dict[str, object] = {}
        original_url = bitrix_app_server.WAZZUP_FORWARD_URL
        bitrix_app_server.WAZZUP_FORWARD_URL = "https://example.invalid/webhook"
        try:
            with patch("cloudbot.providers.bitrix.bitrix_app_server.urlopen", return_value=_Response()) as mocked:
                status = bitrix_app_server._forward_wazzup_payload({"messages": [{"messageId": "m1"}]})
                request = mocked.call_args.args[0]
                captured["url"] = request.full_url
                captured["body"] = request.data.decode("utf-8")
        finally:
            bitrix_app_server.WAZZUP_FORWARD_URL = original_url

        self.assertEqual(status, "ok")
        self.assertEqual(captured["url"], "https://example.invalid/webhook")
        self.assertIn("\"messageId\": \"m1\"", str(captured["body"]))


if __name__ == "__main__":
    unittest.main()
