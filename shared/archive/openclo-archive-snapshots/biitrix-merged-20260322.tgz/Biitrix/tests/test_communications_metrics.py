from __future__ import annotations

import json
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

from agents.sales_agent import communications_metrics

MOSCOW_TZ = ZoneInfo("Europe/Moscow")


class CommunicationsMetricsTests(unittest.TestCase):
    def test_employee_role_from_departments_detects_sales_and_telemarketing(self) -> None:
        self.assertEqual(
            communications_metrics._employee_role_from_departments(["Группа продаж Belberry"]),
            ("sales", "продажи"),
        )
        self.assertEqual(
            communications_metrics._employee_role_from_departments(["Телемаркетинг"]),
            ("telemarketing", "телемаркетинг"),
        )

    def test_extract_operator_name_from_bbcode_message(self) -> None:
        value = communications_metrics._extract_operator_name_from_message(
            '[b]Дарья Исаева:[/b][br] Добрый день'
        )
        self.assertEqual(value, "Дарья Исаева")

    def test_openlines_event_archive_counts_messages_by_manager_name(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            state_dir = Path(tmp_dir)
            record = {
                "saved_at": "2026-03-12T10:15:00+03:00",
                "event": "handler",
                "payload": {
                    "event": "ONIMCONNECTORMESSAGEADD",
                    "data[0][message][text]": "[b]Дарья Исаева:[/b][br] Добрый день",
                    "data[0][im][chat_id]": "chat123",
                },
                "summary": {
                    "payload_event": "ONIMCONNECTORMESSAGEADD",
                },
            }
            (state_dir / "handler.onimconnectormessageadd.20260312T101500000000.json").write_text(
                json.dumps(record, ensure_ascii=False),
                encoding="utf-8",
            )

            snapshot = {
                "responsibles": {
                    "2806": {
                        "name": "Дарья",
                        "last_name": "Исаева",
                    }
                }
            }

            result = communications_metrics.get_yesterday_openlines_from_event_archive(
                {"BITRIX_APP_STATE_DIR": str(state_dir)},
                snapshot=snapshot,
                now=datetime(2026, 3, 13, 9, 0, 0, tzinfo=MOSCOW_TZ),
                allowed_manager_ids={"2806"},
            )

            self.assertTrue(result["available"])
            self.assertEqual(result["source"], "bitrix_app_events")
            self.assertEqual(result["items"], 1)
            self.assertEqual(result["by_manager"][0]["manager_id"], "2806")
            self.assertEqual(result["by_manager"][0]["openlines"], 1)

    def test_openlines_event_archive_reports_empty_window(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            result = communications_metrics.get_yesterday_openlines_from_event_archive(
                {"BITRIX_APP_STATE_DIR": tmp_dir},
                snapshot={},
                now=datetime(2026, 3, 13, 9, 0, 0, tzinfo=MOSCOW_TZ),
                allowed_manager_ids=set(),
            )

            self.assertFalse(result["available"])
            self.assertEqual(result["source"], "bitrix_app_events")
            self.assertIn("нет данных", result["message"])

    def test_wazzup_archive_counts_outgoing_manager_messages(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            state_dir = Path(tmp_dir)
            record = {
                "saved_at": "2026-03-13T10:20:00+03:00",
                "event": "wazzup",
                "payload": {
                    "source": "wazzup",
                    "messages": [
                        {
                            "messageId": "m1",
                            "chatId": "chat-1",
                            "authorId": "2806",
                            "authorName": "Дарья Исаева",
                            "isEcho": True,
                            "dateTime": "2026-03-12T10:10:00+03:00",
                            "text": "тест",
                        },
                        {
                            "messageId": "m2",
                            "chatId": "chat-1",
                            "isEcho": False,
                            "dateTime": "2026-03-12T10:11:00+03:00",
                            "text": "входящее",
                        },
                    ],
                },
                "summary": {
                    "messages_count": 2,
                },
            }
            (state_dir / "wazzup.20260313T102000000000.json").write_text(
                json.dumps(record, ensure_ascii=False),
                encoding="utf-8",
            )

            snapshot = {
                "responsibles": {
                    "2806": {
                        "name": "Дарья",
                        "last_name": "Исаева",
                    }
                }
            }

            result = communications_metrics.get_yesterday_wazzup_by_manager(
                {"BITRIX_APP_STATE_DIR": str(state_dir)},
                snapshot=snapshot,
                now=datetime(2026, 3, 13, 9, 0, 0, tzinfo=MOSCOW_TZ),
                allowed_manager_ids={"2806"},
            )

            self.assertTrue(result["available"])
            self.assertEqual(result["source"], "wazzup_webhooks")
            self.assertEqual(result["by_manager"][0]["manager_id"], "2806")
            self.assertEqual(result["by_manager"][0]["messenger_dialogs"], 1)

    def test_wazzup_archive_status_reports_payloads_and_dialogs(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            state_dir = Path(tmp_dir)
            record = {
                "saved_at": "2026-03-13T10:49:00+03:00",
                "event": "wazzup",
                "payload": {
                    "source": "wazzup",
                    "messages": [
                        {
                            "messageId": "m1",
                            "chatId": "chat-1",
                            "authorId": "2806",
                            "authorName": "Дарья Исаева",
                            "isEcho": True,
                            "dateTime": "2026-03-12T10:10:00+03:00",
                            "text": "тест",
                        },
                        {
                            "messageId": "m2",
                            "chatId": "chat-2",
                            "isEcho": False,
                            "dateTime": "2026-03-12T10:11:00+03:00",
                            "text": "входящее",
                        },
                    ],
                },
            }
            (state_dir / "wazzup.20260313T104900000000.json").write_text(
                json.dumps(record, ensure_ascii=False),
                encoding="utf-8",
            )

            result = communications_metrics.get_wazzup_archive_status(
                {"BITRIX_APP_STATE_DIR": str(state_dir)},
                now=datetime(2026, 3, 13, 9, 0, 0, tzinfo=MOSCOW_TZ),
            )

            self.assertTrue(result["available"])
            self.assertEqual(result["source"], "wazzup_webhooks")
            self.assertEqual(result["payloads"], 1)
            self.assertEqual(result["messages"], 2)
            self.assertEqual(result["dialogs_yesterday"], 2)
            self.assertEqual(result["messages_yesterday"], 2)

    def test_wazzup_archive_accepts_utc_z_suffix(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            state_dir = Path(tmp_dir)
            record = {
                "saved_at": "2026-03-13T10:49:00+03:00",
                "event": "wazzup",
                "payload": {
                    "messages": [
                        {
                            "messageId": "m1",
                            "chatId": "chat-1",
                            "authorId": "2806",
                            "authorName": "Дарья Исаева",
                            "isEcho": True,
                            "dateTime": "2026-03-12T07:10:00.001Z",
                            "text": "тест",
                        }
                    ],
                },
            }
            (state_dir / "wazzup.20260313T104900000000.json").write_text(
                json.dumps(record, ensure_ascii=False),
                encoding="utf-8",
            )

            snapshot = {
                "responsibles": {
                    "2806": {
                        "name": "Дарья",
                        "last_name": "Исаева",
                    }
                }
            }

            result = communications_metrics.get_yesterday_wazzup_by_manager(
                {"BITRIX_APP_STATE_DIR": str(state_dir)},
                snapshot=snapshot,
                now=datetime(2026, 3, 13, 9, 0, 0, tzinfo=MOSCOW_TZ),
                allowed_manager_ids={"2806"},
            )

            self.assertTrue(result["available"])
            self.assertEqual(result["dialogs"], 1)
            self.assertEqual(result["by_manager"][0]["messenger_dialogs"], 1)

    def test_summary_keeps_zero_activity_managers_from_allowlist(self) -> None:
        fake_department_filter = {
            "manager_ids": ["2806", "2818"],
            "manager_allowlist": {
                "2806": "Дарья Исаева",
                "2818": "Иван Халин",
            },
            "allowlist_count": 2,
            "warnings": [],
        }
        fake_calls = {
            "available": True,
            "by_manager": [
                {
                    "manager_id": "2806",
                    "manager_name": "Дарья Исаева",
                    "dials": 6,
                    "normal_calls": 0,
                }
            ],
        }
        fake_messengers = {
            "available": True,
            "by_manager": [],
        }
        with patch("agents.sales_agent.communications_metrics.BitrixSalesAdapter.from_env") as adapter_from_env:
            adapter_from_env.return_value = object()
            with patch("agents.sales_agent.communications_metrics.resolve_sales_team_filter") as resolve_filter:
                with patch(
                    "agents.sales_agent.communications_metrics.get_calls_by_manager_for_window",
                    return_value=fake_calls,
                ):
                    with patch(
                        "agents.sales_agent.communications_metrics.get_wazzup_by_manager_for_window",
                        return_value=fake_messengers,
                    ):
                        result = communications_metrics.get_communications_summary_for_window(
                            {},
                            snapshot={},
                            analysis={},
                            period_start=datetime(2026, 3, 12, 0, 0, 0, tzinfo=MOSCOW_TZ),
                            period_end=datetime(2026, 3, 13, 0, 0, 0, tzinfo=MOSCOW_TZ),
                            department_filter=fake_department_filter,
                        )
        resolve_filter.assert_not_called()

        manager_names = [str(item.get("manager_name") or "") for item in result["managers"]]
        self.assertEqual(manager_names, ["Дарья Исаева", "Иван Халин"])
        zero_row = next(item for item in result["managers"] if item["manager_name"] == "Иван Халин")
        self.assertEqual(int(zero_row["dials"]), 0)
        self.assertEqual(int(zero_row["normal_calls"]), 0)
        self.assertEqual(int(zero_row["messenger_dialogs"]), 0)


if __name__ == "__main__":
    unittest.main()
