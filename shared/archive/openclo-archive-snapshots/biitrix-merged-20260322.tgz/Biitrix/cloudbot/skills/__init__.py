"""Skills-слой Cloudbot."""
