"""Нормализация команд Telegram без бизнес-логики."""

from __future__ import annotations

from typing import Optional

COMMAND_ALIASES = {
    "/today": "/today",
    "/brief": "/brief",
    "/day": "/day",
    "/meetings": "/meetings",
    "/tasks": "/tasks",
    "/add-meeting": "/add-meeting",
    "/create-event": "/create-event",
    "/weather": "/weather",
    "/search": "/search",
    "/plan-day": "/plan-day",
    "/plan": "/plan",
    "/whoop": "/whoop",
    "/news": "/news",
    "/health": "/health",
    "/repair": "/repair",
    "/sales": "/sales",
    "/pipeline": "/pipeline",
    "/risks": "/risks",
    "/focus-sales": "/focus-sales",
    "/bitrixcheck": "/bitrixcheck",
    "сегодня": "/today",
    "бриф": "/brief",
    "день": "/day",
    "встречи": "/meetings",
    "задачи": "/tasks",
    "погода": "/weather",
    "поиск": "/search",
    "план": "/plan",
    "здоровье": "/whoop",
    "новости": "/news",
    "статус": "/health",
    "система": "/health",
    "health": "/health",
    "repair": "/repair",
    "почини": "/repair",
    "ремонт": "/repair",
    "продажи": "/sales",
    "воронка": "/pipeline",
    "риски": "/risks",
    "фокус": "/focus-sales",
    "focus-sales": "/focus-sales",
    "bitrixcheck": "/bitrixcheck",
    "битрикс": "/bitrixcheck",
}


def extract_command(text: str | None) -> Optional[str]:
    raw_text = str(text or "").strip().lower()
    if not raw_text:
        return None
    token = raw_text.split()[0]
    return COMMAND_ALIASES.get(token)
