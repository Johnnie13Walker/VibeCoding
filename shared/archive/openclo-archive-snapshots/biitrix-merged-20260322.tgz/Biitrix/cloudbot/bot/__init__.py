"""Telegram-слой Cloudbot."""
