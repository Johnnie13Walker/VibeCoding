"""Providers-слой Cloudbot."""
