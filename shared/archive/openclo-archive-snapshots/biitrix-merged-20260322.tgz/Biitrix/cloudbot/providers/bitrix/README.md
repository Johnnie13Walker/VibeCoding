# Provider: bitrix

Этот provider отвечает только за API слой bitrix.

- Никакой бизнес-логики workflow.
- Используется skills и orchestrator.
