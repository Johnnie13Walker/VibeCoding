"""Python adapter-слой для Bitrix providers."""

from .bitrix_sales_adapter import BitrixSalesAdapter

__all__ = ["BitrixSalesAdapter"]
