"""Wazzup provider: API-статус и чтение webhook archive."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import json
from pathlib import Path
from typing import Any, Callable, Mapping
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from cloudbot.business_day import MOSCOW_TZ, now_moscow, previous_business_day_window

DEFAULT_WAZZUP_BASE_URL = "https://api.wazzup24.com"

ManagerResolver = Callable[[list[str], dict[str, str]], dict[str, str]]


def _now_moscow(now: datetime | None = None) -> datetime:
    return now_moscow(now)


def _previous_business_day_window(now: datetime | None = None) -> tuple[datetime, datetime]:
    return previous_business_day_window(now)


def _window_label(start: datetime, end: datetime) -> str:
    return f"{start.astimezone(MOSCOW_TZ):%d.%m %H:%M}–{end.astimezone(MOSCOW_TZ):%d.%m %H:%M} МСК"


def _event_dt(item: Mapping[str, Any], *keys: str) -> datetime | None:
    for key in keys:
        value = item.get(key)
        raw = str(value or "").strip()
        if not raw:
            continue
        if raw.endswith("Z"):
            raw = raw[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(raw)
        except ValueError:
            continue
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=MOSCOW_TZ)
        return parsed.astimezone(MOSCOW_TZ)
    return None


def _wazzup_message_dt(item: Mapping[str, Any]) -> datetime | None:
    return _event_dt(item, "dateTime", "timestamp", "createdAt")


def _manager_name(user: Mapping[str, Any]) -> str:
    first_name = str(user.get("name") or "").strip()
    last_name = str(user.get("last_name") or "").strip()
    full_name = " ".join(part for part in (first_name, last_name) if part).strip()
    return full_name or str(user.get("full_name") or user.get("email") or "").strip()


def _manager_map(snapshot: Mapping[str, Any] | None) -> dict[str, str]:
    result: dict[str, str] = {}
    responsibles = (snapshot or {}).get("responsibles") or {}
    for user_id, user in responsibles.items():
        normalized_id = str(user_id or "").strip()
        if not normalized_id or not isinstance(user, Mapping):
            continue
        full_name = _manager_name(user)
        if full_name:
            result[normalized_id] = full_name
    return result


@dataclass
class WazzupProvider:
    api_key: str = ""
    base_url: str = DEFAULT_WAZZUP_BASE_URL
    state_dir: Path = Path("/opt/openclaw/state/bitrix_app")
    timeout: float = 10.0

    @classmethod
    def from_env(cls, env: Mapping[str, Any] | None = None) -> "WazzupProvider":
        env_data = {str(key): str(value) for key, value in (env or {}).items()}
        state_dir = Path(str(env_data.get("BITRIX_APP_STATE_DIR") or "/opt/openclaw/state/bitrix_app")).expanduser()
        return cls(
            api_key=str(env_data.get("WAZZUP_API_KEY") or "").strip(),
            base_url=str(env_data.get("WAZZUP_API_BASE_URL") or DEFAULT_WAZZUP_BASE_URL).strip().rstrip("/"),
            state_dir=state_dir,
        )

    def _request_json(self, path: str) -> Any:
        url = f"{self.base_url}{path}"
        request = Request(
            url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Accept": "application/json",
            },
        )
        with urlopen(request, timeout=self.timeout) as response:
            raw = response.read().decode("utf-8", errors="replace")
        if not raw.strip():
            return {}
        return json.loads(raw)

    def get_api_status(self) -> dict[str, Any]:
        if not self.api_key:
            return {
                "available": False,
                "source": "wazzup_api",
                "status": "not configured",
                "message": "Wazzup API key не задан",
                "checks": [],
            }

        checks: list[dict[str, Any]] = []
        for label, path in (("channels", "/v3/channels"), ("webhooks", "/v3/webhooks")):
            try:
                payload = self._request_json(path)
            except HTTPError as error:
                return {
                    "available": False,
                    "source": "wazzup_api",
                    "status": f"http_{error.code}",
                    "message": f"Wazzup API {label}: HTTP {error.code}",
                    "checks": checks,
                }
            except URLError as error:
                reason = str(error.reason or "network error")
                return {
                    "available": False,
                    "source": "wazzup_api",
                    "status": "network error",
                    "message": f"Wazzup API {label}: {reason}",
                    "checks": checks,
                }
            except (OSError, json.JSONDecodeError) as error:
                return {
                    "available": False,
                    "source": "wazzup_api",
                    "status": "error",
                    "message": f"Wazzup API {label}: {error}",
                    "checks": checks,
                }

            checks.append(
                {
                    "label": label,
                    "path": path,
                    "ok": True,
                    "items": len(payload) if isinstance(payload, list) else None,
                }
            )

        return {
            "available": True,
            "source": "wazzup_api",
            "status": "ok",
            "message": "OK (channels, webhooks)",
            "checks": checks,
        }

    def get_history_source_status(self, *, now: datetime | None = None) -> dict[str, Any]:
        archive = self.get_archive_status(now=now)
        if archive.get("available"):
            return {
                "available": True,
                "source": "wazzup_history",
                "mode": "webhook_archive",
                "api_history_supported": False,
                "message": (
                    "История диалогов считается из webhook archive; "
                    "документированный read-only endpoint dialogs/messages не подтвержден"
                ),
                "archive": archive,
                "documented_api": ["channels", "webhooks", "unanswered_counter"],
            }
        return {
            "available": False,
            "source": "wazzup_history",
            "mode": "webhook_archive",
            "api_history_supported": False,
            "message": (
                "Wazzup webhook archive не найден; документированный read-only endpoint dialogs/messages "
                "не подтвержден"
            ),
            "archive": archive,
            "documented_api": ["channels", "webhooks", "unanswered_counter"],
        }

    def iter_archive_records(self) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        for path in sorted(self.state_dir.glob("wazzup*.json")):
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(record, dict):
                records.append(record)
        return records

    def get_archive_status(self, *, now: datetime | None = None) -> dict[str, Any]:
        start, end = _previous_business_day_window(now)
        records = self.iter_archive_records()
        if not records:
            return {
                "available": False,
                "source": "wazzup_webhooks",
                "status": "not configured",
                "message": "Wazzup webhook archive не найден",
                "payloads": 0,
                "messages": 0,
                "dialogs_yesterday": 0,
                "messages_yesterday": 0,
                "latest_saved_at": None,
            }

        payloads = 0
        messages = 0
        latest_saved_at: datetime | None = None
        dialogs_yesterday: set[str] = set()
        messages_yesterday = 0

        for record in records:
            payload = record.get("payload")
            if not isinstance(payload, dict):
                continue
            items = payload.get("messages")
            if not isinstance(items, list):
                continue
            payloads += 1
            saved_at = _event_dt(record, "saved_at")
            if saved_at is not None and (latest_saved_at is None or saved_at > latest_saved_at):
                latest_saved_at = saved_at
            for item in items:
                if not isinstance(item, dict):
                    continue
                messages += 1
                occurred_at = _wazzup_message_dt(item)
                if occurred_at is None or not (start <= occurred_at < end):
                    continue
                messages_yesterday += 1
                chat_id = str(item.get("chatId") or item.get("chat_id") or "").strip()
                if chat_id:
                    dialogs_yesterday.add(chat_id)

        latest_saved_label = latest_saved_at.strftime("%d.%m %H:%M") if latest_saved_at else "-"
        return {
            "available": payloads > 0,
            "source": "wazzup_webhooks",
            "status": "ok" if payloads > 0 else "not configured",
            "message": (
                f"OK ({payloads} payloads; пред. раб. день dialogs={len(dialogs_yesterday)}, "
                f"messages={messages_yesterday}; latest={latest_saved_label})"
            ),
            "payloads": payloads,
            "messages": messages,
            "dialogs_yesterday": len(dialogs_yesterday),
            "messages_yesterday": messages_yesterday,
            "latest_saved_at": latest_saved_at.isoformat() if latest_saved_at else None,
        }

    def get_yesterday_dialogs_by_manager(
        self,
        *,
        snapshot: Mapping[str, Any] | None = None,
        now: datetime | None = None,
        allowed_manager_ids: set[str] | None = None,
        resolve_manager_names: ManagerResolver | None = None,
    ) -> dict[str, Any]:
        start, end = _previous_business_day_window(now)
        return self.get_dialogs_by_manager_for_window(
            start=start,
            end=end,
            snapshot=snapshot,
            allowed_manager_ids=allowed_manager_ids,
            resolve_manager_names=resolve_manager_names,
            empty_message="За предыдущий рабочий день в Wazzup нет исходящей коммуникации менеджеров",
        )

    def get_dialogs_by_manager_for_window(
        self,
        *,
        start: datetime,
        end: datetime,
        snapshot: Mapping[str, Any] | None = None,
        allowed_manager_ids: set[str] | None = None,
        resolve_manager_names: ManagerResolver | None = None,
        empty_message: str | None = None,
    ) -> dict[str, Any]:
        manager_names = _manager_map(snapshot)
        counts: dict[str, dict[str, Any]] = {}
        processed_messages = 0
        outgoing_messages = 0
        unique_dialogs: set[str] = set()
        records = self.iter_archive_records()

        if not records:
            return {
                "available": False,
                "source": "wazzup_webhooks",
                "status": "not configured",
                "message": "Wazzup webhook archive не найден",
                "by_manager": [],
                "items": 0,
                "dialogs": 0,
            }

        for record in records:
            payload = record.get("payload")
            if not isinstance(payload, dict):
                continue
            messages = payload.get("messages")
            if not isinstance(messages, list):
                continue
            for item in messages:
                if not isinstance(item, dict):
                    continue
                processed_messages += 1
                occurred_at = _wazzup_message_dt(item)
                if occurred_at is None or not (start <= occurred_at < end):
                    continue
                if not bool(item.get("isEcho")):
                    continue
                manager_id = str(item.get("authorId") or "").strip()
                if not manager_id:
                    continue
                if allowed_manager_ids is not None and manager_id not in allowed_manager_ids:
                    continue
                outgoing_messages += 1
                chat_id = str(item.get("chatId") or item.get("chat_id") or "").strip()
                row = counts.setdefault(
                    manager_id,
                    {
                        "manager_id": manager_id,
                        "manager_name": manager_names.get(manager_id, ""),
                        "messenger_dialogs": 0,
                        "dialog_ids": set(),
                    },
                )
                if chat_id:
                    row["dialog_ids"].add(chat_id)
                    unique_dialogs.add(chat_id)

        if outgoing_messages <= 0:
            return {
                "available": True,
                "source": "wazzup_webhooks",
                "status": "ok",
                "message": empty_message or f"В Wazzup нет исходящей коммуникации менеджеров за период {_window_label(start, end)}",
                "by_manager": [],
                "items": processed_messages,
                "dialogs": 0,
            }

        if resolve_manager_names is not None:
            manager_names = resolve_manager_names(list(counts.keys()), manager_names)

        for manager_id, item in counts.items():
            item["manager_name"] = manager_names.get(manager_id) or f"ID {manager_id}"
            item["messenger_dialogs"] = len(item.get("dialog_ids") or set())
            item.pop("dialog_ids", None)

        rows = sorted(
            counts.values(),
            key=lambda item: (int(item["messenger_dialogs"]), str(item.get("manager_name") or "")),
            reverse=True,
        )
        return {
            "available": True,
            "source": "wazzup_webhooks",
            "status": "ok",
            "message": f"Wazzup уникальные диалоги менеджеров: {len(unique_dialogs)} за период {_window_label(start, end)}",
            "by_manager": rows,
            "items": processed_messages,
            "dialogs": len(unique_dialogs),
        }
