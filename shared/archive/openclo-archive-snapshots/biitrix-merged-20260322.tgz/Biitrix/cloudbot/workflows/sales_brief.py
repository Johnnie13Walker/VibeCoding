"""Workflow Sales Copilot для /sales, /pipeline, /risks и /focus-sales."""

from __future__ import annotations

from typing import Any

from agents.sales_agent.sales_agent import SalesAgentError, build_sales_report_from_env


def _detect_report_type(context: dict[str, Any]) -> str:
    message = context.get("message") or {}
    command = str(message.get("command") or "").strip().lower()
    if command == "/pipeline":
        return "sales"
    if command == "/risks":
        return "risks"
    if command == "/focus-sales":
        return "focus"
    return str(context.get("report_type") or "sales").strip().lower() or "sales"


def run(context: dict[str, Any]) -> dict[str, Any]:
    report_type = _detect_report_type(context)
    try:
        result = build_sales_report_from_env(report_type=report_type)
    except SalesAgentError as error:
        return {
            "ok": False,
            "workflow": "sales_brief",
            "report_type": report_type,
            "text": f"Не удалось сформировать sales-отчет: {error}",
            "error": str(error),
        }
    except Exception as error:  # noqa: BLE001
        return {
            "ok": False,
            "workflow": "sales_brief",
            "report_type": report_type,
            "text": f"Критическая ошибка Sales Copilot: {error}",
            "error": str(error),
        }

    return {
        "ok": True,
        "workflow": "sales_brief",
        "report_type": report_type,
        "text": result["text"],
        "parse_mode": result.get("parse_mode") or "HTML",
        "analysis": result.get("analysis") or {},
        "risk_report": result.get("risk_report") or {},
    }
