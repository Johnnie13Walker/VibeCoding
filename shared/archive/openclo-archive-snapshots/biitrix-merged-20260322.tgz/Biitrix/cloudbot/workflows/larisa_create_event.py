"""Workflow создания встречи через контур Ларисы Ивановны."""

from __future__ import annotations

from typing import Any

from cloudbot.workflows.larisa_runtime import build_create_event_payload, run_larisa_command


def run(context: dict[str, Any]) -> dict[str, Any]:
    return run_larisa_command(
        "create_event",
        context=context,
        payload=build_create_event_payload(context),
    )
