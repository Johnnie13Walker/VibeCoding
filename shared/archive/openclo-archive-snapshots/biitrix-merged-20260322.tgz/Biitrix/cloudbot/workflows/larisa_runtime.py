"""Общие adapter-функции для workflow Ларисы Ивановны."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from agents.larisa_ivanovna import LarisaIvanovnaAgentError, build_larisa_agent_from_env
from agents.larisa_ivanovna.config import DEFAULT_CONFIG, WEEKDAY_LABELS
from agents.larisa_ivanovna.schemas.brief import DayBriefRequest
from agents.larisa_ivanovna.schemas.calendar import CreateCalendarEventInput
from cloudbot.business_day import now_moscow

WORKFLOW_BY_COMMAND = {
    "get_day_brief": "day_briefing",
    "create_event": "larisa_create_event",
    "get_weather": "larisa_weather",
    "get_news": "larisa_news",
    "search": "larisa_search",
    "plan_day": "larisa_plan_day",
}


def build_day_brief_request(now: datetime | None = None) -> DayBriefRequest:
    current = now_moscow(now)
    return DayBriefRequest(
        date_msk=current.strftime("%d.%m.%Y"),
        weekday_msk=WEEKDAY_LABELS[current.weekday()],
        news_topics=DEFAULT_CONFIG.default_news_topics,
    )


def extract_message_tail(context: dict[str, Any]) -> str:
    message = context.get("message") or {}
    text = str(message.get("text") or "").strip()
    if not text:
        return ""
    parts = text.split(maxsplit=1)
    return parts[1].strip() if len(parts) > 1 else ""


def build_create_event_payload(context: dict[str, Any]) -> CreateCalendarEventInput:
    message = context.get("message") or {}
    payload = message.get("payload") or {}
    return CreateCalendarEventInput(
        title=str(payload.get("title") or "").strip(),
        start_at_msk=str(payload.get("start_at_msk") or "").strip(),
        end_at_msk=str(payload.get("end_at_msk") or "").strip(),
        description=str(payload.get("description") or "").strip(),
        participants=tuple(str(item) for item in (payload.get("participants") or ())),
        location=str(payload.get("location") or "").strip(),
        join_url=str(payload.get("join_url") or "").strip(),
        timezone=DEFAULT_CONFIG.timezone,
    )


def run_larisa_command(
    command_name: str,
    *,
    context: dict[str, Any],
    payload: Any,
) -> dict[str, Any]:
    workflow_name = WORKFLOW_BY_COMMAND[command_name]
    try:
        agent = build_larisa_agent_from_env()
        result = agent.execute(command_name, payload, context=context)
    except LarisaIvanovnaAgentError as error:
        return {
            "ok": False,
            "workflow": workflow_name,
            "agent_id": DEFAULT_CONFIG.agent_id,
            "text": f"Не удалось выполнить команду Ларисы Ивановны: {error}",
            "error": str(error),
        }
    except Exception as error:  # noqa: BLE001
        return {
            "ok": False,
            "workflow": workflow_name,
            "agent_id": DEFAULT_CONFIG.agent_id,
            "text": f"Критическая ошибка контура Ларисы Ивановны: {error}",
            "error": str(error),
        }

    return {
        "ok": True,
        "workflow": workflow_name,
        "agent_id": DEFAULT_CONFIG.agent_id,
        "text": str(result.get("text") or ""),
        "payload": result.get("payload"),
    }
