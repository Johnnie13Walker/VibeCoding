"""Workflow поиска через контур Ларисы Ивановны."""

from __future__ import annotations

from typing import Any

from cloudbot.workflows.larisa_runtime import extract_message_tail, run_larisa_command


def run(context: dict[str, Any]) -> dict[str, Any]:
    query = extract_message_tail(context)
    if not query:
        return {
            "ok": False,
            "workflow": "larisa_search",
            "agent_id": "larisa_ivanovna",
            "text": "После команды /search нужен текст запроса.",
        }

    return run_larisa_command(
        "search",
        context=context,
        payload={"query": query},
    )
