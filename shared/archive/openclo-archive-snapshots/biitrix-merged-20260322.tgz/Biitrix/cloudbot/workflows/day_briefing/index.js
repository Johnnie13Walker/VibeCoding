export const workflow = {
  name: "day_briefing",
  async run(context) {
    return { ok: true, workflow: "day_briefing", context };
  }
};
