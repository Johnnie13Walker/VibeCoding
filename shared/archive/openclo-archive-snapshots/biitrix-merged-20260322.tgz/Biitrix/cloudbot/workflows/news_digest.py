"""Workflow новостного дайджеста."""

from __future__ import annotations

from typing import Any

from agents.news_agent.news_agent import NewsAgentError, build_news_digest_from_env


def run(context: dict[str, Any]) -> dict[str, Any]:
    try:
        digest = build_news_digest_from_env()
    except NewsAgentError as error:
        return {
            "ok": False,
            "workflow": "news_digest",
            "text": f"Не удалось сформировать новостной дайджест: {error}",
            "error": str(error),
        }
    except Exception as error:  # noqa: BLE001
        return {
            "ok": False,
            "workflow": "news_digest",
            "text": f"Критическая ошибка news_agent: {error}",
            "error": str(error),
        }

    return {
        "ok": True,
        "workflow": "news_digest",
        "text": digest["message"],
        "message_chunks": digest.get("message_chunks") or [],
        "total_selected": digest["total_selected"],
        "fetch_errors": digest["fetch_errors"],
    }
