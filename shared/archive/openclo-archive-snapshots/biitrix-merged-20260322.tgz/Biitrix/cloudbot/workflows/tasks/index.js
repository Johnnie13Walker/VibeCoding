export const workflow = {
  name: "tasks",
  async run(context) {
    return { ok: true, workflow: "tasks", context };
  }
};
