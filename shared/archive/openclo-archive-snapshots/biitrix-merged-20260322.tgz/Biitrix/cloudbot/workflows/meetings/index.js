export const workflow = {
  name: "meetings",
  async run(context) {
    return { ok: true, workflow: "meetings", context };
  }
};
