"""Workflow диагностики Bitrix integration."""

from __future__ import annotations

from typing import Any

from cloudbot.providers.wazzup_provider import WazzupProvider
from cloudbot.skills.bitrix_sales_data import get_sales_snapshot


def _status_label(snapshot: dict[str, Any]) -> str:
    access = snapshot.get("access_report") or []
    critical_keys = {"profile", "deals"}
    critical_failed = any(item.get("key") in critical_keys and not item.get("ok") for item in access)
    optional_failed = any(not item.get("ok") for item in access if item.get("key") not in critical_keys)
    if critical_failed:
        return "ERROR"
    if optional_failed:
        return "WARNING"
    return "OK"


def _format_report(snapshot: dict[str, Any]) -> str:
    available = list(snapshot.get("available") or [])
    unavailable = list(snapshot.get("unavailable") or [])
    status = _status_label(snapshot)
    unavailable_by_key = {str(item.get("key") or ""): item for item in unavailable}

    lines = [f"Bitrix connection: {status}", ""]
    if available:
        lines.append("Доступно:")
        lines.extend(f"- {label}" for label in available)
    else:
        lines.extend(["Доступно:", "- ничего"])

    lines.append("")
    lines.append("Недоступно:")
    if unavailable:
        for item in unavailable:
            detail = str(item.get("message") or item.get("status") or "error")
            lines.append(f"- {item.get('label')} — {detail}")
    else:
        lines.append("- нет")

    counts = snapshot.get("counts") or {}
    scope = snapshot.get("scope") or {}
    tasks_status = snapshot.get("tasks_status") or {}
    access_by_key = {str(item.get("key") or ""): item for item in snapshot.get("access_report") or []}
    telephony_status = access_by_key.get("telephony") or {}
    wazzup_status = snapshot.get("wazzup_status") or WazzupProvider.from_env().get_archive_status()
    wazzup_api_status = snapshot.get("wazzup_api_status") or WazzupProvider.from_env().get_api_status()
    wazzup_history_status = snapshot.get("wazzup_history_status") or WazzupProvider.from_env().get_history_source_status()
    lines.extend(
        [
            "",
            f"Сделки category {scope.get('deal_category_id', '-')}: {counts.get('deals', 0)}",
            f"Проведенные встречи type {scope.get('meeting_entity_type_id', '-')}: {counts.get('conducted_meetings', 0)}",
            f"Принятые брифы type {scope.get('brief_entity_type_id', '-')}: {counts.get('accepted_briefs', 0)}",
        ]
    )
    if telephony_status.get("ok"):
        lines.append(f"Телефония: {telephony_status.get('message') or 'OK'}")
    else:
        lines.append(
            "Телефония: blocked "
            f"({telephony_status.get('code') or telephony_status.get('status') or '-'})"
        )
    if wazzup_api_status.get("available"):
        lines.append(f"Wazzup API: {wazzup_api_status.get('message') or 'OK'}")
    else:
        lines.append(f"Wazzup API: {wazzup_api_status.get('message') or wazzup_api_status.get('status') or '-'}")
    lines.append(f"Wazzup история: {wazzup_history_status.get('message') or '-'}")
    if wazzup_status.get("available"):
        lines.append(f"Wazzup диалоги: {wazzup_status.get('message') or 'OK'}")
    else:
        lines.append(f"Wazzup диалоги: {wazzup_status.get('message') or wazzup_status.get('status') or '-'}")
    if tasks_status.get("available"):
        lines.append(f"Задачи: {counts.get('tasks', 0)} [{tasks_status.get('source')}]")
    else:
        webhook_error = ((tasks_status.get("error") or {}).get("webhook") or {})
        app_error = ((tasks_status.get("error") or {}).get("app_oauth") or {})
        lines.append(
            "Задачи: blocked "
            f"(webhook={webhook_error.get('code') or webhook_error.get('status') or '-'}, "
            f"app={app_error.get('code') or app_error.get('status') or '-'})"
        )
    return "\n".join(lines)


def run(context: dict[str, Any]) -> dict[str, Any]:
    snapshot = get_sales_snapshot()
    provider = WazzupProvider.from_env(context.get("env"))
    snapshot["wazzup_status"] = provider.get_archive_status()
    snapshot["wazzup_api_status"] = provider.get_api_status()
    snapshot["wazzup_history_status"] = provider.get_history_source_status()
    text = _format_report(snapshot)
    return {
        "ok": True,
        "workflow": "bitrix_check",
        "text": text,
        "snapshot": snapshot,
    }
