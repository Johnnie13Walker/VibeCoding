"""Утилиты рабочих дней и недель для Europe/Moscow."""

from __future__ import annotations

from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

MOSCOW_TZ = ZoneInfo("Europe/Moscow")


def now_moscow(now: datetime | None = None) -> datetime:
    if now is None:
        return datetime.now(MOSCOW_TZ)
    if now.tzinfo is None:
        return now.replace(tzinfo=MOSCOW_TZ)
    return now.astimezone(MOSCOW_TZ)


def previous_business_day(value: date | datetime) -> date:
    current_date = value.date() if isinstance(value, datetime) else value
    candidate = current_date - timedelta(days=1)
    while candidate.weekday() >= 5:
        candidate -= timedelta(days=1)
    return candidate


def current_business_week(value: date | datetime) -> tuple[date, date]:
    current_date = value.date() if isinstance(value, datetime) else value
    start = current_date - timedelta(days=current_date.weekday())
    end = start + timedelta(days=4)
    return (start, end)


def previous_business_week(value: date | datetime) -> tuple[date, date]:
    start, end = current_business_week(value)
    return (start - timedelta(days=7), end - timedelta(days=7))


def previous_business_day_window(now: datetime | None = None) -> tuple[datetime, datetime]:
    current = now_moscow(now)
    business_date = previous_business_day(current)
    start = datetime(business_date.year, business_date.month, business_date.day, tzinfo=MOSCOW_TZ)
    end = start + timedelta(days=1)
    return (start, end)


def current_business_week_window(now: datetime | None = None) -> tuple[datetime, datetime]:
    current = now_moscow(now)
    start_date, end_date = current_business_week(current)
    start = datetime(start_date.year, start_date.month, start_date.day, tzinfo=MOSCOW_TZ)
    end = datetime(end_date.year, end_date.month, end_date.day, tzinfo=MOSCOW_TZ) + timedelta(days=1)
    return (start, end)


def previous_business_week_window(now: datetime | None = None) -> tuple[datetime, datetime]:
    current = now_moscow(now)
    start_date, end_date = previous_business_week(current)
    start = datetime(start_date.year, start_date.month, start_date.day, tzinfo=MOSCOW_TZ)
    end = datetime(end_date.year, end_date.month, end_date.day, tzinfo=MOSCOW_TZ) + timedelta(days=1)
    return (start, end)


def report_day_flags(value: datetime | None, now: datetime) -> tuple[bool, bool]:
    current = now_moscow(now)
    if value is None:
        return (False, False)
    value_date = now_moscow(value).date()
    return (value_date == current.date(), value_date == previous_business_day(current))
