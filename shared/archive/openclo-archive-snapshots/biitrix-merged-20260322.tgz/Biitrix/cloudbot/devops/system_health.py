"""Системный health-check Cloudbot для команды /health."""

from __future__ import annotations

import os
from typing import Any, Mapping
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from agents.news_agent.news_agent import NewsAgent, NewsAgentError
from agents.news_agent.news_fetcher import DEFAULT_RSS_SOURCES, RSSNewsFetcher
from agents.news_agent.runtime_support import append_news_log
from cloudbot.providers.bitrix.bitrix_sales_adapter import BitrixSalesAdapter

DEFAULT_TIMEOUT_SEC = 8
HEALTH_USER_AGENT = "CloudbotSystemHealth/1.0 (+https://cloudbot.local)"
MOCK_MODE = "mock"


def _env_dict(env: Mapping[str, str] | None = None) -> dict[str, str]:
    if env is None:
        return dict(os.environ)
    return {str(key): str(value) for key, value in env.items()}


def _mock_health_payload() -> dict[str, Any]:
    checks = {
        "internet": {"ok": True, "status": "OK"},
        "telegram_api": {"ok": True, "status": "OK"},
        "openai_api": {"ok": True, "status": "OK"},
        "bitrix_api": {"ok": True, "status": "OK", "reason": ""},
        "rss_sources": {"ok": True, "status": "OK", "warnings": []},
        "news_agent": {"ok": True, "status": "OK", "total_selected": 3},
    }
    return {
        "ok": True,
        "checks": checks,
        "warnings": [],
        "text": format_system_health_report(checks=checks, warnings=[]),
    }


def _probe_http_endpoint(
    url: str,
    *,
    timeout_sec: int = DEFAULT_TIMEOUT_SEC,
    headers: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    request = Request(
        str(url).strip(),
        headers={
            "User-Agent": HEALTH_USER_AGENT,
            **dict(headers or {}),
        },
    )

    try:
        with urlopen(request, timeout=timeout_sec) as response:  # noqa: S310
            return {
                "ok": True,
                "status": "OK",
                "http_status": getattr(response, "status", 200),
            }
    except HTTPError as error:
        if int(error.code) < 500:
            return {
                "ok": True,
                "status": "OK",
                "http_status": int(error.code),
            }
        return {
            "ok": False,
            "status": "FAIL",
            "http_status": int(error.code),
            "error": str(error),
        }
    except URLError as error:
        return {"ok": False, "status": "FAIL", "error": str(error.reason or error)}
    except Exception as error:  # noqa: BLE001
        return {"ok": False, "status": "FAIL", "error": str(error)}


def _check_internet() -> dict[str, Any]:
    return _probe_http_endpoint("https://example.com")


def _check_telegram_api(env: Mapping[str, str]) -> dict[str, Any]:
    api_base = str(env.get("TELEGRAM_API_BASE_URL") or "https://api.telegram.org").strip()
    return _probe_http_endpoint(api_base)


def _check_openai_api(env: Mapping[str, str]) -> dict[str, Any]:
    api_base = str(env.get("OPENAI_API_BASE_URL") or "https://api.openai.com/v1/models").strip()
    headers: dict[str, str] = {}
    api_key = str(env.get("OPENAI_API_KEY") or "").strip()
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    return _probe_http_endpoint(api_base, headers=headers)


def _check_bitrix_api(env: Mapping[str, str]) -> dict[str, Any]:
    adapter = BitrixSalesAdapter.from_env(env)
    if not adapter.is_configured():
        return {
            "ok": False,
            "status": "WARNING",
            "reason": "BITRIX_WEBHOOK_URL не задан",
        }

    access = {item["key"]: item for item in adapter.check_access()}
    profile = access.get("profile") or {}
    deals = access.get("deals") or {}

    if profile.get("ok") and deals.get("ok"):
        return {
            "ok": True,
            "status": "OK",
            "reason": "",
        }

    failed = profile if not profile.get("ok") else deals
    return {
        "ok": False,
        "status": "ERROR",
        "reason": str(failed.get("message") or failed.get("status") or "Bitrix check failed"),
    }


def _check_rss_sources(env: Mapping[str, str]) -> dict[str, Any]:
    health_env = dict(env)
    health_env["NEWS_CACHE_ENABLED"] = "0"
    health_env["NEWS_RSS_TIMEOUT_SEC"] = str(env.get("NEWS_HEALTH_RSS_TIMEOUT_SEC") or "4")
    fetcher = RSSNewsFetcher.from_env(health_env)

    warnings: list[str] = []
    checked = 0
    ok_count = 0
    for category, urls in DEFAULT_RSS_SOURCES.items():
        for source_url in urls:
            checked += 1
            try:
                payload = fetcher.fetch_source(source_url)
                if str(payload).strip():
                    ok_count += 1
            except Exception as error:  # noqa: BLE001
                warnings.append(f"{category}: {source_url} -> {error}")

    if checked == 0:
        return {
            "ok": False,
            "status": "FAIL",
            "warnings": ["RSS источники не настроены"],
            "checked_sources": 0,
            "ok_sources": 0,
        }

    if warnings and ok_count > 0:
        return {
            "ok": True,
            "status": "WARNING",
            "warnings": warnings,
            "checked_sources": checked,
            "ok_sources": ok_count,
        }

    return {
        "ok": ok_count == checked,
        "status": "OK" if ok_count == checked else "FAIL",
        "warnings": warnings,
        "checked_sources": checked,
        "ok_sources": ok_count,
    }


def _check_news_agent(env: Mapping[str, str]) -> dict[str, Any]:
    health_env = dict(env)
    health_env["NEWS_FETCH_ARTICLE_TEXT"] = "0"
    try:
        agent = NewsAgent.from_env(health_env, per_category_limit=1, translation_mode="mock")
        result = agent.build_digest()
    except NewsAgentError as error:
        return {"ok": False, "status": "FAIL", "error": str(error)}
    except Exception as error:  # noqa: BLE001
        return {"ok": False, "status": "FAIL", "error": str(error)}

    return {
        "ok": True,
        "status": "OK",
        "total_selected": int(result.get("total_selected") or 0),
        "cache_hit": bool(result.get("cache_hit")),
    }


def format_system_health_report(
    *,
    checks: Mapping[str, Mapping[str, Any]],
    warnings: list[str],
) -> str:
    lines = [
        "SYSTEM STATUS",
        "",
        f"Internet: {checks['internet']['status']}",
        f"Telegram API: {checks['telegram_api']['status']}",
        f"OpenAI API: {checks['openai_api']['status']}",
        f"Bitrix API: {checks['bitrix_api']['status']}",
        f"RSS sources: {checks['rss_sources']['status']}",
        f"News agent: {checks['news_agent']['status']}",
    ]

    if warnings:
        lines.append("")
        lines.append("Warnings:")
        for warning in warnings:
            lines.append(f"- {warning}")

    return "\n".join(lines)


def run_system_health(env: Mapping[str, str] | None = None) -> dict[str, Any]:
    env_data = _env_dict(env)
    if str(env_data.get("SYSTEM_HEALTH_MODE") or "").strip().lower() == MOCK_MODE:
        return _mock_health_payload()

    checks = {
        "internet": _check_internet(),
        "telegram_api": _check_telegram_api(env_data),
        "openai_api": _check_openai_api(env_data),
        "bitrix_api": _check_bitrix_api(env_data),
        "rss_sources": _check_rss_sources(env_data),
        "news_agent": _check_news_agent(env_data),
    }
    warnings = list(checks["rss_sources"].get("warnings") or [])
    if checks["bitrix_api"].get("reason"):
        warnings.append(f"Bitrix API: {checks['bitrix_api']['reason']}")
    ok = (
        bool(checks["internet"].get("ok"))
        and bool(checks["telegram_api"].get("ok"))
        and bool(checks["openai_api"].get("ok"))
        and bool(checks["bitrix_api"].get("ok"))
        and bool(checks["rss_sources"].get("ok"))
        and bool(checks["news_agent"].get("ok"))
    )

    append_news_log(
        "system_health",
        ok=ok,
        checks={name: payload.get("status") for name, payload in checks.items()},
        warnings=warnings,
    )

    return {
        "ok": ok,
        "checks": checks,
        "warnings": warnings,
        "text": format_system_health_report(checks=checks, warnings=warnings),
    }
