"""Роутер команд/интентов в workflow."""

from __future__ import annotations

from typing import Any

COMMAND_ROUTES = {
    "/today": "day_briefing",
    "/brief": "day_briefing",
    "/day": "day_briefing",
    "/meetings": "meetings_summary",
    "/tasks": "tasks_summary",
    "/add-meeting": "larisa_create_event",
    "/create-event": "larisa_create_event",
    "/weather": "larisa_weather",
    "/search": "larisa_search",
    "/plan-day": "larisa_plan_day",
    "/plan": "larisa_plan_day",
    "/whoop": "whoop_report",
    "/news": "news_digest",
    "/health": "system_health",
    "/repair": "self_healing",
    "/sales": "sales_brief",
    "/pipeline": "sales_brief",
    "/risks": "sales_brief",
    "/focus-sales": "sales_brief",
    "/bitrixcheck": "bitrix_check",
}

INTENT_ROUTES = {
    "day_briefing": "day_briefing",
    "brief": "day_briefing",
    "plan_day": "larisa_plan_day",
    "create_event": "larisa_create_event",
    "weather": "larisa_weather",
    "search": "larisa_search",
    "meetings": "meetings_summary",
    "tasks": "tasks_summary",
    "whoop": "whoop_report",
    "news": "news_digest",
    "health": "system_health",
    "repair": "self_healing",
    "sales": "sales_brief",
    "pipeline": "sales_brief",
    "risks": "sales_brief",
    "focus": "sales_brief",
    "bitrixcheck": "bitrix_check",
}


def select_workflow(message: dict[str, Any]) -> str:
    command = str(message.get("command") or "").strip().lower()
    if command in COMMAND_ROUTES:
        return COMMAND_ROUTES[command]

    text = str(message.get("text") or "").strip().lower()
    token = text.split()[0] if text else ""
    if token in COMMAND_ROUTES:
        return COMMAND_ROUTES[token]

    intent = str(message.get("intent") or "").strip().lower()
    return INTENT_ROUTES.get(intent, "day_briefing")
