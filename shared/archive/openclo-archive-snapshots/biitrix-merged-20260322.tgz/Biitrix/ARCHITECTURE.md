# Cloudbot Architecture

Cloudbot построен как модульная система, где пользовательский интерфейс, orchestration-логика, автономные агенты и интеграции разделены по слоям. Это позволяет развивать `news_agent` и другие модули без расползания зависимостей по всему проекту.

## Структура

### `cloudbot/`
Главный пакет приложения.

- `cloudbot/bot/telegram` — Telegram-слой: принимает update, нормализует команды и передает их в orchestrator.
- `cloudbot/orchestrator` — центральная маршрутизация и запуск workflow.
- `cloudbot/workflows` — сценарии прикладной логики (`news_digest`, `day_briefing`, `system_health` и т.д.).
- `cloudbot/skills` — атомарные функции, которые могут переиспользоваться разными workflow и агентами.
- `cloudbot/providers` — адаптеры к внешним API и сервисам.
- `cloudbot/devops` — health-check, диагностика, мониторинг и эксплуатационные утилиты.

### `agents/`
Автономные модули верхнего уровня.

- `agents/news_agent` — специализированный агент новостного дайджеста.
- `agents/larisa_ivanovna` — личный executive assistant контур: календарь, задачи, brief дня, поиск, погода, новости, планирование дня.
- Здесь должны жить изолированные агенты, которые можно подключать через workflow-адаптер, не внедряя их напрямую в `providers` или `orchestrator`.

## Роли слоев

### `orchestrator`
- Главный диспетчер системы.
- Принимает входящие события из Telegram и других точек входа.
- Выбирает нужный workflow по команде, тексту или intent.

### `workflows`
- Сценарии логики приложения.
- Оркестрируют конкретный пользовательский сценарий: `news_digest`, `day_briefing`, `tasks_summary`, `system_health`.
- Содержат минимальную glue-логику между orchestrator и агентами/skills.

### `agents`
- Автономные модули с собственной внутренней логикой.
- Пример: `news_agent` отвечает за RSS, фильтрацию, кеш, перевод и сборку дайджеста.
- `larisa_ivanovna` отвечает только за personal assistant сценарии и не должен смешиваться с Sales Copilot.
- Агент должен подключаться через workflow-адаптер, а не напрямую из Telegram-слоя.

### `skills`
- Атомарные функции и небольшие действия.
- Не должны знать о Telegram и пользовательском UI.
- Могут вызываться из workflow и агентов как переиспользуемые кирпичики.

### `providers`
- Интеграции с внешними API.
- Отвечают только за доступ к внешнему сервису: Telegram, OpenAI, Bitrix, Todoist, WHOOP, Search.
- Не должны содержать пользовательские сценарии или сложную orchestration-логику.

### `telegram`
- Слой взаимодействия с пользователем.
- Нормализует входящие команды, не содержит бизнес-логики сценариев.
- Делегирует обработку в orchestrator и возвращает ответ пользователю.

## Базовый поток выполнения

```text
Telegram
  ↓
orchestrator
  ↓
workflow
  ↓
agent
  ↓
skills
  ↓
providers
  ↓
external APIs
```

## Практическое применение в текущем проекте

- Команда `/news` идет в `cloudbot/bot/telegram`, затем в `cloudbot/orchestrator`, потом в workflow `cloudbot/workflows/news_digest.py`.
- Команды `/today`, `/brief`, `/day`, `/weather`, `/search`, `/plan-day`, `/add-meeting` идут тем же путем, но в personal assistant контур Ларисы Ивановны через `cloudbot/workflows/*`.
- Workflow `news_digest` вызывает `agents/news_agent`, который:
  - загружает RSS;
  - использует кеш `cache/news_cache.json`;
  - фильтрует шумные и рекламные статьи;
  - при необходимости использует fallback RSS;
  - формирует готовый текст отчета.
- Команда `/health` идет тем же путем, но вызывает `cloudbot/workflows/system_health.py`, который использует `cloudbot/devops/system_health.py`.

## Архитектурные правила

- `agents/` не импортируют `cloudbot.providers` и `cloudbot.orchestrator` напрямую.
- Интеграция автономного агента в систему идет через `cloudbot/workflows/*`.
- Если агенту нужен Telegram, он использует существующий routing и callback-слой, а не создает новый bot-контур внутри себя.
- `skills` и `providers` не должны зависеть от Telegram-слоя.
- Секреты не хранятся в коде и читаются только из env.
- Runtime-артефакты (`logs`, `cache`) не должны ломать git-историю и должны быть безопасны к пересозданию.
