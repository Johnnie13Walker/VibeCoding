function resolveTelegramConfig(env = process.env) {
  return {
    botToken: String(env.TELEGRAM_BOT_TOKEN || "").trim(),
    apiBaseUrl: String(env.TELEGRAM_API_BASE_URL || "https://api.telegram.org").trim(),
    defaultChatId: String(env.TELEGRAM_CHAT_ID || "").trim(),
    dryRun: env.TELEGRAM_DRY_RUN === "1"
  };
}

function formatOutbound(message) {
  return String(message?.text || "").trim();
}

export function createTelegramTransport({ env = process.env, logger = console } = {}) {
  const cfg = resolveTelegramConfig(env);

  async function sendViaApi({ chatId, text, parseMode }) {
    const url = `${cfg.apiBaseUrl}/bot${cfg.botToken}/sendMessage`;
    const body = {
      chat_id: chatId,
      text,
      disable_web_page_preview: true
    };
    if (parseMode) {
      body.parse_mode = parseMode;
    }
    const response = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body)
    });

    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload?.ok === false) {
      const description = payload?.description || `HTTP ${response.status}`;
      throw new Error(`Telegram sendMessage failed: ${description}`);
    }

    return payload;
  }

  return {
    async send(message) {
      const text = formatOutbound(message);
      const parseMode = String(message?.parseMode || message?.parse_mode || "").trim();
      if (!text) return { status: "skipped_empty" };

      const chatId = String(message?.chatId || cfg.defaultChatId || "").trim();
      if (!chatId) throw new Error("Не задан chatId для отправки в Telegram");

      if (cfg.dryRun || !cfg.botToken) {
        logger.info?.(`[telegram dry-run] chat=${chatId} trigger=${message?.triggerType || "unknown"}`);
        logger.info?.(text);
        return { status: "dry_run", chatId, text };
      }

      const payload = await sendViaApi({ chatId, text, parseMode });
      return { status: "sent", chatId, parseMode, payload };
    }
  };
}
