export function buildSchedulerJobs({
  taskTimeNotificationsJob,
  eveningReminderJob,
  selfHealingJob
}) {
  return [
    {
      name: taskTimeNotificationsJob.name,
      schedule: taskTimeNotificationsJob.schedule,
      timezone: taskTimeNotificationsJob.timezone,
      run: taskTimeNotificationsJob.run
    },
    {
      name: eveningReminderJob.name,
      schedule: eveningReminderJob.schedule,
      timezone: eveningReminderJob.timezone,
      run: eveningReminderJob.run
    },
    {
      name: selfHealingJob.name,
      schedule: selfHealingJob.schedule,
      timezone: selfHealingJob.timezone,
      run: selfHealingJob.run
    }
  ];
}
