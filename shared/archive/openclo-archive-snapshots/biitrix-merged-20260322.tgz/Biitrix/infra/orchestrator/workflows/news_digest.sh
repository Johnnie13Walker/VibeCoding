#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# shellcheck disable=SC1091
source "$ROOT_DIR/infra/orchestrator/lib.sh"

ENV_INTEGRATIONS_FILE="${ENV_INTEGRATIONS_FILE:-$ROOT_DIR/.env.integrations}"
REPORT_DIR="${REPORT_DIR:-$ROOT_DIR/reports}"
NEWS_PER_CATEGORY_LIMIT="${NEWS_PER_CATEGORY_LIMIT:-${NEWS_LIMIT:-3}}"

if [[ -f "$ENV_INTEGRATIONS_FILE" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$ENV_INTEGRATIONS_FILE"
  set +a
fi

: "${TZ:=Europe/Moscow}"
export TZ

mkdir -p "$REPORT_DIR"
STAMP="$(date '+%Y%m%d_%H%M%S_MSK')"
REPORT_FILE="$REPORT_DIR/news_digest_${STAMP}.txt"

log "news_digest: старт (per_category_limit=${NEWS_PER_CATEGORY_LIMIT}, tz=Europe/Moscow)"

set +e
(
  cd "$ROOT_DIR"
  python3 -m agents.news_agent.news_agent --send --per-category-limit "$NEWS_PER_CATEGORY_LIMIT"
) >"$REPORT_FILE" 2>&1
rc=$?
set -e

if [[ "$rc" -ne 0 ]]; then
  log "news_digest: ошибка (rc=${rc}), отчет=${REPORT_FILE}"
  tail -n 120 "$REPORT_FILE" || true
  exit "$rc"
fi

log "news_digest: успешно, отчет=${REPORT_FILE}"
