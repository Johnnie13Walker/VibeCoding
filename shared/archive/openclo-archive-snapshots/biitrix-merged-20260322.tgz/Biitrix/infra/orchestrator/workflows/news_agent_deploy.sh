#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# shellcheck disable=SC1091
source "$ROOT_DIR/infra/orchestrator/lib.sh"

require_env PRIMARY_HOST SSH_USER SSH_KEY_PATH SSH_PORT

REMOTE_DIR="${NEWS_AGENT_REMOTE_DIR:-/home/ops/cloudbot-news-agent}"
SYSTEM_RUNNER_PATH="${NEWS_AGENT_SYSTEM_RUNNER_PATH:-/usr/local/bin/cloudbot-news-digest-live.sh}"
CRON_FILE_PATH="${NEWS_AGENT_CRON_FILE_PATH:-/etc/cron.d/cloudbot-news-digest}"
REPORT_DIR="${REPORT_DIR:-$ROOT_DIR/reports}"
STAMP="$(date '+%Y%m%d_%H%M%S_MSK')"
REPORT_FILE="$REPORT_DIR/news_agent_deploy_${STAMP}.txt"

mkdir -p "$REPORT_DIR"

FILES_TO_SYNC=(
  agents/__init__.py
  agents/news_agent
  infra/orchestrator/lib.sh
  infra/orchestrator/run_workflow.sh
  infra/orchestrator/workflows/news_digest.sh
)

log "news_agent_deploy: старт (host=${PRIMARY_HOST}, remote_dir=${REMOTE_DIR})"

{
  echo "# News Agent Deploy"
  echo "Время: $(date '+%F %T %Z')"
  echo "Хост: ${PRIMARY_HOST}"
  echo "Каталог: ${REMOTE_DIR}"
  echo
  echo "Файлы:"
  printf -- "- %s\n" "${FILES_TO_SYNC[@]}"
  echo

  run_remote_script "$PRIMARY_HOST" "
set -euo pipefail
mkdir -p '${REMOTE_DIR}' '${REMOTE_DIR}/reports'
"

  if [[ "${DRY_RUN:-0}" == "1" ]]; then
    echo "[DRY-RUN] tar sync -> ${PRIMARY_HOST}:${REMOTE_DIR}"
  else
    (
      cd "$ROOT_DIR"
      tar czf - "${FILES_TO_SYNC[@]}"
    ) | ssh -i "$SSH_KEY_PATH" -p "$SSH_PORT" \
      -o BatchMode=yes \
      -o StrictHostKeyChecking=accept-new \
      -o ConnectTimeout=10 \
      "${SSH_USER}@${PRIMARY_HOST}" \
      "mkdir -p '${REMOTE_DIR}' && tar xzf - -C '${REMOTE_DIR}'"
    echo "tar_sync=ok"
  fi

  run_remote_script "$PRIMARY_HOST" "
set -euo pipefail
cat > '${REMOTE_DIR}/run_news_digest_from_runtime_env.sh' <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR=\"\$(cd \"\$(dirname \"\${BASH_SOURCE[0]}\")\" && pwd)\"
: \"\${TZ:=Europe/Moscow}\"
export TZ

for var_name in OPENAI_API_KEY TELEGRAM_BOT_TOKEN TELEGRAM_CHAT_ID; do
  if [[ -z \"\${!var_name:-}\" ]]; then
    echo \"Не задана переменная \${var_name} для news digest\" >&2
    exit 1
  fi
done

cd \"\$ROOT_DIR\"
python3 -m agents.news_agent.news_agent --send --per-category-limit \"\${NEWS_PER_CATEGORY_LIMIT:-3}\" \"\$@\"
SCRIPT
chmod +x '${REMOTE_DIR}/run_news_digest_from_runtime_env.sh'
bash -n '${REMOTE_DIR}/run_news_digest_from_runtime_env.sh'
python3 -m py_compile '${REMOTE_DIR}/agents/news_agent/'*.py
echo \"remote_runner=ok\"
echo \"python=\$(python3 --version 2>&1)\"
"

  run_remote_script "$PRIMARY_HOST" "
set -euo pipefail
sudo -n tee '${SYSTEM_RUNNER_PATH}' >/dev/null <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

export TZ=Europe/Moscow

set -a
source /opt/openclaw/.env
set +a

bot_pid=\"\$(pgrep -u ops -f 'node ./scripts/scheduler_daemon.js' | head -n1)\"
if [[ -z \"\$bot_pid\" ]]; then
  echo 'Не найден процесс Telegram-бота Ларисы' >&2
  exit 1
fi

while IFS= read -r line; do
  case \"\$line\" in
    TELEGRAM_BOT_TOKEN=*|TELEGRAM_CHAT_ID=*|TELEGRAM_API_BASE_URL=*)
      export \"\$line\"
      ;;
  esac
done < <(tr '\0' '\n' </proc/\"\$bot_pid\"/environ)

cd '${REMOTE_DIR}'
exec ./run_news_digest_from_runtime_env.sh
SCRIPT
sudo -n chmod 755 '${SYSTEM_RUNNER_PATH}'
sudo -n bash -n '${SYSTEM_RUNNER_PATH}'

sudo -n tee '${CRON_FILE_PATH}' >/dev/null <<'CRON'
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
TZ=Europe/Moscow
0 10 * * * root ${SYSTEM_RUNNER_PATH} >> ${REMOTE_DIR}/reports/news_digest_cron.log 2>&1
CRON
sudo -n chmod 644 '${CRON_FILE_PATH}'
echo 'system_runner=ok'
echo 'cron=ok'
"
} | tee "$REPORT_FILE"

log "news_agent_deploy: успешно, отчет=${REPORT_FILE}"
