#!/usr/bin/env python3
"""Smoke test Cloudbot: тесты бота и news workflow."""

from __future__ import annotations

from datetime import datetime, timezone
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOT_DIR = ROOT / "bot"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def run_step(title: str, cmd: list[str], cwd: Path | None = None, env: dict[str, str] | None = None) -> None:
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)

    print(f"[STEP] {title}")
    completed = subprocess.run(
        cmd,
        cwd=cwd or ROOT,
        env=merged_env,
        text=True,
        capture_output=True,
        check=False,
    )

    if completed.stdout:
        print(completed.stdout.strip())
    if completed.returncode != 0:
        if completed.stderr:
            print(completed.stderr.strip(), file=sys.stderr)
        raise SystemExit(f"Smoke step failed: {title}")


def main() -> None:
    run_step("bot npm test", ["npm", "test"], cwd=BOT_DIR)

    print("[STEP] orchestrator получает сообщение")
    from cloudbot.orchestrator.orchestrator import handle_incoming_message

    result = handle_incoming_message({"text": "/today", "command": "/today", "chat_id": "1", "user_id": "1"})
    workflow = result.get("workflow")
    if workflow != "day_briefing":
        raise SystemExit(f"Ожидался workflow day_briefing, получен {workflow}")
    print("orchestrator OK:", result.get("text"))

    print("[STEP] telegram handler формирует ответ")
    from cloudbot.bot.telegram.telegram_handler import handle_update

    update_result = handle_update({
        "message": {
            "text": "/tasks",
            "chat": {"id": 700700},
            "from": {"id": 100500},
        }
    })
    response_workflow = update_result["result"].get("workflow")
    if response_workflow != "tasks_summary":
        raise SystemExit(f"Telegram->orchestrator маршрут сломан: {response_workflow}")
    print("telegram handler OK:", update_result["reply_text"])

    print("[STEP] telegram handler маршрут /news")
    fixtures_file = ROOT / "tests" / "fixtures" / "news_rss_fixtures.json"
    news_now_ts = str(int(datetime(2026, 3, 9, 10, 0, tzinfo=timezone.utc).timestamp()))
    cache_file = Path(tempfile.gettempdir()) / "cloudbot_news_cache_smoke.json"
    if cache_file.exists():
        cache_file.unlink()
    old_fixture = os.environ.get("NEWS_RSS_FIXTURES_FILE")
    old_translation_mode = os.environ.get("NEWS_TRANSLATION_MODE")
    old_now_ts = os.environ.get("NEWS_NOW_TS")
    old_cache_file = os.environ.get("NEWS_CACHE_FILE")
    os.environ["NEWS_RSS_FIXTURES_FILE"] = str(fixtures_file)
    os.environ["NEWS_TRANSLATION_MODE"] = "mock"
    os.environ["NEWS_NOW_TS"] = news_now_ts
    os.environ["NEWS_CACHE_FILE"] = str(cache_file)
    try:
        from agents.news_agent.news_agent import build_news_digest_from_env
        from agents.news_agent.news_filter import article_priority_score, is_low_signal_news

        digest = build_news_digest_from_env(os.environ)
        warm_digest = build_news_digest_from_env(os.environ)
        news_result = handle_update({
            "message": {
                "text": "/news",
                "chat": {"id": 700700},
                "from": {"id": 100500},
            }
        })
    finally:
        if old_fixture is None:
            os.environ.pop("NEWS_RSS_FIXTURES_FILE", None)
        else:
            os.environ["NEWS_RSS_FIXTURES_FILE"] = old_fixture
        if old_translation_mode is None:
            os.environ.pop("NEWS_TRANSLATION_MODE", None)
        else:
            os.environ["NEWS_TRANSLATION_MODE"] = old_translation_mode
        if old_now_ts is None:
            os.environ.pop("NEWS_NOW_TS", None)
        else:
            os.environ["NEWS_NOW_TS"] = old_now_ts
        if old_cache_file is None:
            os.environ.pop("NEWS_CACHE_FILE", None)
        else:
            os.environ["NEWS_CACHE_FILE"] = old_cache_file
        if cache_file.exists():
            cache_file.unlink()

    news_workflow = news_result["result"].get("workflow")
    if news_workflow != "news_digest":
        raise SystemExit(f"Telegram->orchestrator маршрут /news сломан: {news_workflow}")
    if "📰 Новости сегодня" not in news_result["reply_text"]:
        raise SystemExit("Команда /news не вернула формат дайджеста")
    if "<b>" not in news_result["reply_text"]:
        raise SystemExit("Команда /news не выделяет заголовки жирным")
    if "Кратко:" not in news_result["reply_text"]:
        raise SystemExit("Команда /news не вернула расширенную сводку по новостям")
    if "Ссылка: https://" not in news_result["reply_text"]:
        raise SystemExit("Команда /news не вернула ссылку на первоисточник")
    if digest["total_selected"] != 9:
        raise SystemExit(f"Ожидалось 9 новостей в дайджесте, получено {digest['total_selected']}")
    if digest.get("cache_hit"):
        raise SystemExit("Первый прогон news_digest не должен использовать cache hit")
    if not warm_digest.get("cache_hit"):
        raise SystemExit("Повторный прогон news_digest должен использовать кеш")
    if digest.get("total_article_enriched") != 9:
        raise SystemExit(
            f"Ожидалось обогащение 9 статей, получено {digest.get('total_article_enriched')}"
        )
    if digest.get("article_errors"):
        raise SystemExit(f"Article fetch вернул ошибки: {digest['article_errors']}")
    expected_categories = ["AI", "Cloud / DevOps", "Marketing / SEO"]
    for category in expected_categories:
        if category not in news_result["reply_text"]:
            raise SystemExit(f"В ответе /news отсутствует категория {category}")
        if len(digest["grouped_items"].get(category, [])) != 3:
            raise SystemExit(f"Категория {category} не ограничена до 3 новостей")
    if "Web Development" in news_result["reply_text"]:
        raise SystemExit("Блок Web Development не должен попадать в дайджест по умолчанию")
    chunks = digest.get("message_chunks") or []
    if not chunks:
        raise SystemExit("news_digest не вернул message_chunks для Telegram")
    for idx, chunk in enumerate(chunks, start=1):
        if len(chunk) > 3800:
            raise SystemExit(f"Chunk {idx} превышает безопасный лимит Telegram")
    if "Sponsored webinar" in news_result["reply_text"]:
        raise SystemExit("Рекламная новость попала в дайджест")
    if "Legacy SEO checklist from last week" in news_result["reply_text"]:
        raise SystemExit("Слишком старая новость попала в дайджест")
    print("telegram /news OK")

    print("[STEP] фильтр мусорных статей")
    noisy_title = {"title": "Top 10 tips for every team", "summary": "General overview without technical depth"}
    technical_title = {"title": "Kubernetes API automation for platform teams", "summary": "DevOps and Cloud automation"}
    generic_title = {"title": "Weekly roundup", "summary": "Broad non-technical summary"}
    if not is_low_signal_news(noisy_title):
        raise SystemExit("Фильтр не пометил мусорный заголовок как low-signal")
    if article_priority_score(technical_title) <= article_priority_score(generic_title):
        raise SystemExit("Техническая статья не получила более высокий приоритет")
    print("news_filter OK")

    print("[STEP] AI fallback RSS работает через фикстуры")
    from agents.news_agent.news_fetcher import AI_BACKUP_RSS_SOURCES, DEFAULT_RSS_SOURCES, RSSNewsFetcher

    fallback_fetcher = RSSNewsFetcher.from_env({
        "NEWS_RSS_FIXTURES_FILE": str(fixtures_file),
        "NEWS_CACHE_ENABLED": "0",
    })
    fallback_sources = {"AI": list(DEFAULT_RSS_SOURCES["AI"])}
    for source_url in DEFAULT_RSS_SOURCES["AI"]:
        if source_url not in AI_BACKUP_RSS_SOURCES:
            fallback_fetcher.fixtures_by_url.pop(source_url, None)
    fallback_result = fallback_fetcher.fetch(fallback_sources)
    fallback_items = [item for item in fallback_result["items"] if item.get("category") == "AI"]
    if not fallback_items:
        raise SystemExit("Fallback AI RSS не вернул ни одной новости")
    fallback_domains = {
        item.get("source_url")
        for item in fallback_items
        if item.get("source_url") in set(AI_BACKUP_RSS_SOURCES)
    }
    if not fallback_domains:
        raise SystemExit("Fallback AI RSS не использовал резервные источники")
    print("AI fallback OK:", ", ".join(sorted(str(url) for url in fallback_domains)))

    print("[STEP] команда /health")
    old_health_mode = os.environ.get("SYSTEM_HEALTH_MODE")
    os.environ["SYSTEM_HEALTH_MODE"] = "mock"
    try:
        health_result = handle_update({
            "message": {
                "text": "/health",
                "chat": {"id": 700700},
                "from": {"id": 100500},
            }
        })
    finally:
        if old_health_mode is None:
            os.environ.pop("SYSTEM_HEALTH_MODE", None)
        else:
            os.environ["SYSTEM_HEALTH_MODE"] = old_health_mode

    if health_result["result"].get("workflow") != "system_health":
        raise SystemExit("Команда /health не попала в system_health workflow")
    if "SYSTEM STATUS" not in health_result["reply_text"]:
        raise SystemExit("Команда /health не вернула системный статус")
    if "Telegram API: OK" not in health_result["reply_text"]:
        raise SystemExit("Команда /health не показала статус Telegram API")
    if "Bitrix API: OK" not in health_result["reply_text"]:
        raise SystemExit("Команда /health не показала статус Bitrix API")
    print("telegram /health OK")

    print("[STEP] команды Sales Copilot")
    sales_fixture_file = ROOT / "tests" / "fixtures" / "bitrix_crm_fixtures.json"
    sales_now_ts = str(int(datetime(2026, 3, 10, 9, 0, tzinfo=timezone.utc).timestamp()))
    old_sales_fixture = os.environ.get("BITRIX_CRM_FIXTURES_FILE")
    old_sales_now = os.environ.get("SALES_AGENT_NOW_TS")
    old_sales_target = os.environ.get("SALES_MONTHLY_TARGET")
    old_sales_webhook = os.environ.get("BITRIX_WEBHOOK_URL")
    old_sales_department_names = os.environ.get("SALES_DEPARTMENT_NAMES")
    old_sales_department_ids = os.environ.get("SALES_DEPARTMENT_IDS")
    os.environ["BITRIX_CRM_FIXTURES_FILE"] = str(sales_fixture_file)
    os.environ["SALES_AGENT_NOW_TS"] = sales_now_ts
    os.environ["SALES_MONTHLY_TARGET"] = "500000"
    os.environ["BITRIX_WEBHOOK_URL"] = "https://belberrycrm.bitrix24.ru/rest/1/local-smoke-token/"
    os.environ["SALES_DEPARTMENT_NAMES"] = "Группа продаж Belberry,Группа продаж Acoola Team,Телемаркетинг"
    os.environ.pop("SALES_DEPARTMENT_IDS", None)
    try:
        sales_result = handle_update({
            "message": {
                "text": "/sales",
                "chat": {"id": 700700},
                "from": {"id": 100500},
            }
        })
        pipeline_result = handle_update({
            "message": {
                "text": "/pipeline",
                "chat": {"id": 700700},
                "from": {"id": 100500},
            }
        })
        risks_result = handle_update({
            "message": {
                "text": "/risks",
                "chat": {"id": 700700},
                "from": {"id": 100500},
            }
        })
        focus_result = handle_update({
            "message": {
                "text": "/focus-sales",
                "chat": {"id": 700700},
                "from": {"id": 100500},
            }
        })
    finally:
        if old_sales_fixture is None:
            os.environ.pop("BITRIX_CRM_FIXTURES_FILE", None)
        else:
            os.environ["BITRIX_CRM_FIXTURES_FILE"] = old_sales_fixture
        if old_sales_now is None:
            os.environ.pop("SALES_AGENT_NOW_TS", None)
        else:
            os.environ["SALES_AGENT_NOW_TS"] = old_sales_now
        if old_sales_target is None:
            os.environ.pop("SALES_MONTHLY_TARGET", None)
        else:
            os.environ["SALES_MONTHLY_TARGET"] = old_sales_target
        if old_sales_webhook is None:
            os.environ.pop("BITRIX_WEBHOOK_URL", None)
        else:
            os.environ["BITRIX_WEBHOOK_URL"] = old_sales_webhook
        if old_sales_department_names is None:
            os.environ.pop("SALES_DEPARTMENT_NAMES", None)
        else:
            os.environ["SALES_DEPARTMENT_NAMES"] = old_sales_department_names
        if old_sales_department_ids is None:
            os.environ.pop("SALES_DEPARTMENT_IDS", None)
        else:
            os.environ["SALES_DEPARTMENT_IDS"] = old_sales_department_ids

    if sales_result["result"].get("workflow") != "sales_brief":
        raise SystemExit("Команда /sales не попала в sales_brief workflow")
    if sales_result.get("reply_parse_mode") != "HTML":
        raise SystemExit("Команда /sales не выставила HTML parse mode")
    if "📊 Sales Copilot" not in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не вернула sales brief")
    if "🎯 Фокус РОПа" in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не должна содержать отдельный отчет Фокус РОПа")
    if "💰 Деньги" not in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не показала отдельный денежный блок")
    if (
        "📞 Коммуникации за предыдущий рабочий день" not in sales_result["reply_text"]
        or "🤝 Проведенные встречи" not in sales_result["reply_text"]
        or "📈 Sales Brief" not in sales_result["reply_text"]
    ):
        raise SystemExit("Команда /sales не вернула блок коммуникаций")
    if "💬 Диалоги в мессенджерах" in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не должна дублировать диалоги в мессенджерах отдельным блоком")
    if "🗂 Просроченные задачи по сделкам" in sales_result["reply_text"] or "🧊 Сделки без следующего шага" in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не должна содержать детали, вынесенные в Фокус РОПа")
    if "⚠️ Риски" in sales_result["reply_text"] or "🧠 Где нужен руководитель" in sales_result["reply_text"] or "🎯 Фокус продаж" in sales_result["reply_text"]:
        raise SystemExit("Команда /sales сохранила старые дублирующие блоки")
    if '<a href="https://belberrycrm.bitrix24.ru/crm/deal/details/' not in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не вернула ссылку на сделку Bitrix")
    if "— <b>" not in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не показала менеджера сделки")
    if "Наб — наборы" not in sales_result["reply_text"] or "Конв — конверсия в дозвон" not in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не показала метрики коммуникаций")
    if "Открытые линии" in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не убрала legacy-блок открытых линий")
    if "Горячая стадия — Подготовка договора:" in sales_result["reply_text"]:
        raise SystemExit("Команда /sales сохранила лишнюю горячую стадию в главном отчете")
    if "• Запущенные без коммуникации > 14 дн.:" not in sales_result["reply_text"]:
        raise SystemExit("Команда /sales не показала денежный сигнал по запущенным сделкам")

    if pipeline_result["result"].get("workflow") != "sales_brief":
        raise SystemExit("Команда /pipeline не попала в sales_brief workflow")
    if pipeline_result.get("reply_parse_mode") != "HTML":
        raise SystemExit("Команда /pipeline не выставила HTML parse mode")
    if "📊 Sales Copilot" not in pipeline_result["reply_text"]:
        raise SystemExit("Команда /pipeline должна быть alias на главный Sales Copilot")
    if "📈 Состояние воронки на сейчас" not in pipeline_result["reply_text"]:
        raise SystemExit("Команда /pipeline не вернула merged-срез воронки")
    if "💰 Деньги" not in pipeline_result["reply_text"]:
        raise SystemExit("Команда /pipeline не показала денежный блок")
    if "Горячая стадия — Подготовка договора:" in pipeline_result["reply_text"]:
        raise SystemExit("Команда /pipeline сохранила горячую стадию в merged-отчете")

    if risks_result["result"].get("workflow") != "sales_brief":
        raise SystemExit("Команда /risks не попала в sales_brief workflow")
    if risks_result.get("reply_parse_mode") != "HTML":
        raise SystemExit("Команда /risks не выставила HTML parse mode")
    if "🎯 Фокус РОПа" not in risks_result["reply_text"]:
        raise SystemExit("Команда /risks не вернула Фокус РОПа")
    if (
        "📌 Сделки под контролем" not in risks_result["reply_text"]
        or "👥 Команда и дисциплина" not in risks_result["reply_text"]
        or "🗂 Просрочки по менеджерам" not in risks_result["reply_text"]
        or "🧊 Сделки без следующего шага" not in risks_result["reply_text"]
    ):
        raise SystemExit("Команда /risks не вернула полный управленческий блок")
    if "переноса" not in risks_result["reply_text"]:
        raise SystemExit("Команда /risks не показала задачи с многократным переносом срока")

    if focus_result["result"].get("workflow") != "sales_brief":
        raise SystemExit("Команда /focus-sales не попала в sales_brief workflow")
    if focus_result.get("reply_parse_mode") != "HTML":
        raise SystemExit("Команда /focus-sales не выставила HTML parse mode")
    if "🎯 Фокус РОПа" not in focus_result["reply_text"]:
        raise SystemExit("Команда /focus-sales не вернула блок Фокус РОПа")
    if (
        "📊 Сигналы по отделу" not in focus_result["reply_text"]
        or "➡️ Что сделать РОПу сегодня" not in focus_result["reply_text"]
        or "🗂 Просрочки по менеджерам" not in focus_result["reply_text"]
        or "🧊 Сделки без следующего шага" not in focus_result["reply_text"]
    ):
        raise SystemExit("Команда /focus-sales не вернула управленческую структуру блока")
    if '<a href="https://belberrycrm.bitrix24.ru/crm/deal/details/' not in focus_result["reply_text"]:
        raise SystemExit("Команда /focus-sales не вернула HTML-ссылки на сделки")
    if "🎯 Фокус продаж" in focus_result["reply_text"]:
        raise SystemExit("Команда /focus-sales сохранила старый заголовок")
    if "Подготовить follow-up по Nord" not in focus_result["reply_text"] or "Обновить статус Vega" not in focus_result["reply_text"]:
        raise SystemExit("Команда /focus-sales не показала задачи с переносом срока по сделкам")
    print("sales copilot OK")

    print("[STEP] команда /bitrixcheck")
    old_bitrix_fixture = os.environ.get("BITRIX_FIXTURES_FILE")
    old_bitrix_crm_fixture = os.environ.get("BITRIX_CRM_FIXTURES_FILE")
    os.environ["BITRIX_FIXTURES_FILE"] = str(sales_fixture_file)
    os.environ["BITRIX_CRM_FIXTURES_FILE"] = str(sales_fixture_file)
    try:
        bitrix_result = handle_update({
            "message": {
                "text": "/bitrixcheck",
                "chat": {"id": 700700},
                "from": {"id": 100500},
            }
        })
    finally:
        if old_bitrix_fixture is None:
            os.environ.pop("BITRIX_FIXTURES_FILE", None)
        else:
            os.environ["BITRIX_FIXTURES_FILE"] = old_bitrix_fixture
        if old_bitrix_crm_fixture is None:
            os.environ.pop("BITRIX_CRM_FIXTURES_FILE", None)
        else:
            os.environ["BITRIX_CRM_FIXTURES_FILE"] = old_bitrix_crm_fixture

    if bitrix_result["result"].get("workflow") != "bitrix_check":
        raise SystemExit("Команда /bitrixcheck не попала в bitrix_check workflow")
    if "Bitrix connection: OK" not in bitrix_result["reply_text"]:
        raise SystemExit("Команда /bitrixcheck не подтвердила подключение")
    if "- профиль" not in bitrix_result["reply_text"]:
        raise SystemExit("Команда /bitrixcheck не показала доступ к профилю")
    if "- сделки" not in bitrix_result["reply_text"]:
        raise SystemExit("Команда /bitrixcheck не показала доступ к сделкам")
    print("bitrixcheck OK")

    print("[STEP] self-healing чинит кеш и лог")
    from cloudbot.devops.self_healing import run_self_healing

    repair_cache_file = Path(tempfile.gettempdir()) / "cloudbot_self_healing_cache.json"
    repair_log_file = Path(tempfile.gettempdir()) / "cloudbot_self_healing_news.log"
    repair_self_log_file = Path(tempfile.gettempdir()) / "cloudbot_self_healing.log"
    repair_rotated_log = Path(f"{repair_log_file}.1")
    repair_cache_file.write_text("{broken json", encoding="utf-8")
    repair_log_file.write_text("x" * 2048, encoding="utf-8")
    if repair_rotated_log.exists():
        repair_rotated_log.unlink()
    if repair_self_log_file.exists():
        repair_self_log_file.unlink()

    old_self_healing_mode = os.environ.get("SELF_HEALING_MODE")
    old_repair_cache = os.environ.get("NEWS_CACHE_FILE")
    old_repair_log = os.environ.get("NEWS_AGENT_LOG_FILE")
    old_self_healing_log = os.environ.get("SELF_HEALING_LOG_FILE")
    old_rotate_limit = os.environ.get("SELF_HEALING_LOG_ROTATE_BYTES")
    os.environ["SELF_HEALING_MODE"] = "mock"
    os.environ["NEWS_CACHE_FILE"] = str(repair_cache_file)
    os.environ["NEWS_AGENT_LOG_FILE"] = str(repair_log_file)
    os.environ["SELF_HEALING_LOG_FILE"] = str(repair_self_log_file)
    os.environ["SELF_HEALING_LOG_ROTATE_BYTES"] = "1024"
    try:
        healing_result = run_self_healing(os.environ)
        repair_result = handle_update({
            "message": {
                "text": "/repair",
                "chat": {"id": 700700},
                "from": {"id": 100500},
            }
        })
    finally:
        if old_self_healing_mode is None:
            os.environ.pop("SELF_HEALING_MODE", None)
        else:
            os.environ["SELF_HEALING_MODE"] = old_self_healing_mode
        if old_repair_cache is None:
            os.environ.pop("NEWS_CACHE_FILE", None)
        else:
            os.environ["NEWS_CACHE_FILE"] = old_repair_cache
        if old_repair_log is None:
            os.environ.pop("NEWS_AGENT_LOG_FILE", None)
        else:
            os.environ["NEWS_AGENT_LOG_FILE"] = old_repair_log
        if old_self_healing_log is None:
            os.environ.pop("SELF_HEALING_LOG_FILE", None)
        else:
            os.environ["SELF_HEALING_LOG_FILE"] = old_self_healing_log
        if old_rotate_limit is None:
            os.environ.pop("SELF_HEALING_LOG_ROTATE_BYTES", None)
        else:
            os.environ["SELF_HEALING_LOG_ROTATE_BYTES"] = old_rotate_limit
        for temp_path in [repair_cache_file, repair_log_file, repair_rotated_log, repair_self_log_file]:
            if temp_path.exists():
                temp_path.unlink()

    if healing_result["checks"]["cache"].get("status") != "recreated":
        raise SystemExit("Self-healing не пересоздал поврежденный кеш")
    if healing_result["checks"]["logs"].get("status") != "rotated":
        raise SystemExit("Self-healing не выполнил ротацию большого лога")
    if "SELF HEALING REPORT" not in healing_result.get("text", ""):
        raise SystemExit("Self-healing не сформировал отчет")
    if repair_result["result"].get("workflow") != "self_healing":
        raise SystemExit("Команда /repair не попала в self_healing workflow")
    if "SELF HEALING REPORT" not in repair_result["reply_text"]:
        raise SystemExit("Команда /repair не вернула self-healing отчет")
    print("self-healing OK")

    print("[STEP] scheduler содержит self_healing job")
    run_step(
        "bot scheduler self_healing job",
        [
            "node",
            "--input-type=module",
            "-e",
            "import { createBotModules } from './src/index.js'; const modules = createBotModules(process.env); const names = modules.schedulerJobs.map((job) => job.name); if (!names.includes('self_healing')) { throw new Error(`scheduler jobs missing self_healing: ${names.join(',')}`); } console.log(names.join(','));",
        ],
        cwd=BOT_DIR,
    )

    run_step(
        "telegram dry-run jobs",
        ["node", "./scripts/run_jobs_once.js"],
        cwd=BOT_DIR,
        env={
            "TELEGRAM_OWNER_ID": "100500",
            "TELEGRAM_CHAT_ID": "700700",
            "TELEGRAM_DRY_RUN": "1",
            "USE_FIXTURE_TASKS": "1",
            "USE_FIXTURE_USERS": "1",
        },
    )

    print("SMOKE TEST OK")


if __name__ == "__main__":
    main()
