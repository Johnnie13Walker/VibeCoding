#!/usr/bin/env python3
"""Smoke check для Bitrix tasks access."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cloudbot.providers.bitrix.bitrix_sales_adapter import BitrixSalesAdapter  # noqa: E402


def _load_env_file(path: Path) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


def main() -> int:
    _load_env_file(Path("/opt/openclaw/.env"))
    adapter = BitrixSalesAdapter.from_env()
    bundle = adapter.get_tasks_bundle(limit=5)
    print(json.dumps(bundle, ensure_ascii=False, indent=2))
    return 0 if bundle.get("available") else 1


if __name__ == "__main__":
    raise SystemExit(main())
