# Cloudbot Personal AI Assistant

Cloudbot — персональный AI-ассистент на базе OpenClaw с интерфейсом в Telegram.

## Ключевые компоненты
- `cloudbot/bot/telegram` — Telegram interface
- `cloudbot/orchestrator` — центральная маршрутизация сценариев
- `cloudbot/workflows` — пользовательские сценарии ассистента
- `cloudbot/skills` — атомарные навыки
- `cloudbot/providers` — интеграции с внешними API
- `cloudbot/devops` — health-check, диагностика, мониторинг, backup

## Интеграции
- Telegram
- OpenAI
- Bitrix
- Todo
- WHOOP
- Web Search

## Быстрый запуск
```bash
python3 checks/smoke_test.py
```

## News Agent (ежедневный дайджест)
- Модуль: `agents/news_agent/`
- Команда в Telegram: `/news` (или `новости`)
- Источники: RSS (AI, Marketing/SEO, Tech)
- Авто-рассылка: cron `10:00` МСК через workflow `news_digest`
- Обязательный перевод заголовков на русский: через OpenAI (`OPENAI_API_KEY`)

## Larisa Ivanovna Agent (personal assistant)
- Модуль: `agents/larisa_ivanovna/`
- Публичные команды в Telegram: `/today`, `/brief`, `/day`, `/weather`, `/search`, `/plan-day`, `/add-meeting`
- Подключение к системе: через `cloudbot/workflows/day_briefing.py` и `cloudbot/workflows/larisa_*.py`
- Границы: календарь, задачи, планирование дня, brief дня, поиск, погода, новости
- Исключено: CRM, сделки, воронка, sales-аналитика, финансы
