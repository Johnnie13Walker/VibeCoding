# API-интеграции Cloudbot

## Telegram
- Интерфейс общения с пользователем.
- Входящий `update` обрабатывается в `cloudbot/bot/telegram/telegram_handler.py`.
- Контур Ларисы Ивановны использует тот же Telegram-layer через workflow routing и callback отправки, без отдельного кода нового бота в агенте.

## OpenAI
- Используется как интеллект ассистента в orchestrator/workflows (через существующие интеграции проекта).
- Также используется News Agent для обязательного перевода RSS-заголовков на русский язык.

## Bitrix
- Провайдер: `cloudbot/providers/bitrix_provider.py`.
- Sales adapter: `cloudbot/providers/bitrix/bitrix_sales_adapter.py`.
- Sales data skill: `cloudbot/skills/bitrix_sales_data.py`.
- Skills: `cloudbot/skills/create_bitrix_event.py`, `cloudbot/skills/get_bitrix_calendar.py`.

## Todo
- Провайдер: `cloudbot/providers/todo_provider.py`.
- Skill: `cloudbot/skills/get_todo_tasks.py`.
- Используется контуром `agents/larisa_ivanovna/` через agent-local adapter layer.

## WHOOP
- Провайдер: `cloudbot/providers/whoop_provider.py`.
- Skill: `cloudbot/skills/get_whoop_data.py`.

## Web Search
- Провайдер: `cloudbot/providers/search_provider.py`.
- Skill: `cloudbot/skills/web_search.py`.
- Используется контуром `agents/larisa_ivanovna/` через agent-local adapter layer.

## RSS News
- Агент: `agents/news_agent/`.
- Workflow: `cloudbot/workflows/news_digest.py`.
- Telegram-команда: `/news`.
- Авто-запуск: orchestrator workflow `news_digest` по cron в 10:00 МСК.

## Personal Assistant / Лариса Ивановна
- Агент: `agents/larisa_ivanovna/`.
- Workflow entrypoints: `cloudbot/workflows/day_briefing.py`, `cloudbot/workflows/larisa_create_event.py`, `cloudbot/workflows/larisa_weather.py`, `cloudbot/workflows/larisa_search.py`, `cloudbot/workflows/larisa_plan_day.py`.
- Календарь: через `cloudbot/skills/get_bitrix_calendar.py` и `cloudbot/skills/create_bitrix_event.py`.
- Задачи: через `cloudbot/skills/get_todo_tasks.py`.
- Поиск: через `cloudbot/skills/web_search.py`.
- Погода и структурированные новости в этом шаге оформлены как контракты с явными ограничениями до отдельной нормализации источников.
